//
//  ViewController.swift
//  Swift笔记16
//
//  Created by apple on 16/1/4.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //析构过程(Deinitialization)
        
        //1.析构过程原理
        
        //Swift会自动释放不再需要的实例以释放资源 如自动引用计数章节中所讲述 Swift通过自动引用计数(ARC)处理实例的内存管理 通常实例被释放时不需要手动地去清理 但是当使用自己的资源时 可能需要进行一些额外的清理 例如:如果创建了一个自定义的类来打开一个文件 并写入一些数据 则可能需要在类实例被释放之前手动去关闭该文件
        
        //在类的定义中 每个类最多只能有一个析构器 而且析构器不带任何参数 如下所示:
//        deinit
//        {
//            //执行析构过程
//        }
        
        //析构器在实例释放发生前被自动调用 析构器是不允许被主动调用的 子类继承了父类的析构器 并且在子类析构器实现的最后 父类的析构器会被自动调用 即使子类没有提供自己的析构器 父类的析构器也同样会被调用
        
        //因为直到实例的析构器被调用时 实例才会被释放 所以析构器可以访问所有请求实例的属性 并且根据那些属性可以修改它的行为(例如:查找一个需要被关闭的文件)
        
        
        
        //2.析构器操作
        
        //下面是一个析构器操作的例子 这里定义了两种新类型 分别是Bank和Player Bank结构体管理一个虚拟货币的流通 在这个流通中设定Bank永远不可能拥有超过10000硬币 而且在游戏中有且只能有一个Bank存在 因此Bank结构体在实现时会带有静态属性和静态方法来存储和管理其当前的状态
        struct Bank
        {
            static var coinsInBank = 10_000
            
            static func vendCoins(coins: Int) -> Int
            {
                let numberOfCoins = min(coins, coinsInBank)
                coinsInBank -= numberOfCoins
                return numberOfCoins
            }
            
            static func recycleCoins(coins: Int)
            {
                coinsInBank += coins
            }
        }
        
        //Player类描述了游戏中的玩家 每个玩家在任何时刻都有一定数量的硬币存储在钱包中 这通过player的coinsInPurse属性来体现:
        class Player
        {
            var coinsInPurse: Int
            
            init(coins: Int)
            {
                coinsInPurse = Bank.vendCoins(coins)
            }
            
            func winCoins(coins: Int)
            {
                coinsInPurse += Bank.vendCoins(coins)
            }
            
            deinit
            {
                Bank.recycleCoins(coinsInPurse)
            }
        }
        //Player类实现了一个析构器 析构器在Player实例释放前被调用 这里析构器的作用是将玩家的所有硬币都返回给bank对象
        
        var playerOne: Player? = Player(coins: 100)
        print("A new player has joined the game with \(playerOne!.coinsInPurse) coins")
        print("There are now \(Bank.coinsInBank) coins left in the bank")
        
        playerOne!.winCoins(2_000)
        print("PlayerOne won 2000 coins & now has \(playerOne!.coinsInPurse) coins")
        print("The bank now has \(Bank.coinsInBank) coins left")
        
        playerOne = nil
        print("PlayerOne has left the game")
        print("The bank now has \(Bank.coinsInBank) coins")
        //玩家离开了游戏 这表明要将可选的playerOne变量置为nil 这种情况发生时playerOne变量对Player实例的引用被破坏 没有其它属性或变量引用Player实例 在释放它之前 其析构器会被自动调用 使硬币返回到bank对象中
    }
}