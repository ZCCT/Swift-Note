//
//  ViewController.swift
//  Swift笔记18
//
//  Created by apple on 16/1/6.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //可空链式调用(Optional Chaining)
        
        //可空链式调用是一种可以请求和调用属性 方法及下标的过程 它的可空性体现于请求或调用的目标当前可能为空(nil) 如果可空的目标有值 那么调用就会成功 如果选择的目标为空(nil) 那么这种调用将返回空(nil) 多个连续的调用可以被链接在一起形成一个调用链 如果其中任何一个节点为空(nil)将导致整个链调用失败
            
        //注意:Swift的可空链式调用和Objective-C中的消息为空有些相像 但是Swift可以使用在任意类型中 并且能够检查调用是否成功
        
        
        
        //1.使用可空链式调用来强制展开
        
        //通过在想调用非空的属性 方法 或下标的可空值(optional value)后面放一个问号 可以定义一个可空链 这一点很像在可空值后面放一个叹号(!)来强制展开其中值 它们的主要区别在于当可空值为空时可空链式只是调用失败 然而强制展开将会触发运行时错误
        
        //为了反映可空链式调用可以在空对象(nil)上调用 不论这个调用的属性 方法 下标等返回的值是不是可空值 它的返回结果都是一个可空值 可以利用这个返回值来判断可空链式调用是否调用成功 如果调用有返回值则说明调用成功 返回nil则说明调用失败
        
        //可空链式调用的返回结果与原本的返回结果具有相同的类型 但是被包装成了一个可空类型值 当可空链式调用成功时 一个本应该返回Int的类型的结果将会返回Int?类型
        
        //下面几段代码将解释可空链式调用和强制展开的不同:
        class Person
        {
            var residence: Residence?
        }
        
        class Residence
        {
            var numberOfRooms = 1
        }
        
        let john = Person()
//        let roomCount = john.residence!.numberOfRooms //当residence为空时会触发运行时错误
        
        //可空链式调用提供了一种另一种访问numberOfRooms的方法:
        if let roomCount = john.residence?.numberOfRooms
        {
            print("John's residence has \(roomCount) room(s).")
        }
        else
        {
            print("Unable to retrieve the number of rooms.")
        }
        
        //因为访问numberOfRooms有可能失败 可空链式调用会返回Int?类型 如上所示:当residence为nil时 将会为nil 表明无法访问numberOfRooms
        
        //注意:即使numberOfRooms是不可空的Int时 这一点也成立 只要是通过可空链式调用就意味着最后numberOfRooms返回一个Int?而不是Int
        
        //通过赋给john.residence一个Residence的实例变量 这样john.residence就不为nil了:
        john.residence = Residence()
        
        if let roomCount = john.residence?.numberOfRooms
        {
            print("John's residence has \(roomCount) room(s).")
        }
        else
        {
            print("Unable to retrieve the number of rooms.")
        }
        
        
        
        //2.为可空链式调用定义模型类
        
        //通过使用可空链式调用可以调用多层属性 方法 和下标 这样可以通过各种模型向下访问各种子属性 并且判断能否访问子属性的属性 方法或下标
        
        //下例定义了四个模型类 包括多层可空链式调用:
        class PersonNew
        {
            var residence: ResidenceNew?
        }
        
        class Room
        {
            let name: String
            init(name: String) { self.name = name }
        }
        
        class ResidenceNew
        {
            var rooms = [Room]()
            
            var numberOfRooms: Int
            {
                return rooms.count
            }
            
            subscript(i: Int) -> Room
            {
                get
                {
                    return rooms[i]
                }
                set
                {
                    rooms[i] = newValue
                }
            }
            
            func printNumberOfRooms()
            {
                print("The number of rooms is \(numberOfRooms)")
            }
            var address: Address?
        }
        
        class Address
        {
            var buildingName: String?
            var buildingNumber: String?
            var street: String?
            
            func buildingIdentifier() -> String?
            {
                if buildingName != nil
                {
                    return buildingName
                }
                else if buildingNumber != nil
                {
                    return buildingNumber
                }
                else
                {
                    return nil
                }
            }
        }
        
        
        
        //3.通过可空链式调用访问属性
        
        //下例创建了一个Person实例 然后访问numberOfRooms属性:
        let bob = PersonNew()
        
        if let roomCount = bob.residence?.numberOfRooms
        {
            print("Bob's residence has \(roomCount) room(s).")
        }
        else
        {
            print("Unable to retrieve the number of rooms.")
        }
        //因为bob.residence为nil 所以这个可空链式调用失败了
        
        //通过可空链式调用来设定属性值:
        let someAddress = Address()
        someAddress.buildingNumber = "29"
        someAddress.street = "Acacia Road"
        bob.residence?.address = someAddress
        //本例中通过bob.residence来设定address属性也是不行的 因为bob.residence为nil
        
        
        
        //4.通过可空链式调用来调用方法
        
        //可以通过可空链式调用来调用方法 并判断是否调用成功 即使这个方法没有返回值
        
//        func printNumberOfRooms()
//        {
//            print("The number of rooms is \(numberOfRooms)")
//        }
        
        //这个方法没有返回值 但是没有返回值的方法隐式返回Void类型 没有返回值的方法也会返回()或者空的元组
        
        //如果在可空值上通过可空链式调用来调用这个方法 这个方法的返回类型为Void? 而不是Void 因为通过可空链式调用得到的返回值都是可空的:
        if bob.residence?.printNumberOfRooms() != nil
        {
            print("It was possible to print the number of rooms.")
        }
        else
        {
            print("It was not possible to print the number of rooms.")
        }
        
        //同样 可以判断通过可空链式调用来给属性赋值是否成功 通过可空链式调用给属性赋值会返回Void? 通过判断返回值是否为nil可以知道赋值是否成功:
        if (bob.residence?.address = someAddress) != nil
        {
            print("It was possible to set the address.")
        }
        else
        {
            print("It was not possible to set the address.")
        }
        
        
        
        //5.通过可空链式调用来访问下标
        
        //通过可空链式调用 可以用下标来对可空值进行读取或写入 并且判断下标调用是否成功
        
        //注意:当通过可空链式调用访问可空值的下标时 应该将问号放在下标方括号的前面:
        bob.residence?[0] = Room(name: "Bathroom")
        
        if let firstRoomName = bob.residence?[0].name
        {
            print("The first room name is \(firstRoomName).")
        }
        else
        {
            print("Unable to retrieve the first room name.")
        }
        
        //如果创建了一个Residence实例 添加一些Room实例并赋值给bob.residence 就可以通过可选链和下标来访问数组中的元素:
        let bobsHouse = ResidenceNew()
        bobsHouse.rooms.append(Room(name: "Living Room"))
        bobsHouse.rooms.append(Room(name: "Kitchen"))
        bob.residence = bobsHouse
        
        if let firstRoomName = bob.residence?[0].name
        {
            print("The first room name is \(firstRoomName).")
        }
        else
        {
            print("Unable to retrieve the first room name.")
        }
        
        
        
        //6.访问可空类型的下标
        
        //如果下标返回可空类型值 如:Swift中Dictionary的key下标 可以在下标的闭合括号后面放一个问号来链接下标的可空返回值:
        var testScores = ["Dave": [86, 82, 84], "Bev": [79, 94, 81]]
        testScores["Dave"]?[0] = 91
        testScores["Brian"]?[0] = 72 //调用失败 因为key"Brian"在字典中不存在
        
        
        
        //7.多层链接
        
        //可以通过多层可空链式调用来向下访问属性 方法和下标 但是多层可空链式调用不会添加返回值的可空性
        
        //因此:通过可空链式调用访问一个Int值 将会返回Int? 但是通过可空链式调用访问Int?值 并不会变得更加可空
        if let bobsStreet = bob.residence?.address?.street
        {
            print("John's street name is \(bobsStreet).")
        }
        else
        {
            print("Unable to retrieve the address.")
        }
        
        //如果把bob.residence.address指向一个实例 并且为address中的street属性赋值 就能过通过可空链式调用来访问street属性了:
        let bobsAddress = Address()
        bobsAddress.buildingName = "The Larches"
        bobsAddress.street = "Laurel Street"
        bob.residence?.address = bobsAddress
        
        if let bobsStreet = bob.residence?.address?.street
        {
            print("Bob's street name is \(bobsStreet).")
        }
        else
        {
            print("Unable to retrieve the address.")
        }
        
        
        
        //8.对返回可空值的函数进行链接
        
        //下例中 通过可空链式调用来调用Address的buildingIdentifier()方法 这个方法返回String?类型 和上面一样 通过可空链式调用的方法的最终返回值还是String?:
        if let buildingIdentifier = bob.residence?.address?.buildingIdentifier()
        {
            print("Bob's building identifier is \(buildingIdentifier).")
        }
        
        //如果要进一步对方法的返回值进行可空链式调用 可以在方法buildingIdentifier()的圆括号后面加上问号:
        if let beginsWithThe = bob.residence?.address?.buildingIdentifier()?.hasPrefix("The")
        {
            if beginsWithThe
            {
                print("Bob's building identifier begins with \"The\".")
            }
            else
            {
                print("Bob's building identifier does not begin with \"The\".")
            }
        }
    }
}