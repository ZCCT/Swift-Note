//
//  ViewController.swift
//  Swift笔记08
//
//  Created by apple on 15/12/24.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //闭包(Closures)
        
        //闭包是自包含的函数代码块 可以在代码中被传递和使用
        
        //Swift中的闭包与C和Objective-C中的代码块(blocks)以及其他一些编程语言中的匿名函数比较相似
        
        //闭包可以捕获和存储其所在上下文中任意常量和变量的引用 这就是所谓的闭合并包裹着这些常量和变量 俗称闭包 Swift会管理在捕获过程中涉及到的所有内存操作
        
        //在函数章节中介绍的全局和嵌套函数实际上也是特殊的闭包 闭包采取如下三种形式之一:
        //(1)全局函数是一个有名字但不会捕获任何值的闭包
        //(2)嵌套函数是一个有名字并可以捕获其封闭函数域内值的闭包
        //(3)闭包表达式是一个利用轻量级语法所写的可以捕获其上下文中变量或常量值的匿名闭包
        
        //Swift的闭包表达式拥有简洁的风格 并鼓励在常见场景中进行语法优化 主要优化如下:
        //利用上下文推断参数和返回值类型
        //隐式返回单表达式闭包 即单表达式闭包可以省略return关键字
        //参数名称缩写
        //尾随(Trailing)闭包语法
        
        
        
        //1.闭包表达式(Closure Expressions)
        
        //嵌套函数是一个在较复杂函数中方便进行命名和定义自包含代码模块的方式 有时候撰写小巧的没有完整定义和命名的类 函数结构也是很有用处的 尤其是在处理一些函数并需要将另外一些函数作为该函数的参数时
        
        //闭包表达式是一种利用简洁语法构建内联闭包的方式 闭包表达式提供了一些语法优化 使得撰写闭包变得简单明了 下面闭包表达式的例子通过使用几次迭代展示了sort(_:)方法定义和语法优化的方式 每一次迭代都用更简洁的方式描述了相同的功能
        
        
        
        //1.1sort函数(The Sort Function)
        
        //Swift标准库提供了名为sort的函数 会根据提供的用于排序的闭包函数将已知类型数组中的值进行排序 一旦排序完成 sort(_:)方法会返回一个与原数组大小相同 包含同类型元素且元素已正确排序的新数组 原数组不会被sort(_:)方法修改
        
        //下例使用sort(_:)方法对一个String类型的数组进行字母逆序排序 以下是初始数组值:
        let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
        
        //sort(_:)方法需要传入两个参数:
        //(1)已知类型的数组
        //(2)闭包函数 该闭包函数需要传入与数组元素类型相同的两个值 并返回一个布尔类型值来表明当排序结束后传入的第一个参数排在第二个参数前面还是后面 如果第一个参数值出现在第二个参数值前面 排序闭包函数需要返回true 反之返回false
        
        //该例子对一个String类型的数组进行排序 因此排序闭包函数类型需为(String, String) -> Bool:
        func backwards(s1: String, s2: String) -> Bool
        {
            return s1 > s2
        }
        var reversed = names.sort(backwards)
        
        //如果第一个字符串(s1) 大于第二个字符串(s2) backwards函数返回true 表示在新的数组中s1应该出现在s2前 对于字符串中的字符来说"大于"表示"按照字母顺序较晚出现" 这意味着字母"B"大于字母"A" 字符串"Tom"大于字符串"Tim" 其将进行字母逆序排序
        //然而 这是一个相当冗长的方式 本质上只是写了一个单表达式函数(a > b)
        
        
        
        //1.2闭包表达式语法(Closure Expression Syntax)
        
        //闭包表达式语法一般形式:
//        { (parameters) -> returnType in
//                statements
//        }
        
        //闭包表达式语法可以使用常量 变量和inout类型作为参数 不提供默认值 也可以在参数列表的最后使用可变参数 元组也可以作为参数和返回值
        
        //下例展示了之前backwards函数对应的闭包表达式版本的代码:
        reversed = names.sort({ (s1: String, s2: String) -> Bool in
            return s1 > s2
        })
        
        //需要注意的是内联闭包参数和返回值类型声明与backwards函数类型声明相同 在这两种方式中 都写成了(s1: String, s2: String) -> Bool然而在内联闭包表达式中 函数和返回值类型都写在大括号内 而不是大括号外
        
        //闭包的函数体部分由关键字in引入 该关键字表示闭包的参数和返回值类型定义已经完成 闭包函数体即将开始
        
        //sort(_:)方法的整体调用保持不变 一对圆括号仍然包裹住函数中整个参数集合 而其中一个参数现在变成了内联闭包(相比于backwards版本的代码)
        
        
        
        //1.3根据上下文推断类型(Inferring Type From Context)
        
        //因为排序闭包函数是作为sort(_:)方法的参数传入的 Swift可以推断其参数和返回值的类型 sort(_:)方法期望第二个参数是类型为(String, String) -> Bool的函数 因此实际上String String和Bool类型并不需要作为闭包表达式定义中的一部分 因为所有的类型都可以被正确推断 返回箭头(->)和围绕在参数周围的括号也可以被省略:
        reversed = names.sort( { s1, s2 in return s1 > s2 } )
        
        //任何情况下 通过内联闭包表达式构造的闭包作为参数传递给函数时 都可以推断出闭包的参数和返回值类型
        
        //如果完整格式的闭包能够提高代码的可读性 则可以采用完整格式的闭包 而在sort(_:)方法这个例子里 闭包的目的就是排序 能够推测出这个闭包是用于字符串处理的 因为这个闭包是为了处理字符串数组的排序
        
        
        
        //1.4单表达式闭包隐式返回(Implicit Return From Single-Expression Clossures)
        
        //单行表达式闭包可以通过隐藏return关键字来隐式返回单行表达式的结果 上例可以改写为:
        reversed = names.sort( { s1, s2 in s1 > s2 } )
        
        //本例中 sort(_:)方法的第二个参数函数类型明确了闭包必须返回一个Bool类型值 因为闭包函数体只包含了一个单一表达式(s1 > s2) 该表达式返回Bool类型值 因此这里没有歧义 return关键字可以省略
        
        
        
        //1.5参数名称缩写(Shorthand Argument Names)
        
        //Swift自动为内联函数提供了参数名称缩写功能 可以直接通过$0 $1 $2来顺序调用闭包的参数
        
        //如果在闭包表达式中使用参数名称缩写 则可以在闭包参数列表中省略对其的定义 并且对应参数名称缩写的类型会通过函数类型进行推断 in关键字也同样可以被省略 因为此时闭包表达式完全由闭包函数体构成:
        reversed = names.sort( { $0 > $1 } )
        
        
        
        //1.6运算符函数(Operator Functions)
        
        //还有一种更简短的方式来实现上例中的闭包表达式 Swift的String类型定义了关于大于号(>)的字符串实现 其作为一个函数接受两个String类型的参数并返回Bool类型的值 而这正好与sort(_:)方法的第二个参数需要的函数类型相符 因此可以简单地传递一个大于号 Swift可以自动推断出使用大于号的字符串函数实现:
        reversed = names.sort(>)
        print(reversed)
        
        
        
        //2.尾随闭包(Trailing Closures)
        
        //如果需要将一个很长的闭包表达式作为最后一个参数传递给函数 可以使用尾随闭包来增强函数的可读性 尾随闭包是一个书写在函数括号之后的闭包表达式 函数支持将其作为最后一个参数调用:
        func someFunctionThatTakesAClosure(closure: () -> Void)
        {
            //函数体部分
        }
        
        //以下是不使用尾随闭包进行函数调用:
        someFunctionThatTakesAClosure( { /*闭包主体部分*/ } )
        
        //以下是使用尾随闭包进行函数调用:
        someFunctionThatTakesAClosure() { /*闭包主体部分*/ }
        
        //注意:如果函数只需要闭包表达式一个参数 当使用尾随闭包时 甚至可以把()省略掉
        
        //上例中作为sorted函数参数的字符串排序闭包可以改写为:
        reversed = names.sort() { $0 > $1 }
        
        //当闭包非常长以至于不能在一行中进行书写时 尾随闭包变得非常有用:
        let digitNames = [
            0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
            5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
        ]
        let numbers = [16, 58, 510]
        
        //上例创建了一个数字和名字映射的英文版本字典 同时定义了一个准备转换为字符串的整型数组
        
        //现在可以通过传递一个尾随闭包给numbers的map方法来创建对应的字符串版本数组 需要注意的是调用numbers.map不需要在map后面包含任何括号 因为其只需要传递闭包表达式这一个参数 并且该闭包表达式参数通过尾随方式进行:
        let strings = numbers.map
        {
            (var number) -> String in
            var output = ""
            
            while number > 0
            {
                output = digitNames[number % 10]! + output
                number /= 10
            }
            return output
        }
        print(strings)
        
        //闭包number参数被声明为一个变量参数(具体描述请参看常量参数和变量参数) 因此可以在闭包函数体内对其进行修改 闭包表达式制定了返回类型为String 以表明存储映射值的新数组类型为String
        
        //注意:字典digitNames下标后跟着一个叹号(!) 因为字典下标返回一个可选值(optional value) 表明即使该key 不存在也不会查找失败 在上例中 它保证了number % 10可以总是作为一个digitNames字典的有效下标key 因此叹号可以用于强制解析(force-unwrap) 存储在可选下标项中的String类型值
        
        //上例中尾随闭包语法在函数后整洁封装了具体的闭包功能 而不再需要将整个闭包包裹在map函数的括号内
        
        
        
        //3.捕获值(Capturing Values)
        
        //闭包可以在其定义的上下文中捕获常量或变量 即使定义这些常量和变量的原域已经不存在 闭包仍然可以在闭包函数体内引用和修改这些值
        
        //Swift最简单的闭包形式是嵌套函数 也就是定义在其他函数的函数体内的函数 嵌套函数可以捕获其外部函数所有的参数以及定义的常量和变量
        
        //下例定义了一个makeIncrementor函数 其包含了一个incrementor的嵌套函数 嵌套函数incrementor从上下文中捕获了两个值 runningTotal和amount 之后makeIncrementor将incrementor作为闭包返回:
        func makeIncrementor(forIncrement amount: Int) -> () -> Int
        {
            var runningTotal = 0
            
            func incrementor() -> Int
            {
                runningTotal += amount
                return runningTotal
            }
            return incrementor
        }
        
        //makeIncrementor返回类型为() -> Int 这意味着其返回的是一个函数 而不是一个简单类型值 该函数在每次调用时不接受参数只返回一个Int类型的值(关于函数返回其他函数的内容 请查看函数类型作为返回类型)
        
        //如果单独看这个函数 会发现看上去不同寻常:
//        func incrementor() -> Int
//        {
//            runningTotal += amount
//            return runningTotal
//        }
        //incrementor函数并没有任何参数 但是在函数体内访问了runningTotal和amount变量 这是因为其通过捕获在包含它的函数体内已经存在的runningTotal和amount变量的引用(reference)而实现 捕捉了变量引用保证了runningTotal和amount变量在调用完makeIncrementer后不会消失 并且保证了在下一次执行incrementor函数时 runningTotal可以继续增加
        
        //注意:为了优化 Swift可能会捕捉和保存一份对值的拷贝 如果这个值是不可变或是在闭包外的 Swift同样负责被捕捉的所有变量的内存管理 包括释放不被需要的变量
        
        //下例使用了makeIncrementor:
        let incrementByTen = makeIncrementor(forIncrement: 10)
        
        //该例定义了一个叫做incrementByTen的常量 该常量指向一个每次调用会加10的incrementor函数 多次调用这个函数可以得到以下结果:
        print(incrementByTen())
        print(incrementByTen())
        print(incrementByTen())
        
        //如果创建了另一个incrementor 其会有一个属于自己的独立的runningTotal变量的引用 下例中incrementBySevne捕获了一个新的runningTotal变量 该变量和incrementByTen中捕获的变量没有任何联系:
        let incrementBySeven = makeIncrementor(forIncrement: 7)
        print(incrementByTen())
        print(incrementBySeven())
        
        //注意:如果将闭包赋值给一个类实例的属性 并且该闭包通过指向该实例或其成员来捕获了该实例 将创建一个在闭包和实例间的强引用环 Swift使用捕获列表来打破这种强引用环(更多信息请参考闭包引起的循环强引用)
        
        
        
        //4.闭包是引用类型(Closures Are Reference Types)
        
        //上例中incrementBySeven和incrementByTen是常量 但是这些常量指向的闭包仍然可以增加其捕获的变量值 这是因为函数和闭包都是引用类型
        
        //无论将函数/闭包赋值给一个常量还是变量 实际上都是将常量/变量的值设置为对应函数/闭包的引用 上例中incrementByTen指向闭包的引用是一个常量 而并非闭包内容本身
        
        //这也意味着如果将闭包赋值给了两个不同的常量/变量 两个值都会指向同一个闭包:
        let alsoIncrementByTen = incrementByTen
        print(alsoIncrementByTen())
    }
}