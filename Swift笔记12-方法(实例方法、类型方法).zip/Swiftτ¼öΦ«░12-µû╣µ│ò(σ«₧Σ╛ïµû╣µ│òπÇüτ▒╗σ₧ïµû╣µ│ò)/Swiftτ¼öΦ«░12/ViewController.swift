//
//  ViewController.swift
//  Swift笔记12
//
//  Created by apple on 15/12/30.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //方法(Methods)
        
        //方法是与某些特定类型相关联的函数
        //类 结构体 枚举都可以定义实例方法 实例方法为给定类型的实例封装了具体的任务与功能
        //类 结构体 枚举也可以定义类型方法 类型方法与类型本身相关联 类型方法与Objective-C中的类方法(class methods)相似
        
        //结构体和枚举能够定义方法是Swift与C Objective-C的主要区别之一 在Objective-C中类是唯一能定义方法的类型 但在Swift中不仅能创建类型(类/结构体/枚举) 还能灵活的在创建的类型上定义方法⭐️
        
        
        
        //1.实例方法(Instance Methods)
        
        //实例方法是属于某个特定类 结构体或者枚举类型实例的方法 实例方法提供访问和修改实例属性的方法或提供与实例目的相关的功能 并以此来支撑实例的功能 实例方法语法与函数完全一致(具体参见函数)
        
        //实例方法要写在它所属的类型的前后大括号之间 实例方法能够隐式访问它所属类型的所有的其他实例方法和属性 实例方法只能被它所属的类的某个特定实例调用
        
        //下例中Counter类声明了一个可变属性count 还定义了三个实例方法:
        class Counter
        {
            var count = 0
            
            func increment()
            {
                ++count
            }
            
            func incrementBy(amount: Int)
            {
                count += amount
            }
            
            func reset()
            {
                count = 0
            }
        }
        
        //和调用属性一样 用点语法(dot syntax)调用实例方法:
        let counter = Counter()
        counter.increment(); print(counter.count)
        counter.incrementBy(5); print(counter.count)
        counter.reset(); print(counter.count)
        
        
        
        //1.1方法的局部参数名称和外部参数名称(Local and External Parameter Names for Methods)
        
        //函数参数可以同时有一个局部名称:在函数体内部使用 和一个外部名称:在调用函数时使用(详情参见指定外部参数名)
        //方法参数也一样(因为方法就是函数 只是这个函数与某个类型相关联了)
        
        //下例是Counter的另一个版本:
        class CounterNew
        {
            var count: Int = 0
            
            func incrementBy(amount: Int, numberOfTimes: Int)
            {
                count += amount * numberOfTimes
            }
        }
        
        let counter1 = CounterNew()
        counter1.incrementBy(5, numberOfTimes: 3); print(counter1.count)
        
        
        
        //1.2修改方法的外部参数名称(Modifying External Parameter Name Behavior for Methods)
        
        //有时为方法的第一个参数提供一个外部参数名称是非常有用的 尽管这不是默认的行为 
        //可以自行添加一个显式的外部名称或者用一个井号(#)作为第一个参数的前缀来把这个局部名称当作外部名称使用
        
        //相对的 如果不想为方法的第二个及后续的参数提供一个外部名称 可以通过使用下划线(_)作为该参数的显式外部名称
        
        
        
        //1.3self属性(The self Property)
        
        //类型的每一个实例都有一个隐含属性叫做self self完全等同于该实例本身 可以在一个实例的实例方法中使用这个隐含的self属性来引用当前实例
        
        //使用的主要场景是实例方法的某个参数名称与实例的某个属性名称相同的时候 在这种情况下 参数名称享有优先权 并且在引用属性时必须使用一种更严格的方式 这时你可以使用self属性来区分参数名称和属性名称
        
        //下例中self消除方法参数x和实例属性x之间的歧义:
        struct Point
        {
            var x = 0.0, y = 0.0
            
            func isToTheRightOfX(x: Double) -> Bool
            {
                return self.x > x
            }
        }
        
        let somePoint = Point(x: 4.0, y: 5.0)
        if somePoint.isToTheRightOfX(1.0)
        {
            print("This point is to the right of the line where x == 1.0")
        }
        
        
        
        //1.4在实例方法中修改值类型(Modifying Value Types from Within Instance Methods)
        
        //结构体和枚举是值类型 一般情况下 值类型的属性不能在它的实例方法中被修改
        //但是 如果确实需要在某个具体的方法中修改结构体或者枚举的属性 可以选择变异(mutating)方法 然后方法就可以从方法内部改变它的属性 并且它做的任何改变在方法结束时还会保留在原始结构中 方法还可以给它隐含的self属性赋值一个全新的实例 这个新实例在方法结束后将替换原来的实例
        struct PointNew
        {
            var x = 0.0, y = 0.0
            
            mutating func moveByXY(x x: Double, y: Double)
            {
                self.x += x
                self.y += y
            }
        }
        var somePoint1 = PointNew(x: 1.0, y: 1.0)
        somePoint1.moveByXY(x: 2.0, y: 3.0)
        print("The point is now at (\(somePoint1.x), \(somePoint1.y))")
        
        //注意:不能在结构体类型常量上调用变异方法 因为常量的属性不能被改变 即使想改变的是常量的变量属性也不行(详情参见存储属性和实例变量)
//        let fixedPoint = PointNew(x: 1.0, y: 1.0)
//        fixedPoint.moveByXY(x: 2.0, y: 3.0) //这里会提示一个错误
        
        
        
        //1.5在变异方法中给self赋值(Assigning to self Within a Mutating Method)
        
        //变异方法能够赋给隐含属性self一个全新的实例 上面PointNew的例子可以用下面的方式改写:
        struct PointNewAnother
        {
            var x = 0.0, y = 0.0
            
            mutating func moveByXY(deltaX: Double, deltaY: Double)
            {
                self = PointNewAnother(x: x + deltaX, y: y + deltaY)
            }
        }
        
        //枚举的变异方法可以把self设置为相同的枚举类型中不同的成员:
        enum StateSwitch
        {
            case Off, Low, High
            
            mutating func next()
            {
                switch self
                {
                case Off:
                    self = Low
                case Low:
                    self = High
                case High:
                    self = Off
                }
            }
        }
        
        var ovenLight = StateSwitch.Low
        ovenLight.next() //ovenLight现在等于.High
        ovenLight.next() //ovenLight现在等于.Off
        
        
        
        //2.类型方法(Type Methods)
        
        //实例方法是被类型的某个实例调用的方法 也可以定义类型本身调用的方法 这种方法叫做类型方法
        //声明结构体和枚举的类型方法 在方法的func关键字之前加上关键字static 类可能会用关键字class来允许子类重写父类的实现方法
        
        //注意:在Objective-C中只能为类定义类型方法(type-level methods) 在Swift中可以为所有的类 结构体 枚举定义类型方法:每一个类型方法都被它所支持的类型显式包含
        
        //类型方法和实例方法一样用点语法调用:
        class SomeClass
        {
            static func someTypeMethod()
            {
                //type method implementation goes here
            }
        }
        
        SomeClass.someTypeMethod()
        
        //在类型方法的方法体(body)中 self指向这个类型本身 而不是类型的某个实例 对于结构体和枚举来说 这意味着可以用self来消除静态属性和静态方法参数之间的歧义(类似于前面处理实例属性和实例方法参数)
        
        //一个类型方法可以调用本类中另一个类型方法的名称 而无需在方法名称前面加上类型名称的前缀
        //同样 类型方法也能够直接通过静态属性的名称访问静态属性 而无需类型名称前缀:
        struct LevelTracker
        {
            static var highestUnlockedLevel = 1 //静态属性
            
            static func unlockLevel(level: Int)
            {
                if level > highestUnlockedLevel { highestUnlockedLevel = level }
            }
            
            static func levelIsUnlocked(level: Int) -> Bool
            {
                return level <= highestUnlockedLevel
            }
            
            var currentLevel = 1 //实例属性
            
            mutating func advanceToLevel(level: Int) -> Bool
            {
                if LevelTracker.levelIsUnlocked(level)
                {
                    currentLevel = level
                    return true
                }
                else
                {
                    return false
                }
            }
        }
        
        //Player类使用LevelTracker来监测和更新每个玩家的发展进度:
        class Player
        {
            let playerName: String
            var tracker = LevelTracker()
            
            func completedLevel(level: Int)
            {
                LevelTracker.unlockLevel(level + 1) //调用类型方法
                tracker.advanceToLevel(level + 1)   //调用实例方法
            }
            
            init(name: String)
            {
                playerName = name
            }
        }
        
        //为一个新的玩家创建一个Player的实例 然后看这个玩家完成等级1时发生了什么:
        var player = Player(name: "Argyrios")
        player.completedLevel(1)
        print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")
        
        //创建第二个玩家 并尝试让其开始一个没有被任何玩家解锁的等级 则本次设置玩家当前等级会失败:
        player = Player(name: "Beto")
        if player.tracker.advanceToLevel(6)
        {
            print("player is now on level 6")
        }
        else
        {
            print("level 6 has not yet been unlocked")
        }
    }
}