//
//  File.swift
//  Swift笔记22
//
//  Created by apple on 16/1/7.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
extension Double
{
    var km: Double { return self * 1_000.0 }
    var m : Double { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}

//代码2
struct Size
{
    var width = 0.0, height = 0.0
}

struct Point
{
    var x = 0.0, y = 0.0
}

struct Rect
{
    var origin = Point()
    var size = Size()
}

//代码3
extension Rect
{
    init(center: Point, size: Size)
    {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

//代码4
extension Int
{
    func repetitions(task: () -> ())
    {
        for _ in 0..<self
        {
            task()
        }
    }
}

//repetitions方法使用了一个() -> ()类型的单参数 表明函数没有参数而且没有返回值

//代码5
extension Int
{
    mutating func square()
    {
        self *= self
    }
}

//结构体和枚举类型中修改self或其属性的方法必须将该实例方法标注为mutating 和原始实现的修改方法一样

//代码6
extension Int
{
    subscript(digitIndex: Int) -> Int
    {
        var decimalBase = 1
        var index = digitIndex
        
        while index > 0
        {
            decimalBase *= 10
            index -= 1
        }
        return (self / decimalBase) % 10
    }
}

//代码7
extension Int
{
    enum Kind
    {
        case Negative, Zero, Positive
    }
    
    var kind: Kind
    {
        switch self
        {
            case 0:
                return .Zero
            case let x where x > 0:
                return .Positive
            default:
                return .Negative
        }
    }
}