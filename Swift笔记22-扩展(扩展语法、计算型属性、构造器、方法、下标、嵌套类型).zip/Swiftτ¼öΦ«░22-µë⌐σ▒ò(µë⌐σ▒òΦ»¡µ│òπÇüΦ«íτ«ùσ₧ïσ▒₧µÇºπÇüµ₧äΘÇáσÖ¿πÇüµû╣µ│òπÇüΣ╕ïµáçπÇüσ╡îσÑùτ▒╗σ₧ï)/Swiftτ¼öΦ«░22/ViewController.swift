//
//  ViewController.swift
//  Swift笔记22
//
//  Created by apple on 16/1/7.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //扩展(Extensions)
        
        //扩展就是向一个已有的类 结构体 枚举类型或者协议类型添加新功能 包括在没有权限获取源代码的情况下扩展类型的能力(即逆向建模) 扩展和Objective-C中的类别(categories)类似 (不过Swift的扩展没有名字)
        
        //Swift的扩展可以是:
        //添加计算型属性和计算型类型属性
        //定义实例方法和类型方法
        //提供新的构造器
        //定义下标
        //定义和使用新的嵌套类型
        //使一个已有类型符合某个协议
        
        //在Swift中 甚至可以对一个协议(Procotol)进行扩展 提供协议需要的实现 或者添加额外的功能能够对合适的类型带来额外的作用(具体参见协议扩展)
        
        //注意:扩展可以对一个类型添加新的功能 但是不能重写已有的功能
        
        
        
        //1.扩展语法(Extension Syntax)
        
        //声明一个扩展使用关键字extension:
//        extension SomeType
//        {
//            //加到SomeType的新功能写到这里
//        }
        
        //可以扩展一个已有类型 使其能够适配一个或多个协议(protocol) 当这种情况发生时 协议的名字应该完全按照类或结构体的名字的方式进行书写:
//        extension SomeType: SomeProtocol, AnotherProctocol
//        {
//            //协议实现写到这里
//        }
        //按照这种方式添加的协议遵循者(protocol conformance)被称之为在扩展中添加协议遵循者
        
        //注意:如果定义了一个扩展向一个已有类型添加新功能 那么这个新功能对该类型的所有已有实例都是可用的 即使它们是在这个扩展的前面定义的
        
        
        
        //2.计算型属性(Computed Properties)
        
        //扩展可以向已有类型添加计算型实例属性和计算型类型属性:
        
        //⭐️代码1在File文件里⭐️
        
        let oneInch = 25.4.mm
        print("One inch is \(oneInch) meters")
        
        let threeFeet = 3.ft
        print("Three feet is \(threeFeet) meters")
        
        let aMarathon = 42.km + 195.m
        print("A marathon is \(aMarathon) meters long")
        
        //注意:扩展可以添加计算属性 但是不能添加存储属性 也不能向已有属性添加属性观察器(property observers)
        
        
        
        //3.构造器(Initializers)
        
        //扩展能向类中添加新的便利构造器 但是不能向类中添加新的指定构造器或析构器 指定构造器和析构器必须总是由原始的类实现来提供
        
        //注意:如果使用扩展向一个值类型添加一个构造器 在该值类型已经向所有的存储属性提供默认值 而且没有定义任何定制构造器时 可以在值类型的扩展构造器中调用默认构造器和逐一成员构造器
            
        //正如在值类型的构造器代理中描述的 如果已经把构造器写成值类型原始实现的一部分 上述规则不再适用
        
        //⭐️代码2在File文件里⭐️
        
        //因为结构体Rect提供了其所有属性的默认值 所以正如默认构造器中描述的:它可以自动接受一个默认构造器和一个逐一成员构造器 这些构造器可以用于构造新的Rect实例:
        let defaultRect = Rect()
        let memberwiseRect = Rect(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))
        
        //可以提供一个额外的使用特殊中心点和大小的构造器来扩展Rect结构体:
        
        //⭐️代码3在File文件里⭐️
        
        let centerRect = Rect(center: Point(x: 4.0, y:4.0), size: Size(width: 3.0, height: 3.0))
        
        //注意:如果使用扩展提供了一个新的构造器 依旧要保证构造过程能够让所有实例完全初始化
        
        
        
        //4.方法(Methods)
        
        //扩展可以向已有类型添加新的实例方法和类型方法:
        
        //⭐️代码4在File文件里⭐️
        
        //定义该扩展后 就可以对任意整数调用repetitions方法:
        3.repetitions({ print("Hello!") })
        
        //可以使用trailing闭包使调用更加简洁:
        3.repetitions{ print("Goodbye!") }
        
        
        
        //4.1修改实例方法(Mutating Instance Methods)
        
        //通过扩展添加的实例方法也可以修改该实例本身:
        
        //⭐️代码5在File文件里⭐️
        
        var someInt = 3
        someInt.square()
        print(someInt)
        
        
        
        //5.下标(Subscripts)
        
        //扩展可以向一个已有类型添加新下标:
        
        //⭐️代码6在File文件里⭐️
        print(746381295[0], 746381295[1], 746381295[2], 746381295[8])
        
        //如果该Int值没有足够的位数 即下标越界 那么上述实现的下标会返回0 因为它会在数字左边自动补0:
        print(746381295[9], 0746381295[9])
        
        
        
        //6.嵌套类型(Nested Types)
        
        //扩展可以向已有的类 结构体和枚举添加新的嵌套类型:
        
        //⭐️代码7在File文件里⭐️
        
        func printIntegerKinds(numbers: [Int])
        {
            for number in numbers
            {
                switch number.kind
                {
                case .Negative:
                    print("- ", terminator: "")
                case .Zero:
                    print("0 ", terminator: "")
                default:
                    print("+ ", terminator: "")
                }
            }
        }
        
        printIntegerKinds([3, 19, -27, 0, -6, 0, 7])
        
        //注意:由于已知number.kind是Int.Kind类型 所以Int.Kind中的所有成员值都可以使用switch语句里的形式简写 比如使用.Negative代替Int.Kind.Negative
    }
}