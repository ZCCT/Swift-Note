//
//  ViewController.swift
//  Swift笔记01
//
//  Created by apple on 15/12/17.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //1.声明常量和变量
        
//        let maximumNumberOfLoginAttempts = 10
//        var currentLoginAttempt = 0
//        var x = 0, y = 0, z = 0
        
        
        
        //2.类型标注(type annotation)
        
        //一般很少需要写类型标注 如果在声明常量或者变量的时候赋了一个初始值 Swift可以推断出这个常量或者变量的类型
//        var welcomeMessage: String
//        welcomeMessage = "Hello"
//        var red, green, blue: Double
        
        
        
        //3.常量和变量的命名
        
        //可以用任何字符作为常量和变量名 包括Unicode字符
        //常量与变量名不能包含数学符号 箭头 保留的(或者非法的)Unicode码位 连线与制表符
        //也不能以数字开头 但是可以在常量与变量名的其他地方包含数字
//        let π = 3.14159
//        let 🐶🐮 = "DogCow"
//        var friendlyWelcome = "Hello!"
//        friendlyWelcome = "Bonjour!"
//        print(friendlyWelcome)
        
        
        
        //4.print(_:separator:terminator:)是一个用来输出一个或多个值到适当输出区的全局函数
        
        //separator和terminator参数具有默认值 调用这个函数的时候可以忽略 默认该函数通过添加换行符来结束当前行
        //如果不想换行 可以传递一个空字符串给terminator参数 例如:print(someValue, terminator:"")
        //关于参数默认值的更多信息 请参考默认参数值
//        let languageName = "Swift"
//        print(languageName, terminator:"")
//        print("111")
        
        
        
        //5.Swift用字符串插值(string interpolation)的方式把常量名或者变量名当做占位符加入到长字符串中
        
        //Swift会用当前常量或变量的值替换这些占位符 将常量或变量名放入圆括号中 并在括号前使用反斜杠将其转义
//        var friendlyWelcome = "Bonjour!"
//        print("The current value of friendlyWelcome is \(friendlyWelcome)")
        
        
        
        //6.注释
        
        //这是一个单行注释
        
        /*这是一个
        多行注释*/
        
        /*这是第一个多行注释的开头
        /*这是第二个被嵌套的多行注释*/
        这是第一个多行注释的结尾*/
        
        
        
        //7.分号
        
        //Swift不强制要求在每条语句的结尾处使用分号(;) 但也可以按照习惯添加分号
        //有一种情况下必须要用分号:在同一行内写多条独立的语句
//        let cat = "🐱"; print(cat)
        
        
        
        //8.整数
        
        //Swift提供8 16 32和64位的有符号和无符号整数类型
        //这些整数类型和C语言的命名方式很像 比如8位无符号整数类型是UInt8 32位有符号整数类型是Int32
        //就像Swift的其他类型一样 整数类型采用大写命名法
        
        //整数范围:可以访问不同整数类型的min和max属性来获取对应类型的最小值和最大值
        //min和max所传回值的类型 正是其所对的整数类型(如下例UInt8 所传回的类型是UInt8)
//        print(UInt8.min, UInt8.max)
        
        //一般不需要专门指定整数的长度
        //Swift提供了一个特殊的整数类型Int 长度与当前平台的原生字长相同
        //在32位平台上:Int和Int32长度相同 在64位平台上:Int和Int64长度相同
        //Swift也提供了一个特殊的无符号整数类型UInt 长度与当前平台的原生字长相同
        //在32位平台上:UInt和UInt32长度相同 在64位平台上:UInt和UInt64长度相同
        
        //尽量不要使用UInt 除非真的需要存储一个和当前平台原生字长相同的无符号整数
        //除了这种情况 最好使用Int 即使要存储的值已知是非负的
        //统一使用Int可以提高代码复用度 避免不同类型数字之间的转换 并且匹配数字的类型推断 请参考类型安全和类型推断
        
        
        
        //9.浮点数
        
        //浮点类型比整数类型表示的范围更大 可以存储比Int类型更大或者更小的数字
        //Swift提供两种有符号浮点数类型
        //Double表示64位浮点数 当需要存储很大或者很高精度的浮点数时请使用此类型
        //Float表示32位浮点数 精度要求不高的话可以使用此类型
        //Double精度很高:至少有15位数字 Float最少只有6位数字 选择哪个类型取决于需要处理的值的范围
        
        
        
        //10.类型安全与类型推断
        
        //Swift是一个类型安全(type safe)的语言 它会在编译代码时进行类型检查(type checks) 并把不匹配的类型标记为错误
        //当要处理不同类型的值时 类型检查可以避免错误 这并不是说每次声明常量和变量的时候都需要显式指定类型
        //如果没有显式指定类型 Swift会使用类型推断(type inference)来选择合适的类型
        //有了类型推断 编译器可以在编译代码的时候自动推断出表达式的类型 原理很简单:只要检查赋值即可
        
        //meaningOfLife会被推测为Int类型
//        let meaningOfLife = 42
        
        //π会被推测为Double类型
//        let π = 3.14159
        
        //当推断浮点数的类型时 Swift总是会选择Double而不是Float
        //如果表达式中同时出现了整数和浮点数 会被推断为Double类型
        
        
        
        //11.数值型字面量
        
        //整数字面量可以被写作
        //十进制数:没有前缀 二进制数:前缀是0b 八进制数:前缀是0o 十六进制数:前缀是0x
        
        //下面所有的整数字面量的十进制值都是17:
//        let decimalInteger = 17
//        let binaryInteger = 0b10001       // 二进制的17
//        let octalInteger = 0o21           // 八进制的17
//        let hexadecimalInteger = 0x11     // 十六进制的17
        
        //浮点字面量可以是十进制(没有前缀) 或者是十六进制(前缀是0x) 小数点两边必须有至少一个十进制数字(或者是十六进制的数字)
        //浮点字面量还有一个可选的指数(exponent) 在十进制浮点数中通过大写或者小写的e来指定 在十六进制浮点数中通过大写或者小写的p来指定
        
        //如果一个十进制数的指数为exp 那这个数相当于基数和10^exp的乘积
        //1.25e2 表示1.25×10^2 等于125.0
        //1.25e-2 表示1.25×10^-2 等于0.0125
        
        //如果一个十六进制数的指数为exp 那这个数相当于基数和2^exp的乘积
        //0xFp2 表示15×2^2 等于60.0
        //0xFp-2 表示15×2^-2 等于3.75
        
        //下面这些浮点字面量都等于十进制的12.1875:
//        let decimalDouble = 12.1875
//        let exponentDouble = 1.21875e1
//        let hexadecimalDouble = 0xC.3p0 //0xC.3p0 = (12 + 3/16) * 2^0 = 12.1875
        
        //数值类字面量可以包括额外的格式来增强可读性 整数和浮点数都可以添加额外的零并且包含下划线:
//        let paddedDouble = 000123.456
//        let oneMillion = 1_000_000
//        let justOverOneMillion = 1_000_000.000_000_1
        
        
        
        //12.数值型类型转换
        
        //整数转换
        //不同整数类型的变量和常量可以存储不同范围的数字 由于每种整数类型都可以存储不同范围的值 所以必须根据不同情况选择性使用数值型类型转换:
//        let twoThousand: UInt16 = 2_000
//        let one: UInt8 = 1
//        let twoThousandAndOne = twoThousand + UInt16(one)
        
        //整数和浮点数转换(必须显式指定类型)
//        let three = 3
//        let pointOneFourOneFiveNine = 0.14159
//        let π = Double(three) + pointOneFourOneFiveNine
//        let integerπ = Int(π)
        
        
        
        //13.类型别名(type aliases)
        
        //当想要给现有类型起一个更有意义的名字时 类型别名非常有用:
//        typealias AudioSample = UInt8
//        var maxAmplitudeFound = AudioSample.max
        
        
        
        //14.布尔值
        //Swift有一个基本的布尔(Boolean)类型 叫做Bool 布尔值指逻辑上的值 因此它们只能是真或假
        //Swift有两个布尔常量:true false
    }
}