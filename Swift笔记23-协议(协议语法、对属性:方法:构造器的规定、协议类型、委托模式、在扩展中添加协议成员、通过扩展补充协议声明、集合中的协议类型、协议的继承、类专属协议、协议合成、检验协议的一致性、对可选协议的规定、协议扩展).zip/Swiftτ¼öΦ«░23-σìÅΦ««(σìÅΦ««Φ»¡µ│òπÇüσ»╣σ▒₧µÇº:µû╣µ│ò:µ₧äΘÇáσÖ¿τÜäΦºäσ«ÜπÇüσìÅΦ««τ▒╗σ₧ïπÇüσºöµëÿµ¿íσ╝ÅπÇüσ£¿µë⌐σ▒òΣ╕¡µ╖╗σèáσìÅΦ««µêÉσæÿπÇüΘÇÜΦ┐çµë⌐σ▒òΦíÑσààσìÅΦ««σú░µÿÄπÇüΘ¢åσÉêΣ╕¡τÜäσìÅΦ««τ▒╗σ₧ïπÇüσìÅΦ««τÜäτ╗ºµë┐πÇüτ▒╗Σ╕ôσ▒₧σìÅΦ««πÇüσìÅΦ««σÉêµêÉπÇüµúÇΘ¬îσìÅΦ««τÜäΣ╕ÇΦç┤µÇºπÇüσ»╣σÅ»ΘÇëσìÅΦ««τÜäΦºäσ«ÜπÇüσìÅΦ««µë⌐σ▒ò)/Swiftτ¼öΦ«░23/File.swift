//
//  File.swift
//  Swift笔记23
//
//  Created by apple on 16/1/8.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
protocol FullyNamed
{
    var fullName: String { get }
}

//FullyNamed协议除了要求协议的遵循者提供fullName属性外 对协议遵循者的类型并没有特别的要求
//这个协议表示:任何遵循FullyNamed协议的类型 都具有一个可读的String类型实例属性fullName

//代码2
protocol RandomNumberGenerator
{
    func random() -> Double
}

class LinearCongruentialGenerator: RandomNumberGenerator
{
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0
    
    func random() -> Double
    {
        lastRandom = ((lastRandom * a + c) % m)
        return lastRandom / m
    }
}

//代码3
protocol Togglable
{
    mutating func toggle()
}

//代码4
class Dice
{
    let sides: Int
    let generator: RandomNumberGenerator
    
    init(sides: Int, generator: RandomNumberGenerator)
    {
        self.sides = sides
        self.generator = generator
    }
    
    func roll() -> Int
    {
        return Int(generator.random() * Double(sides)) + 1
    }
}

//generator属性的类型为RandomNumberGenerator 因此任何遵循了该协议的类型的实例都可以赋值给generator

//代码5
protocol DiceGame
{
    var dice: Dice { get }
    func play()
}

protocol DiceGameDelegate
{
    func gameDidStart(game: DiceGame)
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int)
    func gameDidEnd(game: DiceGame)
}

class SnakesAndLadders: DiceGame
{
    let finalSquare = 25
    let dice = Dice(sides: 6, generator: LinearCongruentialGenerator())
    var square = 0
    var board: [Int]
    
    init()
    {
        board = [Int](count: finalSquare + 1, repeatedValue: 0)
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
    }
    var delegate: DiceGameDelegate?
    
    func play()
    {
        square = 0
        delegate?.gameDidStart(self)
        gameLoop: while square != finalSquare
        {
            let diceRoll = dice.roll()
            delegate?.game(self,didStartNewTurnWithDiceRoll: diceRoll)
            switch square + diceRoll
            {
            case finalSquare:
                break gameLoop
            case let newSquare where newSquare > finalSquare:
                continue gameLoop
            default:
                square += diceRoll
                square += board[square]
            }
        }
        delegate?.gameDidEnd(self)
    }
}

//SnakesAndLadders类遵循了DiceGame协议 并且提供了相应的可读的dice属性和play实例方法(dice属性在构造之后就不再改变 且协议要求dice为只读的 因此将dice声明为常量属性)

//注意:delegate并不是游戏的必备条件 因此delegate被定义为遵循DiceGameDelegate协议的可选属性 因此在初始化的时候被自动赋值为nil 之后可以在游戏中为delegate设置适当的值

//因为delegate是一个遵循DiceGameDelegate协议的可选属性 因此在play()方法中使用了可选链来调用委托方法 若delegate属性为nil 则delegate调用的方法失效 并不会产生错误 若delegate不为nil则方法能够被调用

//代码6
protocol TextRepresentable
{
    func asText() -> String
}

//代码7
extension Dice: TextRepresentable
{
    func asText() -> String
    {
        return "A \(sides)-sided dice"
    }
}

//通过扩展使得Dice类型遵循了一个新的协议 这和Dice类型在定义的时候声明为遵循TextRepresentable协议的效果相同 在扩展的时候 协议名称写在类型名之后 以冒号(:)隔开 在大括号内写明新添加的协议内容

//代码8
extension SnakesAndLadders: TextRepresentable
{
    func asText() -> String
    {
        return "A game of Snakes and Ladders with \(finalSquare) squares"
    }
}

//代码9
struct Hamster
{
    var name: String
    
    func asText() -> String
    {
        return "A hamster named \(name)"
    }
}

extension Hamster: TextRepresentable {}

//代码10
protocol PrettyTextRepresentable: TextRepresentable
{
    func asPrettyText() -> String
}

//本例中定义了一个新的协议PrettyTextRepresentable 它继承自TextRepresentable协议
//任何遵循PrettyTextRepresentable协议的类型在满足该协议的要求时 也必须满足TextRepresentable协议的要求
//本例中PrettyTextRepresentable协议要求其遵循者提供一个返回值为String类型的asPrettyText方法

//代码11
extension SnakesAndLadders: PrettyTextRepresentable
{
    func asPrettyText() -> String
    {
        var output = asText() + ":\n"
        
        for index in 1...finalSquare
        {
            switch board[index]
            {
            case let ladder where ladder > 0:
                output += "▲ "
            case let snake where snake < 0:
                output += "▼ "
            default:
                output += "○ "
            }
        }
        return output
    }
}

//上述扩展使得SnakesAndLadders遵循了PrettyTextRepresentable协议 并为每个SnakesAndLadders类型的实例提供了协议要求的asPrettyText()方法
//每个PrettyTextRepresentable类型的实例同时也是TextRepresentable类型 所以在asPrettyText的实现中 可以调用asText()方法

//代码12
protocol Named
{
    var name: String { get }
}

protocol Aged
{
    var age: Int { get }
}

//代码13
protocol HasArea
{
    var area: Double { get }
}

//代码14
@objc protocol CounterDataSource
{
    optional func incrementForCount(count: Int) -> Int
    optional var fixedIncrement: Int { get }
}
//注意:CounterDataSource中的属性和方法都是可选的 因此可以在类中声明都不实现这些成员 尽管技术上允许这样做 不过最好不要这样写

//代码15
extension RandomNumberGenerator
{
    func randomBool() -> Bool
    {
        return random() > 0.5
    }
}

//代码16
extension PrettyTextRepresentable
{
    func asPrettyText() -> String
    {
        return asText()
    }
}

//代码17
extension CollectionType where Generator.Element : TextRepresentable
{
    func asList() -> String
    {
        return "YES"
    }
}