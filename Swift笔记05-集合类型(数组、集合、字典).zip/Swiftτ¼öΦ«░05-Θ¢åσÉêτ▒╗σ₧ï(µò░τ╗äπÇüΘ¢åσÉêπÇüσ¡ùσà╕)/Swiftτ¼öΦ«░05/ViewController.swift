//
//  ViewController.swift
//  Swift笔记05
//
//  Created by apple on 15/12/21.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //1.集合类型(Collection Types)
        
        //Swift语言提供Arrays(数组) Sets(集合) Dictionaries(字典)三种基本的集合类型用来存储集合数据
        //数组是有序数据的集 集合是无序无重复数据的集 字典是无序的键值对的集
        
        //Swift的Arrays Sets Dictionaries中存储的数据值类型必须明确 这意味着不能把不正确的数据类型插入其中
        
        //Swift的Arrays Sets Dictionaries类型被实现为泛型集合
        
        
        
        //1.1集合的可变性
        
        //如果创建一个Arrays Sets Dictionaries并且把它分配成一个变量 这个集合将会是可变的 这意味着可以在创建之后添加更多或移除已存在的数据项来改变这个集合的大小 如果把Arrays Sets Dictionaries分配成常量 那么它就是不可变的 不能被改变
        
        //注意:在不需要改变集合大小的时候创建不可变集合是很好的习惯 如此Swift编译器可以优化创建的集合
        
        
        
        //1.2数组(Arrays)
        
        //数组使用有序列表存储同一类型的多个值 相同的值可以多次出现在一个数组的不同位置中
        
        //注意:Swift的Array类型被桥接到Foundation中的NSArray类 更多关于在Foundation和Cocoa中使用Array的信息参见Using Swift with Cocoa and Obejective-C一书
        
        //1.2.1数组的简单语法
        
        //Swift数组应该遵循像Array<Element>这样的形式 其中Element是这个数组中唯一允许存在的数据类型 也可以使用像[Element]这样的简单语法 尽管两种形式在功能上是一样的 但是推荐较短的那种
        
        //1.2.2创建一个空数组
        
        //可以使用构造语法来创建一个由特定数据类型构成的空数组:
        var someInts = [Int]()
        print("someInts is of type [Int] with \(someInts.count) items.")
        //注意:通过构造函数的类型 someInts的值类型被推断为[Int]
        
        //或者 如果代码上下文中已经提供了类型信息 例如:一个函数参数或者一个已经定义好类型的常量或者变量 就可以使用空数组语句创建一个空数组 它的写法很简单:[]:
        someInts.append(3) //someInts现在包含一个Int值
        someInts = [] //someInts现在是空数组 但仍是[Int]类型的
        
        //1.2.3创建一个带有默认值的数组
        
        //Swift中的Array类型还提供一个可以创建特定大小并且所有数据都被默认的构造方法 可以把准备加入新数组的数据项数量(count)和适当类型的初始值(repeatedValue)传入数组构造函数:
        let threeDoubles = [Double](count: 3, repeatedValue: 0.0)
        //threeDoubles是一种[Double]数组 等价于[0.0, 0.0, 0.0]
        
        //1.2.4通过两个数组相加创建一个数组
        
        //可以使用加法操作符(+)来组合两种已存在的相同类型数组 新数组的数据类型会被从两个数组的数据类型中推断出来:
        let anotherThreeDoubles = Array(count: 3, repeatedValue: 1.0)
        let sixDoubles = threeDoubles + anotherThreeDoubles
        print(sixDoubles)
        //sixDoubles被推断为[Double] 等价于[0.0, 0.0, 0.0, 1.0, 1.0, 1.0]
        
        //1.2.5用字面量构造数组
        
        //可以使用字面量来进行数组构造 这是一种用一个或者多个数值构造数组的简单方法 字面量是一系列由逗号分割并由方括号包含的数值
        //下面这个例子创建了一个叫做shoppingList并且存储String的数组:
        var shoppingList: [String] = ["Eggs", "Milk"]
        //shoppingList变量被声明为"字符串值类型的数组" 记作[String] 因为这个数组被规定只有String一种数据结构 所以只有String类型可以在其中被存取 在这里 shoppinglist数组由两个String值("Eggs" "Milk")构造 并且由字面量定义
        //在这个例子中 字面量仅仅包含两个String值 匹配了该数组的变量声明(只能包含String的数组) 所以这个字面量的分配过程可以作为用两个初始项来构造shoppinglist的一种方式
        
        //由于Swift的类型推断机制 当用字面量构造只拥有相同类型值数组的时候 不必把数组的类型定义写清楚:
//        var anotherShoppingList = ["Eggs", "Milk"]
        //因为所有字面量中的值都是相同的类型 Swift可以推断出[String]是anotherShoppingList中变量的正确类型
        
        
        
        //1.2.6访问和修改数组
        
        //可以通过数组的方法和属性来访问和修改数组 或者使用下标语法
        
        //可以使用数组的只读属性count来获取数组中的数据项数量:
        print("The shopping list contains \(shoppingList.count) items.")
        
        //使用布尔值属性isEmpty作为检查count属性的值是否为0的捷径:
        if shoppingList.isEmpty
        {
            print("The shopping list is empty.")
        }
        else
        {
            print("The shopping list is not empty.")
        }
        
        //也可以使用append(_:)方法在数组后面添加新的数据项:
        shoppingList.append("Flour")
        print(shoppingList.count)
        
        //除此之外 使用加法赋值运算符(+=)也可以直接在数组后面添加一个或多个拥有相同类型的数据项:
        shoppingList += ["Baking Powder"]
        shoppingList += ["Chocolate Spread", "Cheese", "Butter"]
        print(shoppingList.count)
        
        //可以直接使用下标语法来获取数组中的数据项 把需要的数据项的索引值直接放在数组名称的方括号中:
        var firstItem = shoppingList[0]
        print(firstItem)
        //注意:第一项在数组中的索引值是0而不是1 Swift中的数组索引总是从零开始
        
        //也可以用下标来改变某个已有索引值对应的数据值:
        shoppingList[0] = "Six eggs"
        print(shoppingList[0])
        
        //还可以利用下标来一次改变一系列数据值 即使新数据和原有数据的数量是不一样的 下面的例子把"Chocolate Spread" "Cheese" 和"Butter"替换为"Bananas"和 "Apples":
        shoppingList[4...6] = ["Bananas", "Apples"]
        print(shoppingList.count)
        //注意:不可以用下标访问的形式在数组尾部添加新项
        
        //调用数组的insert(_:atIndex:)方法来在某个具体索引值之前添加数据项:
        shoppingList.insert("Maple Syrup", atIndex: 0)
        print(shoppingList.count)
        print(shoppingList[0])
        //这次insert(_:atIndex:)方法调用把值为"Maple Syrup"的新数据项插入列表的最开始位置 并且使用0作为索引值
        
        //类似的也可以使用removeAtIndex(_:)方法来移除数组中的某一项 这个方法把数组在特定索引值中存储的数据项移除并且返回这个被移除的数据项(不需要的时候就可以无视它):
        let mapleSyrup = shoppingList.removeAtIndex(0)
        print(mapleSyrup)
        //索引值为0的数据项被移除
        //mapleSyrup常量的值等于被移除数据项的值"Maple Syrup"
        //注意:如果对索引越界的数据进行检索或者设置新值的操作 会引发一个运行时错误 在使用某个索引之前先检验是否有效 可以使用索引值和数组的count属性进行比较
        
        //数据项被移除后数组中的空项会被自动填补 所以现在索引值为0的数据项的值再次等于"Six eggs":
        firstItem = shoppingList[0]
        print(firstItem)
        //如果只想把数组中的最后一项移除 可以使用removeLast()方法而不是removeAtIndex(_:)方法来避免获取数组的count属性 就像后者一样 前者也会返回被移除的数据项:
        let apples = shoppingList.removeLast()
        print(apples)
        
        
        
        //1.2.7数组的遍历
        
        //可以使用for-in循环来遍历所有数组中的数据项:
        for item in shoppingList
        {
            print(item)
        }
        
        //如果同时需要每个数据项的值和索引值 可以使用enumerate()方法来进行数组遍历 enumerate()返回一个由每一个数据项索引值和数据值组成的元组 可以把这个元组分解成临时常量或者变量来进行遍历:
        for (index, value) in shoppingList.enumerate()
        {
            print("Item \(String(index + 1)): \(value)")
        }
        
        
        
        //1.3集合(Set)
        
        //集合(Set)用来存储相同类型并且没有确定顺序的值 当集合元素顺序不重要时或者希望确保每个元素只出现一次时可以使用集合而不是数组
        
        //注意:Swift的Set类型被桥接到Fundation中的NSSet类 更多关于在Fundation和Cocoa中使用Set的信息 参见Using Swift with Cocoa and Obejective-C一书
        
        //集合类型的哈希值:一个类型为了存储在集合中 该类型必须是可哈希化的
        //也就是说该类型必须提供一个方法来计算它的哈希值 一个哈希值是Int类型的 相等的对象哈希值必须相同 比如a==b 因此必须a.hashValue == b.hashValue
        
        //Swift的所有基本类型(比如String Int Double Bool)默认都是可哈希化的 可以作为集合的值的类型或者字典的键的类型 没有关联值的枚举成员值(在枚举有讲述)默认也是可哈希化的
        
        //注意:可以使用自定义的类型作为集合的值的类型或者是字典的键的类型 但需要使自定义类型符合Swift标准库中的Hashable协议 符合Hashable协议的类型需要提供一个类型为Int的可读属性hashValue 由类型的hashValue属性返回的值不需要在同一程序的不同执行周期或者不同程序之间保持相同
        
        //因为hashable协议符合Equatable协议 所以符合该协议的类型也必须提供一个"是否相等"运算符(==)的实现 这个Equatable协议要求任何符合==实现的实例间都是一种相等的关系
        //也就是说 对于a b c三个值来说 ==的实现必须满足下面三种情况:
        //a == a(自反性)
        //a == b 意味着 b == a(对称性)
        //a == b && b == c 意味着 a == c(传递性)
        //关于协议的更多信息 请看协议
        
        
        
        //1.3.1集合类型语法
        
        //Swift中的Set类型被写为Set<Element> 这里的Element表示Set中允许存储的类型 和数组不同 集合没有等价的简化形式
        
        
        
        //1.3.2创建和构造一个空的集合
        
        //可以通过构造器语法创建一个特定类型的空集合:
        var letters = Set<Character>()
        print("letters is of type Set<Character> with \(letters.count) items.")
        //注意:通过构造器 这里的letters变量的类型被推断为Set<Character>
        
        //如果上下文提供了类型信息 比如作为函数的参数或者已知类型的变量或常量 可以创建一个空的Set:
        letters.insert("a") //letters现在含有1个Character类型的值
        letters = [] //letters现在是一个空的Set 但它依然是Set<Character>类型
        
        
        
        //1.3.3用数组字面量创建集合
        
        //可以使用数组字面量来构造集合 并且可以使用简化形式写一个或者多个值作为集合元素
        
        //下例创建了一个称之为favoriteGenres的集合来存储String类型的值:
        var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
        //这个favoriteGenres变量被声明为"一个String值的集合" 写为Set<String> 由于这个特定的集合含有指定String类型的值 所以它只允许存储String类型值 这里的favoriteGenres变量有三个String类型的初始值("Rock" "Classical" "Hip hop")并以数组字面量的方式出现
        
        //一个Set类型不能从数组字面量中被单独推断出来 因此Set类型必须显式声明 
        //然而 由于Swift的类型推断功能 如果想使用一个数组字面量构造一个Set并且该数组字面量中的所有元素类型相同 那么无须写出Set的具体类型:
//        var anotherFavoriteGenres: Set = ["Rock", "Classical", "Hip hop"]
        //由于数组字面量中的所有元素类型相同 Swift可以推断出Set<String>作为anotherFavoriteGenres变量的正确类型
        
        
        
        //1.3.4访问和修改一个集合
        
        //可以通过Set的属性和方法来访问和修改一个Set
        
        //为了得出一个Set中元素的数量 可以使用其只读属性count:
        print("I have \(favoriteGenres.count) favorite music genres.")
        
        //使用布尔属性isEmpty去检查count属性是否为0:
        if favoriteGenres.isEmpty
        {
            print("As far as music goes, I'm not picky.")
        }
        else
        {
            print("I have particular music preferences.")
        }
        
        //可以通过调用Set的insert(_:)方法来添加一个新元素:
        favoriteGenres.insert("Jazz")
        
        //可以通过调用Set的remove(_:)方法去删除一个元素 如果该值是该Set的一个元素则删除该元素并且返回被删除的元素值 否则如果该Set不包含该值 则返回nil 另外 Set中的所有元素可以通过它的removeAll()方法删除
        if let removedGenre = favoriteGenres.remove("Rock")
        {
            print("\(removedGenre)? I'm over it.")
        }
        else
        {
            print("I never much cared for that.")
        }
        
        //使用contains(_:)方法去检查Set中是否包含一个特定的值:
        if favoriteGenres.contains("Funk")
        {
            print("I get up on the good foot.")
        }
        else
        {
            print("It's too funky in here.")
        }
        
        
        
        //1.3.5遍历一个集合
        
        //可以在一个for-in循环中遍历一个Set中的所有值:
//        for genre in favoriteGenres
//        {
//            print("\(genre)")
//        }
        
        //Swift的Set类型没有确定的顺序 为了按照特定顺序来遍历一个Set中的值可以使用sort()方法 它将根据提供的序列返回一个有序集合
        for genre in favoriteGenres.sort()
        {
            print("\(genre)")
        }
        
        
        
        //1.3.6集合操作
        
        //交集定义:属于A且属于B的相同元素组成的集合
        //并集定义:所有属于A或属于B的元素组成的集合
        //相对补集定义:属于A而不属于B的元素组成的集合 称为B在A中的相对补集
        
        //a与b的交集:a.intersect(b)
        //a与b的并集:a.union(b)
        //b在a中的相对补集:a.subtract(b)
        //(a与b的交集)在(a与b的并集)中的相对补集:a.exclusiveOr(b)
        
        let oddDigits: Set = [1, 3, 5, 7, 9]
        let evenDigits: Set = [0, 2, 4, 6, 8]
        let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]
        
        print(oddDigits.union(evenDigits).sort()) //[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        print(oddDigits.intersect(evenDigits).sort()) //[]
        print(oddDigits.subtract(singleDigitPrimeNumbers).sort()) //[1, 9]
        print(oddDigits.exclusiveOr(singleDigitPrimeNumbers).sort()) //[1, 2, 9]
        
        //1.3.7集合关系
        
        //使用运算符(==)来判断两个集合是否相等
        //使用isDisjointWith(_:)方法来判断两个集合是否不相交
        //使用isSubsetOf(_:)方法来判断一个集合是否是另一个集合的子集
        //使用isSupersetOf(_:)方法来判断一个集合是否是另一个集合的父集
        //使用isStrictSubsetOf(_:)\isStrictSupersetOf(_:)方法来判断一个集合是否是另外一个集合的子集\父集 并且两个集合不相等
        
        let houseAnimals: Set = ["🐶", "🐱"]
        let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
        let cityAnimals: Set = ["🐦", "🐭"]
        
        print(houseAnimals.isSubsetOf(farmAnimals))
        print(farmAnimals.isSupersetOf(houseAnimals))
        print(farmAnimals.isDisjointWith(cityAnimals))
        
        
        
        //1.4字典
        
        //字典是一种存储多个相同类型的值的容器 每个值(value)都关联唯一的键(key) 键作为字典中的这个值数据的标识符 和数组中的数据项不同 字典中的数据项并没有具体顺序
        
        //注意:Swift的Dictionary类型被桥接到Foundation的NSDictionary类 更多关于在Foundation和Cocoa中使用Dictionary类型的信息 参见Using Swift with Cocoa and Obejective-C一书
        
        //1.4.1字典类型快捷语法
        
        //Swift的字典用Dictionary<Key, Value>定义 Key是字典中键的数据类型 Value是字典中对应于这些键所存储值的数据类型
        //注意:一个字典的Key类型必须遵循Hashable协议 就像Set的值类型
        //也可以用[Key: Value]这样快捷的形式去创建一个字典类型 虽然这两种形式功能上相同 但是后者是首选
        
        
        
        //1.4.2创建一个空字典
        
        //可以像数组一样使用构造语法创建一个拥有确定类型的空字典:
        var namesOfIntegers = [Int: String]()
        //上例创建了一个[Int: String]类型的空字典 它的键是Int类型 值是String类型
        
        //如果上下文已经提供了类型信息 可以使用空字典字面量来创建一个空字典 记作[:]
        namesOfIntegers[16] = "sixteen" //namesOfIntegers现在包含一个键值对
        namesOfIntegers = [:]           //namesOfIntegers又成了一个[Int: String]类型的空字典
        print(namesOfIntegers)
        
        
        
        //1.4.3用字典字面量创建字典
        
        //可以使用字典字面量来构造字典 字典字面量是一种将一个或多个键值对写作Dictionary集合的快捷途径
        
        //一个键值对是一个key和一个value的结合体 在字典字面量中 每一个键值对的键和值都由冒号分割 这些键值对构成一个列表:
        var airports: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
        //这个字典语句包含了两个String: String类型的键值对 它们对应airports变量声明的类型(一个只有String键和String值的字典)
        
        //和数组一样 在用字典字面量构造字典时 如果它的键和值都有各自一致的类型 那么就不必写出字典的类型:
        let anotherAirports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
        print(anotherAirports)
        //这个语句中所有的键和值都各自拥有相同的数据类型 Swift可以推断出Dictionary<String, String>是anotherAirports字典的正确类型
        
        
        
        //1.4.4访问和修改字典
        
        //可以通过字典的方法和属性来访问和修改字典 或者通过使用下标语法
        
        //可以通过字典的只读属性count来获取某个字典的数据项数量:
        print("The dictionary of airports contains \(airports.count) items.")
        
        //使用布尔属性isEmpty来快捷地检查字典的count属性是否等于0:
        if airports.isEmpty
        {
            print("The airports dictionary is empty.")
        }
        else
        {
            print("The airports dictionary is not empty.")
        }
        
        //也可以在字典中使用下标语法来添加新的数据项 可以使用一个恰当类型的键作为下标索引 并且分配恰当类型的新值:
        airports["LHR"] = "London"
        
        //也可以使用下标语法来改变特定键对应的值:
        airports["LHR"] = "London Heathrow"
        
        //另一种下标方法:字典的updateValue(_:forKey:)方法可以设置或者更新特定键对应的值
        //类似上例 该方法在键不存在对应值的时候会设置新值或在值存在时更新已有值 不同的是 该方法返回更新值之前的原值 这样可以检查更新是否成功
        //updateValue(_:forKey:)方法会返回对应值的类型的可选值 举例来说:对于存储String值的字典 这个函数会返回一个String?或者Optional(String)类型的值
        //如果有值存在于更新前 则这个可选值包含了旧值 否则它将会是nil
        if let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB")
        {
            print("The old value for DUB was \(oldValue).")
        }
        
        //也可以使用下标语法在字典中检索特定键对应的值 因为有可能请求的键没有对应的值存在 字典的下标访问会返回对应值的类型的可选值 如果这个字典包含请求键所对应的值 下标会返回一个包含这个存在值的可选值 否则将返回nil:
        if let newValue = airports["DUB"]
        {
            print("The new value for DUB was \(newValue).")
        }
        else
        {
            print("The new value for DUB is not in the airports dictionary.")
        }
        
        //还可以使用下标语法来通过给某个键的对应值赋值为nil来从字典里移除一个键值对:
        airports["APL"] = "Apple Internation"
        airports["APL"] = nil
        
        //此外 removeValueForKey(_:)方法也可以用来在字典中移除键值对 这个方法在键值对存在的情况下会移除该键值对并且返回被移除的值 或者在没有值的情况下返回nil:
        if let removedValue = airports.removeValueForKey("DUB")
        {
            print("The removed airport's name is \(removedValue).")
        }
        else
        {
            print("The airports dictionary does not contain a value for DUB.")
        }
        
        
        
        //1.4.5字典遍历
        
        //可以使用for-in循环来遍历某个字典中的键值对 每一个字典中的数据项都以(key, value)元组形式返回 并且可以使用临时常量或者变量来分解这些元组:
        
        for (airportCode, airportName) in airports
        {
            print("\(airportCode): \(airportName)")
        }
        
        //通过访问keys或者values属性 也可以遍历字典的键或者值:
        for airportCode in airports.keys
        {
            print("Airport code: \(airportCode)")
        }
        
        for airportName in airports.values
        {
            print("Airport name: \(airportName)")
        }
        
        //如果只是需要使用某个字典的键集合或者值集合来作为某个接受Array实例的API的参数 可以直接使用keys或者values属性构造一个新数组:
        let airportCodes = [String](airports.keys)
        print(airportCodes)
        
        let airportNames = [String](airports.values)
        print(airportNames)
        
        //Swift的字典类型是无序集合类型 为了以特定的顺序遍历字典的键或值 可以对字典的keys或values属性使用sort()方法
    }
}