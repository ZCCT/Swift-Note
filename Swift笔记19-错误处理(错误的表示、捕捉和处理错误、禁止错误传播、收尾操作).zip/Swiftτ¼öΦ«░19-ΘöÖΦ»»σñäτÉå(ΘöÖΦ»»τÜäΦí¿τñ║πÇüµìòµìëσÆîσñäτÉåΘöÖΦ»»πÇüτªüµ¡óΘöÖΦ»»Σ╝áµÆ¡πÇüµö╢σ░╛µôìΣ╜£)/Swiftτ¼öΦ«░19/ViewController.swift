//
//  ViewController.swift
//  Swift笔记19
//
//  Created by apple on 16/1/7.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //错误处理(Error Handling)
        
        //错误处理是响应错误并从错误中返回的过程 Swift提供第一类错误支持 包括在运行时抛出 捕获 传送和控制可回收错误
        
        //一些函数和方法不能总保证能够执行所有代码或产生有用的输出 可空类型用来表示值可能为空 但是当函数执行失败时 可空通常可以用来确定执行失败的原因 因此代码可以正确地响应失败 在Swift中这叫做抛出函数或者抛出方法
        
        
        
        //1.错误的表示
        
        //在Swift中 错误用符合ErrorType协议的值表示:
        enum VendingMachineError: ErrorType
        {
            case InvalidSelection
            case InsufficientFunds(coinsNeeded: Int)
            case OutOfStock
        }
        
        //错误抛出:通过在函数或方法声明的参数后面加上throws关键字 表明这个函数或方法可以抛出错误 如果指定一个返回值 可以把throws关键字放在返回箭头(->)的前面:
//        func canThrowErrors() throws -> String
//        func cannotThrowErrors() -> String
        
        //在抛出函数体的任意一个地方 可以通过throw语句抛出错误:
        struct Item
        {
            var price: Int
            var count: Int
        }
        
        class VendingMachine
        {
            var inventory = ["Candy Bar": Item(price: 12, count: 7), "Chips": Item(price: 10, count: 4), "Pretzels": Item(price: 7, count: 11)]
            var coinsDeposited = 0
            
            func dispenseSnack(snack: String)
            {
                print("Dispensing \(snack)")
            }
            
            func vend(itemNamed name: String) throws
            {
                guard var item = inventory[name]
                else {
                    throw VendingMachineError.InvalidSelection
                }
                
                guard item.count > 0
                else {
                    throw VendingMachineError.OutOfStock
                }
                
                guard item.price <= coinsDeposited
                else {
                    throw VendingMachineError.InsufficientFunds(coinsNeeded: item.price - coinsDeposited)
                }
                
                coinsDeposited -= item.price
                item.count -= 1
                inventory[name] = item
                dispenseSnack(name)
            }
        }
        
        //当调用一个抛出函数时 在调用前面加上try关键字
        let favoriteSnacks = ["Alice": "Chips", "Bob": "Licorice", "Eve": "Pretzels"]
        
        func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws
        {
            let snackName = favoriteSnacks[person] ?? "Candy Bar"
            try vendingMachine.vend(itemNamed: snackName)
        }
        
        
        
        //2.捕获和处理错误
        
        //使用do-catch语句捕获和处理错误:
//        do
//        {
//            try expression
//            statements
//        }
//        catch pattern 1
//        {
//            statements
//        }
//        catch pattern 2 where condition
//        {
//            statements
//        }
        
        //如果一个错误被抛出 这个错误会被传递到外部域 直到被一个catch分句处理 一个catch分句包含一个catch关键字 跟着一个pattern来匹配错误和相应的执行语句
        
        //类似switch语句 编译器会检查catch分句是否能够处理全部错误 如果能够处理所有错误情况 就认为这个错误被完全处理 否则 包含这个抛出函数的所在域就要处理这个错误 或者包含这个抛出函数的函数也用throws声明 为了保证错误被处理 用一个带pattern的catch分句来匹配所有错误 如果一个catch分句没有指定样式 这个分句会匹配并且绑定任何错误到一个本地error常量(更多关于pattern的信息 参见模式)
        let vendingMachine = VendingMachine()
        vendingMachine.coinsDeposited = 8
        
        do
        {
            try buyFavoriteSnack("Alice", vendingMachine: vendingMachine)
        }
        catch VendingMachineError.InvalidSelection
        {
            print("Invalid Selection.")
        }
        catch VendingMachineError.OutOfStock
        {
            print("Out of Stock.")
        }
        catch VendingMachineError.InsufficientFunds(let coinsNeeded)
        {
            print("Insufficient funds. Please insert an additional \(coinsNeeded) coins.")
        }
        catch
        {
            print("Other unknown error")
        }
        
        //上例中buyFavoriteSnack函数在try表达式中被调用 如果函数抛出了错误 程序执行流程马上转到catch分句 如果没有抛出错误 将会执行在do语句中剩余的语句
        
        //注意:Swift中的错误处理和其他语言中的异常处理很像 使用了throw try do-catch关键字 但和这些语言不同的是 Swift不会展开调用堆栈 那会带来很大的性能损耗 因此Swift中throw语句的性能几乎和return语句一样
        
        
        
        //3.禁止错误传播
        
        //在运行时 有几种情况抛出函数事实上是不会抛出错误的 在这几种情况下 可以用forced-try表达式来调用抛出函数或方法 即用try!来代替try
        
        //通过try!来调用抛出函数或方法禁止了错误传送 并且把调用包装在运行时断言 这样就不会抛出错误 如果错误真的抛出了 会触发运行时错误:
//        func willOnlyThrowIfTrue(value: Bool) throws
//        {
//            if value { throw someError }
//        }
//        
//        try! willOnlyThrowIfTrue(false)
        
        
        
        //4.收尾操作
        
        //使用defer语句来在执行一系列的语句 这样不管有没有错误发生 都可以执行一些必要的收尾操作 包括关闭打开的文件以及释放所有手动分配的内存
        
        //defer语句把执行推迟到退出当前域的时候 defer语句包括defer关键字以及后面要执行的语句 被推迟的语句可能不包含任何将执行流程转移到外部的代码 比如break或者return语句 或者通过抛出一个错误 被推迟的操作的执行顺序和他们定义的顺序相反 也就是说 第一个defer语句中的代码在第二个defer语句中的代码之后执行:
//        func processFile(filename: String) throws
//        {
//            if exists(filename)
//            {
//                let file = open(filename)
//                defer
//                {
//                    close(file)
//                }
//                while let line = try file.readline()
//                {
//                    //Work with the file
//                }
//            }
//        }
    }
}