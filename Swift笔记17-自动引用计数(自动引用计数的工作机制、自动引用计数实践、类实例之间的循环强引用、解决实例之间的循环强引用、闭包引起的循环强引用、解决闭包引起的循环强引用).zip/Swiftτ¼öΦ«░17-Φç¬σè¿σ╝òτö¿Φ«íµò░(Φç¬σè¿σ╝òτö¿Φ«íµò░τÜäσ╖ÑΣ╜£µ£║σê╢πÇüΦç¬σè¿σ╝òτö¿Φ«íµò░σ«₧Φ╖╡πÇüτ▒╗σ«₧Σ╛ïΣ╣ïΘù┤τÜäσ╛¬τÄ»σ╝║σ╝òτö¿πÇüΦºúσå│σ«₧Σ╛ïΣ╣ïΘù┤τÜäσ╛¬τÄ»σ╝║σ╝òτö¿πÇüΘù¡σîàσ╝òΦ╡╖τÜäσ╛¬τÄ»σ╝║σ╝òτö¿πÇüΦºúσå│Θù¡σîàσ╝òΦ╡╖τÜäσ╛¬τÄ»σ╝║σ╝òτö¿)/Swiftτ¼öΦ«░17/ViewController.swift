//
//  ViewController.swift
//  Swift笔记17
//
//  Created by apple on 16/1/5.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //自动引用计数(Automatic Reference Counting)
        
        //1.自动引用计数的工作机制
        
        //当每次创建一个类的新的实例的时候 ARC会分配一大块内存用来储存实例的信息 内存中会包含实例的类型信息 以及这个实例所有相关属性的值
        
        //此外 当实例不再被使用时 ARC释放实例所占用的内存 并让释放的内存移作他用 这确保了不再被使用的实例不会一直占用内存空间
        
        //然而 当ARC收回和释放了正在被使用中的实例 该实例的属性和方法将不能再被访问和调用 实际上 如果试图访问这个实例应用程序很可能会崩溃
        
        //为了确保使用中的实例不会被销毁 ARC会跟踪和计算每一个实例正在被多少属性 常量和变量所引用 哪怕实例的引用数为1 ARC都不会销毁这个实例
        
        //为了使上述成为可能 无论将实例赋值给属性 常量或变量 它们都会创建此实例的强引用 之所以称之为强引用 是因为它会将实例牢牢的保持住 只要强引用还在 实例是不允许被销毁的
        
        
        
        //2.自动引用计数实践
        
        //下例展示了自动引用计数的工作机制:
        class Person
        {
            let name: String
            
            init(name: String)
            {
                self.name = name
                print("\(name) is being initialized")
            }
            
            deinit
            {
                print("\(name) is being deinitialized")
            }
        }
        
        //下面定义了三个类型为Person?的变量 用来按照代码片段中的顺序 为新的Person实例建立多个引用 由于这些变量被定义为可选类型 它们的值会被自动初始化为nil 目前还不会引用到Person类的实例:
        var reference1: Person?
        var reference2: Person?
        var reference3: Person?
        
        //现在创建Person类的新实例 并且将它赋值给三个变量中的一个:
        reference1 = Person(name: "John Appleseed")
        //由于Person类的新实例被赋值给了reference1变量 所以reference1与Person类的新实例之间建立了一个强引用 因为这一个强引用 ARC会保证Person实例被保持在内存中不被销毁
        
        //如果将同一个Person实例也赋值给其他两个变量 该实例又会多出两个强引用:
        reference2 = reference1
        reference3 = reference1
        //现在这一Person实例已经有三个强引用了
        
        //如果通过给其中两个变量赋值nil的方式断开两个强引用 只留下一个强引用 Person实例不会被销毁:
        reference1 = nil
        reference2 = nil
        
        //在清楚地表明不再使用这个Person实例时 即最后一个强引用被断开时 ARC会销毁它:
        reference3 = nil
        
        
        
        //3.类实例之间的循环强引用
        
        //上例中 ARC会跟踪新创建的Person实例的引用数量 并且会在Person实例不再被需要时销毁它
        
        //然而 有可能会出现一个类实例的强引用数永远不会变成0的情况:如果两个类实例互相持有对方的强引用 则每个实例都让对方一直存在 这就是所谓的循环强引用
        
        //可以通过定义类之间的关系为弱引用或无主引用 以替代强引用 从而解决循环强引用的问题
        
        //下面展示了一个产生循环强引用的例子:
        class PersonNew
        {
            let name: String
            init(name: String) { self.name = name }
            var apartment: Apartment?
            deinit { print("\(name) is being deinitialized") }
        }
        
        class Apartment
        {
            let number: Int
            init(number: Int) { self.number = number }
            var tenant: PersonNew?
            deinit { print("Apartment #\(number) is being deinitialized") }
        }
        
        //每个PersonNew实例有一个类型为String 名字为name的属性 并有一个可选的初始化为nil的apartment属性 apartment属性是可选的 因为一个人并不总是拥有公寓
        
        //每个Apartment实例有一个类型为Int 名字为number的属性 并有一个可选的初始化为nil的tenant属性 tenant属性是可选的 因为一栋公寓并不总是有居民
        
        //这两个类都定义了析构函数 用以在类实例被析构的时候输出信息
        
        //接下来定义了两个可选类型的变量john和number73 并分别设定为PersonNew和Apartment的实例 这两个变量都被初始化为nil 这正是可选的优点:
        var john: PersonNew?
        var number73: Apartment?
        
        //现在可以创建特定的PersonNew和Apartment实例并赋值给john和number73变量:
        john = PersonNew(name: "John Appleseed")
        number73 = Apartment(number: 73)
        
        //现在将这两个实例关联在一起 注意:感叹号是用来展开和访问可选变量john和number73中的实例 这样实例的属性才能被赋值:
        john!.apartment = number73
        number73!.tenant = john
        
        //当把这两个变量设为nil时 没有任何一个析构函数被调用 循环强引用会阻止类的实例的销毁 这就造成了内存泄漏:
        john = nil
        number73 = nil
        
        
        
        //4.解决实例之间的循环强引用
        
        //Swift提供了两种办法用来解决在使用类的属性时所遇到的循环强引用问题:弱引用(weak reference)和无主引用(unowned reference)
        
        //弱引用和无主引用允许循环引用中的一个实例引用另外一个实例而不保持强引用 这样实例能够互相引用而不产生循环强引用
        
        //对于生命周期中会变为nil的实例使用弱引用 相反地 对于初始化赋值后再也不会被赋值为nil的实例 使用无主引用
        
        
        
        //4.1弱引用
        
        //弱引用不会对其引用的实例保持强引用 因而不会阻止ARC销毁被引用的实例 这个特性阻止了引用变为循环强引用 声明属性或者变量时 在前面加上weak关键字表明这是一个弱引用
        
        //在实例的生命周期中 如果某些时候引用没有值 那么弱引用可以避免循环强引用 如果引用总是有值 则可以使用无主引用
        
        //注意:弱引用必须被声明为变量 表明其值能在运行时被修改 弱引用不能被声明为常量
        
        //因为弱引用可以没有值 必须将每一个弱引用声明为可选类型 在Swift中推荐使用可选类型描述可能没有值的类型
        
        //因为弱引用不会保持所引用的实例 即使引用存在 实例也有可能被销毁 因此ARC会在引用的实例被销毁后自动将其赋值为nil
        class Person1
        {
            let name: String
            init(name: String) { self.name = name }
            var apartment: Apartment1?
            deinit { print("\(name) is being deinitialized") }
        }
        
        class Apartment1
        {
            let number: Int
            init(number: Int) { self.number = number }
            weak var tenant: Person1?
            deinit { print("Apartment #\(number) is being deinitialized") }
        }
        
        var mike: Person1?
        var number66: Apartment1?
        
        mike = Person1(name: "Mike Json")
        number66 = Apartment1(number: 66)
        
        mike?.apartment = number66
        number66?.tenant = mike
        
        //Person1实例依然保持对Apartment1实例的强引用 但是Apartment1实例只是对Person1实例的弱引用 这意味着当断开mike变量所保持的强引用时 再也没有指向Person实例的强引用了 由于再也没有指向Person实例的强引用 该实例会被销毁:
        mike = nil
        
        //唯一剩下的指向Apartment1实例的强引用来自于变量number66 如果断开这个强引用 再也没有指向Apartment1实例的强引用了 由于再也没有指向Apartment1实例的强引用 该实例也会被销毁:
        number66 = nil
        
        
        
        //4.2无主引用
        
        //和弱引用类似 无主引用不会牢牢保持住引用的实例 和弱引用不同的是 无主引用是永远有值的 因此 无主引用总是被定义为非可选类型(non-optional type) 可以在声明属性或者变量时 在前面加上关键字unowned表示这是一个无主引用
        
        //由于无主引用是非可选类型 不需要在使用它的时候将它展开 无主引用总是可以被直接访问 不过ARC无法在实例被销毁后将无主引用设为nil 因为非可选类型的变量不允许被赋值为nil
        
        //注意:如果试图在实例被销毁后 访问该实例的无主引用 会触发运行时错误 使用无主引用 必须确保引用始终指向一个未销毁的实例
        
        //下例定义了两个类 这两个类中 每一个都将另外一个类的实例作为自身的属性 这种关系可能会造成循环强引用
        
        //本例中 一个客户可能有或者没有信用卡 但是一张信用卡总是关联着一个客户 为了表示这种关系:Customer类有一个可选类型的card属性 而CreditCard类有一个非可选类型的customer属性
        
        //此外 只能通过将一个number值和customer实例传递给CreditCard构造函数的方式来创建CreditCard实例 这样可以确保当创建CreditCard实例时总是有一个customer实例与之关联
        
        //由于信用卡总是关联着一个客户 因此将customer属性定义为无主引用 以避免循环强引用:
        class Customer
        {
            let name: String
            var card: CreditCard?
            
            init(name: String)
            {
                self.name = name
            }
            
            deinit { print("\(name) is being deinitialized") }
        }
        
        class CreditCard
        {
            let number: UInt64
            unowned let customer: Customer
            
            init(number: UInt64, customer: Customer)
            {
                self.number = number
                self.customer = customer
            }
            
            deinit { print("Card #\(number) is being deinitialized") }
        }
        
        var bob: Customer?
        bob = Customer(name: "Bob Laby")
        bob!.card = CreditCard(number: 1234_5678_9012_3456, customer: bob!)
        bob = nil
        
        
        
        //4.3无主引用以及隐式解析可选属性
        
        //上面弱引用和无主引用的例子涵盖了两种常用的需要打破循环强引用的场景
        
        //然而 存在着第三种场景:两个属性都必须有值 并且初始化完成后永远不会为nil 在这种场景中 需要一个类使用无主属性 而另外一个类使用隐式解析可选属性
        
        //这使得两个属性在初始化完成后能被直接访问(不需要可选展开) 同时避免了循环引用
        class Country
        {
            let name: String
            var capitalCity: City!
            
            init(name: String, capitalName: String)
            {
                self.name = name
                self.capitalCity = City(name: capitalName, country: self)
            }
        }
        
        class City
        {
            let name: String
            unowned let country: Country
            
            init(name: String, country: Country)
            {
                self.name = name
                self.country = country
            }
        }
        
        //为了建立两个类的依赖关系 City的构造函数有一个Country实例的参数 并且将实例保存为country属性
        
        //Country的构造函数调用了City的构造函数 然而 只有Country的实例完全初始化完后 Country的构造函数才能把self传给City的构造函数(具体参见两段式构造过程)
        
        //为了满足这种需求 通过在类型结尾处加上感叹号(!)的方式 将Country的capitalCity属性声明为隐式解析可选类型的属性 这表示像其他可选类型一样 capitalCity属性的默认值为nil 但是不需要展开它的值就能访问它(具体参见隐式解析可选类型)
        
        //由于capitalCity默认值为nil 一旦Country的实例在构造函数中给name属性赋值后 整个初始化过程就完成了 这代表一旦name属性被赋值后 Country的构造函数就能引用并传递隐式的self Country的构造函数在赋值capitalCity时 就能将self作为参数传递给City的构造函数
        let country = Country(name: "Canada", capitalName: "Ottawa")
        print("\(country.name)'s capital city is called \(country.capitalCity.name)")
        
        //上例使用隐式解析可选值的意义在于满足了两个类构造函数的需求 capitalCity属性在初始化完成后 能像非可选值一样使用和存取同时还避免了循环强引用
        
        
        
        //5.闭包引起的循环强引用
        
        //循环强引用还会发生在将一个闭包赋值给类实例的某个属性 并且这个闭包体中又使用了这个类实例:闭包体中可能访问了实例的某个属性 或者调用了实例的某个方法 这两种情况都导致了闭包捕获self从而产生了循环强引用
        
        //循环强引用的产生 是因为闭包和类相似 都是引用类型
        
        //Swift提供了一种优雅的方法来解决这个问题 称之为闭包捕获列表(closuer capture list)
        
        //下例展示了当一个闭包引用了self后是如何产生一个循环强引用的:
        //⭐️File文件里的代码1⭐️
        
        var paragraph: HTMLElement? = HTMLElement(name: "p", text: "hello, world")
        print(paragraph!.asHTML())
        
        //实例的asHTML属性持有闭包的强引用 但是闭包在其闭包体内使用了self(引用了self.name和self.text) 因此闭包捕获了self 这意味着闭包又反过来持有了HTMLElement实例的强引用 这样两个对象就产生了循环强引用(更多关于闭包捕获值的信息参见值捕获)
        
        //注意:虽然闭包多次使用了self 但只捕获HTMLElement实例的一个强引用
        
        //如果设置paragraph变量为nil 打破它持有的HTMLElement实例的强引用 HTMLElement实例和它的闭包都不会被销毁(因为循环强引用):
        paragraph = nil
        
        
        
        //6.解决闭包引起的循环强引用
        
        //在定义闭包时同时定义捕获列表作为闭包的一部分 通过这种方式可以解决闭包和类实例之间的循环强引用 
        //捕获列表定义了闭包体内捕获一个或者多个引用类型的规则 跟解决两个类实例间的循环强引用一样 声明每个捕获的引用为弱引用或无主引用
        
        //注意:只要在闭包内使用self的成员 就要用self.someProperty或self.someMethod
        
        
        
        //6.1定义捕获列表
        
        //捕获列表中的每一项都由一对元素组成 一个元素是weak或unowned关键字 另一个元素是类实例的引用(如self) 或初始化过的变量(如delegate = self.delegate!) 这些项在方括号中用逗号分开
        
        //如果闭包有参数列表和返回类型 把捕获列表放在它们前面:
//        lazy var someClosure: (Int, String) -> String =
//        {
//            [unowned self, weak delegate = self.delegate!] (index: Int, stringToProcess: String) -> String in
//        }
        
        //如果闭包没有指明参数列表或者返回类型 即它们会通过上下文推断 那么可以把捕获列表和关键字in放在闭包最开始的地方:
//        lazy var someClosure: Void -> String =
//        {
//            [unowned self, weak delegate = self.delegate!] in
//        }
        
        
        
        //6.2弱引用和无主引用
        
        //在闭包和捕获的实例总是互相引用时并且总是同时销毁时 将闭包内的捕获定义为无主引用
        
        //相反 在被捕获的引用可能会变为nil时 将闭包内的捕获定义为弱引用 弱引用总是可选类型 并且当引用的实例被销毁后 弱引用的值会自动置为nil
        
        //注意:如果被捕获的引用绝对不会变为nil 应该用无主引用 而不是弱引用
        
        var paragraph1: HTMLElementNew? = HTMLElementNew(name: "p", text: "hello, world")
        print(paragraph1!.asHTML())
        paragraph1 = nil
    }
}