//
//  File.swift
//  Swift笔记17
//
//  Created by apple on 16/1/5.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
class HTMLElement
{
    let name: String
    let text: String?
    
    lazy var asHTML: Void -> String =
    {
        if let text = self.text
        {
            return "<\(self.name)>\(text)</\(self.name)>"
        }
        else
        {
            return "<\(self.name) />"
        }
    }
    
    init(name: String, text: String? = nil)
    {
        self.name = name
        self.text = text
    }
    
    deinit
    {
        print("\(name) is being deinitialized")
    }
}
//注意:asHTML声明为lazy属性 因为只有当元素确实需要处理为HTML输出的字符串时 才需要使用asHTML 也就是说 在默认的闭包中可以使用self 因为只有当初始化完成以及self确实存在后 才能访问lazy属性



//上例中无主引用是正确解决循环强引用的方法:
class HTMLElementNew
{
    
    let name: String
    let text: String?
    
    lazy var asHTML: Void -> String =
    {
        [unowned self] in
        if let text = self.text
        {
            return "<\(self.name)>\(text)</\(self.name)>"
        }
        else
        {
            return "<\(self.name) />"
        }
    }
    
    init(name: String, text: String? = nil)
    {
        self.name = name
        self.text = text
    }
    
    deinit
    {
        print("\(name) is being deinitialized")
    }
}
//上面的捕获列表是[unowned self] 表示"用无主引用来捕获self"