//
//  ViewController.swift
//  Swift笔记10
//
//  Created by apple on 15/12/29.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //类和结构体(Classes and Structures)
        
        //类和结构体是构建代码所用的一种通用且灵活的构造体 可以使用完全相同的语法规则来为类和结构体定义属性(常量、变量) 添加方法 从而扩展类和结构体的功能
        
        //与其他编程语言不同 Swift并不要求为自定义类和结构体去创建独立的接口和实现文件 只要在一个单一文件中定义一个类或者结构体 系统将会自动生成面向其它代码的外部接口
        
        //注意:通常一个类的实例被称为对象 而在Swift中类和结构体的关系要比在其他语言中更加的密切 本章中所讨论的大部分功能都可以用在类和结构体上 因此主要使用实例而不是对象
        
        
        
        //类和结构体对比
        
        //Swift中类和结构体有很多共同点:
        //定义属性用于存储值
        //定义方法用于提供功能
        //定义附属脚本用于访问值
        //定义构造器用于生成初始化值
        //通过扩展以增加默认实现的功能
        //实现协议以提供某种标准功能
        //(更多信息请参见属性 方法 下标脚本 初始过程 扩展 协议)
        
        //与结构体相比 类还有以下的附加功能:
        //允许一个类继承另一个类的特征
        //类型转换允许在运行时检查和解释一个类实例的类型
        //析构器允许一个类实例释放任何其所被分配的资源
        //引用计数允许对一个类的多次引用
        //(更多信息请参见继承 类型转换 析构过程 自动引用计数)
        
        //注意:结构体总是通过被复制的方式在代码中传递 因此不使用引用计数
        
        
        
        //定义
        
        //类和结构体有着类似的定义方式 通过关键字class和struct来分别表示类和结构体 并在一对大括号中定义具体内容:
        class SomeClass
        {
            //class definition goes here
        }
        
        struct SomeStructure
        {
            //structure definition goes here
        }
        
        //注意:每次定义一个新类或结构体的时候 实际上是有效地定义了一个新的Swift类型
        //请使用UpperCamelCase这种方式来命名(如:SomeClass SomeStructure)以便符合标准Swift类型的大写命名风格(如:String Int Bool)
        //相反 请使用lowerCamelCase这种方式为属性和方法命名(如framerate和incrementCount)以便和类区分
        
        //以下是定义结构体和定义类的示例:
        struct Resolution
        {
            var width = 0
            var height = 0
        }
        
        class VideoMode
        {
            var resolution = Resolution()
            var interlaced = false
            var frameRate = 0.0
            var name: String?
        }
        
        //上例定义了一个名为Resolution的结构体 用来描述一个显示器的像素分辨率 这个结构体包含了两个名为width和height的存储属性 存储属性是捆绑和存储在类或结构体中的常量或变量 当这两个属性被初始化为0的时候 它们会被推断为Int类型
        
        //上例还定义了一个名为VideoMode的类 用来描述一个视频显示器的特定模式 这个类包含了四个储存属性变量 第一个是分辨率 它被初始化为一个新的Resolution结构体的实例 具有Resolution的属性类型 新VideoMode实例同时还会初始化其它三个属性分别是:初始值为false(意为"非隔行扫描视频")的interlaced 回放帧率初始值为0.0的frameRate和值为可选String的name name属性会被自动赋予一个默认值nil 意为"没有name值" 因为它是一个可选类型
        
        
        
        //类和结构体实例
        
        //生成结构体和类实例的语法非常相似:
        let someResolution = Resolution()
        let someVideoMode = VideoMode()
        
        //结构体和类都使用构造器语法来生成新的实例 构造器语法的最简单形式是在结构体或者类的类型名称后跟随一对空括号 如:Resolution() VideoMode()通过这种方式创建的类或者结构体实例 其属性均会被初始化为默认值
        
        
        
        //属性访问
        
        //通过使用点语法(dot syntax)可以访问实例中所含有的属性 其语法规则是:实例名后面紧跟属性名 两者通过点(.)连接:
        print("The width of someResolution is \(someResolution.width)")
        
        //上例中someResolution.width引用了someResolution的width属性 返回width的初始值0
        
        //也可以访问子属性 如VideoMode中Resolution属性的width属性:
        print("The width of someVideoMode is \(someVideoMode.resolution.width)")
        
        //也可以使用点语法为属性变量赋值:
        someVideoMode.resolution.width = 1280
        print("The width of someVideoMode is now \(someVideoMode.resolution.width)")
        
        //注意:与Objective-C不同的是 Swift允许直接设置结构体属性的子属性 上面最后一例就是直接设置了someVideoMode中resolution属性的width子属性 以上操作并不需要重新设置resolution属性
        
        
        
        //结构体类型的成员逐一构造器(Memberwise Initializers for Structure Types)
        
        //所有结构体都有一个自动生成的成员逐一构造器 用于初始化新结构体实例中成员的属性 新实例中各个属性的初始值可以通过属性的名称传递到成员逐一构造器之中:
        let vga = Resolution(width: 640, height: 480)
        print(vga.width, vga.height)
        //与结构体不同 类实例没有默认的成员逐一构造器(构造过程章节会对构造器进行更详细的介绍)
        
        
        
        //1.结构体和枚举是值类型
        
        //值类型被赋予给一个变量 常量或者本身被传递给一个函数的时候 实际上操作的是其的拷贝
        
        //⭐️Swift中所有的基本类型:整数(Integer) 浮点数(Floating-Point) 布尔值(Boolean) 字符串(String) 数组(Array) 字典(Dictionary)都是值类型 并且都是以结构体的形式在后台实现⭐️
        
        //在Swift中所有的结构体和枚举类型都是值类型 这意味着它们的实例以及实例中所包含的任何值类型属性 在代码中传递的时候都会被复制:
        let fhd = Resolution(width: 1920, height: 1080)
        var cinema = fhd
        cinema.width = 2048
        print("cinema is now \(cinema.width) pixels wide")
        print("fhd is still \(fhd.width) pixels wide")
        
        //枚举也遵循相同的准则:
        enum CompassPoint
        {
            case North, South, East, West
        }
        
        var currentDirection = CompassPoint.West
        let rememberedDirection = currentDirection
        currentDirection = .East
        
        if rememberedDirection == .West
        {
            print("The remembered direction is still West")
        }
        
        
        
        //2.类是引用类型
        
        //与值类型不同 引用类型在被赋予到一个变量 常量或者被传递到一个函数时 操作的是引用 并不是其拷贝 引用的是已存在的实例本身而不是其拷贝:
        let tenEighty = VideoMode()
        tenEighty.resolution = fhd
        tenEighty.interlaced = true
        tenEighty.name = "1080i"
        tenEighty.frameRate = 25.0
        
        let alsoTenEighty = tenEighty
        alsoTenEighty.frameRate = 30.0
        print("The frameRate property of tenEighty is now \(tenEighty.frameRate)")
        
        //因为类是引用类型 所以tenEight和alsoTenEight实际上引用的是相同的VideoMode实例 换句话说:它们是同一个实例的两种叫法
        
        //注意:tenEighty和alsoTenEighty被声明为常量 但依然可以改变tenEighty.frameRate和alsoTenEighty.frameRate 因为这两个常量本身不会改变 它们并不存储VideoMode实例 在后台仅仅是对VideoMode实例的引用 所以改变的是被引用的VideoMode实例的frameRate参数 而不是常量的值
        
        
        
        //2.1恒等运算符
        
        //因为类是引用类型 有可能有多个常量和变量在后台同时引用某一个类实例 如果能够判断两个常量或者变量是否引用同一个类的实例将会很有帮助 为了达到这个目的Swift内建了两个恒等运算符:
        //等价于(===)
        //不等价于(!==)
        if tenEighty === alsoTenEighty
        {
            print("tenEighty and alsoTenEighty refer to the same Resolution instance.")
        }
        
        //"等价于"(===)与"等于"(==)的不同:
        //"等价于"表示两个类(class type)的常量或者变量引用自同一个类实例
        //"等于"表示两个实例的值"相等"
        
        
        
        //2.2指针
        
        //C C++或Objective-C使用指针来引用内存中的地址
        //Swift常量或者变量引用引用类型的实例与C语言中的指针类似 不同的是Swift并不直接指向内存中的某个地址 而且也不用星号(*)来表明创建了一个引用 Swift中这些引用与其它的常量或变量的定义方式相同
        
        
        
        //3.类和结构体的选择
        
        //结构体实例总是通过值传递 类实例总是通过引用传递 这意味着两者适用不同的任务 当考虑一个工程项目的数据构造和功能的时候 需要决定每个数据构造是定义成类还是结构体
        
        //按照通用的准则 当符合一条或多条以下条件时请考虑构建结构体:
        //结构体的主要目的是用来封装少量相关简单数据值
        //预计一个结构体实例在赋值或传递时 封装的数据将会被拷贝而不是被引用
        //任何在结构体中储存的值类型属性 也将会被拷贝 而不是被引用
        //结构体不需要去继承另一个已存在类型的属性或行为
        
        //以下情境适合使用结构体:
        //几何形状的大小 封装一个width属性和height属性 两者均为Double类型
        //一定范围的路径 封装一个start属性和length属性 两者均为Int类型
        //三维坐标系内一点 封装x y z属性 三者均为Double类型
        
        //实际中 绝大部分的自定义数据构造都应该是类 而非结构体(⭐️)
        
        
        
        //4.字符串(String) 数组(Array) 字典(Dictionary)类型的赋值与复制行为
        
        //Swift中字符串(String) 数组(Array) 字典(Dictionary)类型均以结构体的形式实现 这意味着String Array Dictionary类型数据被赋值给新的常量或变量 或者被传入函数或方法中时 它们的值会发生拷贝行为(值传递方式)
        
        //Objective-C中字符串(String) 数组(Array) 字典(Dictionary)类型均以类的形式实现 这与Swfit中以值传递方式是不同的 NSString NSArray NSDictionary在发生赋值或者传入函数或方法中时 不会发生值拷贝 而是传递已存在实例的引用
        
        //注意:在Swift的后台中 只有确有必要 实际(actual)拷贝才会被执行 Swift管理所有的值拷贝以确保性能最优 所以没必要避免赋值来保证最优性能(实际赋值由系统管理优化)
    }
}