//
//  ViewController.swift
//  Swift笔记09
//
//  Created by apple on 15/12/28.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //枚举(Enumerations)
        
        //枚举定义了一个通用类型的一组相关值 使代码中以一种安全的方式来使用这些值
        
        //在C语言中枚举将枚举名和一个整型值相对应 Swift中的枚举更加灵活 不必给每一个枚举成员提供一个值 如果给枚举成员提供一个值(称为"原始值")则该值的类型可以是字符串 字符 整型值或浮点数
        
        //此外 枚举成员可以指定任何类型的相关值存储到枚举成员值中 可以定义一组通用的相关成员作为枚举的一部分 每一组都有不同的一组与它相关的适当类型的数值
        
        //在Swift中 枚举类型是(first-class) 它们采用了很多传统上只被类(class)所支持的特征 例如:计算型属性(computed properties)用于提供关于枚举当前值的附加信息 实例方法(instance methods)用于提供和枚举所代表的值相关联的功能 枚举也可以定义构造函数(initializers)来提供一个初始值 可以在原始的实现基础上扩展它们的功能 可以遵守协议(protocols)来提供标准的功能
        
        
        
        //1.枚举语法
        
        //使用enum关键词来创建枚举并且把它们的整个定义放在一对大括号内:
        enum CompassPoint
        {
            case North
            case South
            case East
            case West
        }
        
        //一个枚举中被定义的值(如:North South East West)是枚举的成员值(成员) case关键词表明新的一行成员值将被定义
        
        //注意:和C与Objective-C不同 Swift的枚举成员在被创建时不会被赋予一个默认的整型值 上例子中:North South East West不会隐式地赋值为0 1 2 3 相反 这些不同的枚举成员在CompassPoint的一种显示定义中拥有各自不同的值
        
        //多个成员值可以出现在同一行上 用逗号隔开:
        enum Planet
        {
            case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
        }
        
        //每个枚举定义了一个全新的类型 像Swift中其他类型一样 它们的名字(如:CompassPoint Planet)必须以一个大写字母开头 给枚举类型起一个单数名字而不是复数名字 以便于读起来更加容易理解:
        var directionToHead = CompassPoint.West
        
        //当directionToHead的类型已知时 再次为其赋值可以省略枚举名 但使用显式类型的枚举值可以让代码更具可读性:
        directionToHead = .East
        
        
        
        //2.匹配枚举值和Switch语句
        
        //可以使用switch语句匹配单个枚举值:
        directionToHead = .South
        
        switch directionToHead
        {
        case .North:
            print("Lots of planets have a north")
        case .South:
            print("Watch out for penguins")
        case .East:
            print("Where the sun rises")
        case .West:
            print("Where the skies are blue")
        }
        
        //当不需要匹配每个枚举成员的时候 可以提供一个默认default分支来涵盖所有未明确被提出的枚举成员:
        let somePlanet = Planet.Earth
        
        switch somePlanet
        {
        case .Earth:
            print("Mostly harmless")
        default:
            print("Not a safe place for humans")
        }
        
        
        
        //3.相关值(Associated Values)
        
        //可以定义Swift的枚举存储任何类型的相关值 如果需要的话 每个成员的数据类型可以是各不相同的
        
        //例如:假设一个库存跟踪系统需要利用两种不同类型的条形码来跟踪商品 有些商品上标有UPC-A格式的一维t条形码 它使用数字0到9 每一个条形码都有一个代表"数字系统"的数字 该数字后接5个代表"生产代码"的数字 接下来是5位"产品代码" 最后一个数字是"检查"位 用来验证代码是否被正确扫描
        
        //其他商品上标有QR码格式的二维码 它可以使用任何ISO8859-1字符 并且可以编码一个最多拥有2953字符的字符串
        
        //在Swift中 使用如下方式定义两种商品条码的枚举:
        enum Barcode
        {
            case UPCA(Int, Int, Int, Int)
            case QRCode(String)
        }
        
        //定义一个名为Barcode的枚举类型 它可以是UPCA的一个相关值(Int, Int, Int, Int) 或者是QRCode的一个字符串类型(String)相关值
        
        var productBarcode = Barcode.UPCA(8, 85909, 51226, 3)
        //上例创建了一个名为productBarcode的变量 并且赋给它一个Barcode.UPCA的相关元组值(8, 85909, 51226, 3)
        
        //同一个商品可以被分配给一个不同类型的条形码 如:
        productBarcode = .QRCode("ABCDEFGHIJKLMNOP")
        
        //不同的类型可以使用switch语句来检查 相关值可以被提取作为switch语句的一部分 可以在switch的case分支代码中提取每个相关值作为一个常量或者作为一个变量来使用:
        switch productBarcode
        {
            case .UPCA(let numberSystem, let manufacturer, let product, let check):
            print("UPC-A: \(numberSystem), \(manufacturer), \(product), \(check).")
            case .QRCode(let productCode):
            print("QR code: \(productCode).")
        }
        
        //如果一个枚举成员的所有相关值都被提取为常量 或者全部被提取为变量 为了简洁可以只放置一个var或者let标注在成员名称前:
        switch productBarcode
        {
        case let .UPCA(numberSystem, manufacturer, product, check):
            print("UPC-A: \(numberSystem), \(manufacturer), \(product), \(check).")
        case let .QRCode(productCode):
            print("QR code: \(productCode).")
        }
        
        
        
        //4.原始值(Raw Values)
        
        //上面演示了一个枚举的成员如何声明 存储不同类型的相关值 作为相关值的另一种选择 枚举成员可以被默认值(原始值)赋值 其中这些原始值具有相同的类型
        
        //这里是一个枚举成员存储ASCII码的例子:
        enum ASCIIControlCharacter: Character
        {
            case Tab = "\t"
            case LineFeed = "\n"
            case CarriageReturn = "\r"
        }
        
        //原始值可以是字符串 字符 整型值或浮点型值 每个原始值在它的枚举声明中必须是唯一的
        
        
        
        //4.1原始值的隐式赋值(Implicitly Assigned Raw Values)
        
        //在使用原始值为整数或者字符串类型的枚举时 不需要显式的为每一个成员赋值 Swift会自动赋值
        
        //例如:当使用整数作为原始值时 隐式赋值的值依次递增1 如果第一个值没有被赋初值 将会被自动置为0:
        enum PlanetNew: Int
        {
            case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
        }
        
        //上例中Plant.Mercury赋了初值1 Planet.Venus会拥有隐式赋值2 依次类推
        
        //当使用字符串作为枚举类型的初值时 每个枚举成员的隐式初值则为该成员的名称:
        enum CompassPointNew: String
        {
            case North, South, East, West
        }
        
        //上例中CompassPoint.South拥有隐式初值South 依次类推
        
        //使用枚举成员的rawValue属性可以访问该枚举成员的原始值:
        let earthsOrder = PlanetNew.Earth.rawValue
        print(earthsOrder)
        
        let sunsetDirection = CompassPointNew.West.rawValue
        print(sunsetDirection)
        
        
        
        //4.2使用原始值初始化枚举变量(Initializing from a Raw Value)
        
        //如果在定义枚举类型的时候使用了原始值 那么将会自动获得一个初始化方法 这个方法将原始值类型作为参数 返回枚举成员或者nil 可以使用这种初始化方法来创建一个新的枚举变量
        
        //这个例子通过原始值7从而创建枚举成员:
        let possiblePlanet = PlanetNew(rawValue: 7)
        //possiblePlanet类型为Planet? 值为Planet.Uranus
        
        //然而 并非所有可能的Int值都可以找到一个匹配的行星 正因为如此 构造函数可以返回一个可选的枚举成员 在上面的例子中possiblePlanet是Planet?类型(可选的Planet)
        
        //注意:原始值构造器是一个可失败构造器 因为并不是每一个原始值都有与之对应的枚举成员(更多信息请参阅可失败构造器)
        
        //如果试图寻找一个位置为9的行星 通过参数为rawValue构造函数返回的可选Planet值将是nil:
        if let somePlanet = PlanetNew(rawValue: 9)
        {
            switch somePlanet
            {
            case .Earth:
                print("Mostly harmless")
            default:
                print("Not a safe place for humans")
            }
        }
        else
        {
            print("There isn't a planet at position 9")
        }
        
        //本例使用了可选绑定(optional binding)通过原始值9试图访问一个行星
        //if let somePlanet = Planet(rawValue: 9)语句获得一个可选Planet
        //如果可选Planet可以被获得 把somePlanet设置成该可选Planet的内容 本例中无法检索到位置为9的行星 else分支被执行
        
        
        
        //5.递归枚举(Recursive Enumerations)
        
        //递归枚举(recursive enumeration)是一种枚举类型 表示它的枚举中有一个或多个枚举成员拥有该枚举的其他成员作为相关值 使用递归枚举时编译器会插入一个中间层 可以在枚举成员前加上indirect来表示成员可递归:
        enum ArithmeticExpression
        {
            case Number(Int)
            indirect case Addition(ArithmeticExpression, ArithmeticExpression)
            indirect case Multiplication(ArithmeticExpression, ArithmeticExpression)
        }
        
        //也可以在枚举类型开头加上indirect关键字来表示它的所有成员都是可递归的:
        indirect enum ArithmeticExpressionNew
        {
            case Number(Int)
            case Addition(ArithmeticExpressionNew, ArithmeticExpressionNew)
            case Multiplication(ArithmeticExpressionNew, ArithmeticExpressionNew)
        }
        
        //上面定义的枚举类型可以存储三种算数表达式:纯数字 两个表达式相加 两个表达式相乘 Addition和Multiplication成员的相关值也是算数表达式 这些相关值使得嵌套表达式成为可能
        
        //递归函数可以很直观地使用具有递归性质的数据结构:
        func evaluate(expression: ArithmeticExpression) -> Int
        {
            switch expression
            {
            case .Number(let value):
                return value
            case .Addition(let left, let right):
                return evaluate(left) + evaluate(right)
            case .Multiplication(let left, let right):
                return evaluate(left) * evaluate(right)
            }
        }
        
        let five = ArithmeticExpression.Number(5)
        let four = ArithmeticExpression.Number(4)
        let sum = ArithmeticExpression.Addition(five, four)
        let product = ArithmeticExpression.Multiplication(sum, ArithmeticExpression.Number(2))
        print(evaluate(product))
    }
}