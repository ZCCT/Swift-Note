//
//  File.swift
//  Swift笔记24
//
//  Created by apple on 16/1/11.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
struct Stack<T>
{
    var items = [T]()
    
    mutating func push(item: T)
    {
        items.append(item)
    }
    
    mutating func pop() -> T
    {
        return items.removeLast()
    }
}

//代码2
extension Stack
{
    var topItem: T?
    {
        return items.isEmpty ? nil : items[items.count - 1]
    }
}

//代码3
protocol Container
{
    associatedtype ItemType
    
    mutating func append(item: ItemType)
    
    var count: Int { get }
    
    subscript(i: Int) -> ItemType { get }
}

//代码4
struct IntStackNew: Container
{
    //原始实现
    var items = [Int]()
    mutating func push(item: Int)
    {
        items.append(item)
    }
    mutating func pop() -> Int
    {
        return items.removeLast()
    }
    
    //遵循Container协议的实现
    typealias ItemType = Int
    
    mutating func append(item: Int)
    {
        self.push(item)
    }
    var count: Int
    {
        return items.count
    }
    subscript(i: Int) -> Int
    {
        return items[i]
    }
}

//代码5
struct StackNew<T>: Container
{
    //原始实现
    var items = [T]()
    mutating func push(item: T)
    {
        items.append(item)
    }
    mutating func pop() -> T
    {
        return items.removeLast()
    }
    
    //遵循Container协议的实现
    mutating func append(item: T)
    {
        self.push(item)
    }
    var count: Int
    {
        return items.count
    }
    subscript(i: Int) -> T
    {
        return items[i]
    }
}

//代码6
extension Array: Container
{
    
}