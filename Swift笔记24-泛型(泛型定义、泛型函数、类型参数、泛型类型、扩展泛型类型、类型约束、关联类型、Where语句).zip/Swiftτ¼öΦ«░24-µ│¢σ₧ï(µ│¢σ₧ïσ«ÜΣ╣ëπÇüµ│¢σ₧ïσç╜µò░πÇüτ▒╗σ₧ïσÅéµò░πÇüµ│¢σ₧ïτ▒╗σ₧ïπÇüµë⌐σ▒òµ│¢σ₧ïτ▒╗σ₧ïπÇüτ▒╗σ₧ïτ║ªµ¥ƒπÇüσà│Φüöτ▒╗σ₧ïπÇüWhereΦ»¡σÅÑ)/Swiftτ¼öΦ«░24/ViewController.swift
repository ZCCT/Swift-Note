//
//  ViewController.swift
//  Swift笔记24
//
//  Created by apple on 16/1/11.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //泛型(Generics)
        
        //用泛型可以写出根据需求定义 适用于任何类型 灵活且可重用的函数和类型
        
        //泛型是Swift的强大特征之一 许多Swift标准库是通过泛型代码构建出来的 例如:Swift的数组和字典类型都是泛型集
        
        
        
        //1.泛型所解决的问题
        
        //下例是一个非泛型函数swapTwoInts 用来交换两个Int值:
        func swapTwoInts(inout a: Int, inout _ b: Int)
        {
            let temporaryA = a
            a = b
            b = temporaryA
        }
        
        var someInt = 3
        var anotherInt = 107
        swapTwoInts(&someInt, &anotherInt)
        print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")
        
        //swapTwoInts函数只能交换Int值 如果想要交换String值或者Double值 就不得不写更多的函数:
        func swapTwoStrings(inout a: String, inout _ b: String)
        {
            let temporaryA = a
            a = b
            b = temporaryA
        }
        
        func swapTwoDoubles(inout a: Double, inout _ b: Double)
        {
            let temporaryA = a
            a = b
            b = temporaryA
        }
        
        //swapTwoInts swapTwoStrings swapTwoDoubles函数功能都是相同的 唯一不同之处在于传入的变量类型不同
        
        //实际应用中需要一个更为灵活的函数 可以用来交换两个任意类型值 泛型代码可以解决这个问题
        
        //注意:在这三个函数中 a和b的类型是一样的 如果a和b不是相同的类型 那它们就不能互换值 Swift是类型安全的语言它不允许一个String类型的变量和一个Double类型的变量交换值 否则将报编译错误
        
        
        
        //2.泛型函数
        
        //泛型函数可以用于任何类型:
        func swapTwoValues<T>(inout a: T, inout _ b: T)
        {
            let temporaryA = a
            a = b
            b = temporaryA
        }
        
        //该泛型函数使用了占位类型名字(通常用字母T来表示)来代替实际类型名(如:Int String Double) 占位类型名没有提示T必须是什么类型 但是它提示了a和b必须是同一类型T
        
        //swapTwoValues函数要求传入的两个任何类型值是同一类型:
        var someIntNew = 3
        var anotherIntNew = 107
        swapTwoValues(&someIntNew, &anotherIntNew)
        print("someIntNew is now \(someIntNew), and anotherIntNew is now \(anotherIntNew)")
        
        var someString = "hello"
        var anotherString = "world"
        swapTwoValues(&someString, &anotherString)
        print("someString is now \(someString), and anotherString is now \(anotherString)")
        
        
        
        //3.类型参数
        
        //上例中占位类型T是一种类型参数 类型参数指定并命名为一个占位类型 用一对尖括号括起来(如:<T>)紧跟在函数名后
        
        //一旦一个类型参数被指定 那么其可以被用来定义一个函数的参数类型 或作为一个函数的返回类型 或用作函数主体中的注释类型 在这种情况下 被类型参数所代表的占位类型不管函数任何时候被调用 都会被实际类型所替换
        
        //可以支持多个类型参数 命名在尖括号中 用逗号隔开
        
        
        
        //4.命名类型参数
        
        //泛型函数或泛型类型需要指定一个占位类型 通常用(T)来命名类型参数 也可以使用任何有效的标识符来作为类型参数名
        
        //如果使用多个参数定义更复杂的泛型函数或泛型类型 那么使用更多的描述类型参数是非常有用的
        
        //注意:请始终使用驼峰式命名法(例如:T Key)来给类型参数命名 以表明它们是类型的占位符 而非类型值
        
        
        
        //5.泛型类型
        
        //Swift允许自定义的泛型类型 这些自定义类 结构体和枚举作用于任何类型 如同Array和Dictionary的用法
        
        //栈(Stack)是一系列值域的集合 栈只允许在集合的末端添加新项 也只能从末端移除项
        
        //下例展示了一个非泛型版本的栈:
        struct IntStack
        {
            var items = [Int]()
            
            mutating func push(item: Int)
            {
                items.append(item)
            }
            
            mutating func pop() -> Int
            {
                return items.removeLast()
            }
        }
        
        //下例是一个相同代码的泛型版本:
        
        //⭐️代码1在File文件里⭐️
        
        //可以通过在尖括号里写出栈中需要存储的数据类型来创建并初始化一个Stack实例:
        var stackOfStrings = Stack<String>()
        
        //push四个值进栈:
        stackOfStrings.push("uno")
        stackOfStrings.push("dos")
        stackOfStrings.push("tres")
        stackOfStrings.push("cuatro")
        
        //从栈中pop并移除值"cuatro":
        let fromTheTop = stackOfStrings.pop()
        print("\(fromTheTop) was removed from the stack")
        
        
        
        //6.扩展一个泛型类型
        
        //扩展一个泛型类型时 并不需要在扩展的定义中提供类型参数列表 更加方便的是 原始类型定义中声明的类型参数列表在扩展中是可用的
        
        //下例扩展了泛型Stack类型 为其添加了一个名为topItem的只读计算属性 它会返回当前栈顶端的元素:
        
        //⭐️代码2在File文件里⭐️
        
        if let topItem = stackOfStrings.topItem
        {
            print("The top item on the stack is \(topItem).")
        }
        
        
        
        //7.类型约束
        
        //类型约束确定了一个必须继承自指定类的类型参数 或者遵循一个特定的协议
        
        //例如:Swift的Dictionary类型对作用于其键的类型做了限制 在字典的描述中:字典的键类型必须是可哈希的 也就是说必须有一种方法可以使其被唯一的表示
        
        //当创建自定义泛型类型时 可以自定义类型约束 当然 这些约束要支持泛型编程的强力特征中的多数
        
        
        
        //7.1类型约束语法
        
        //可以在类型参数名后添加类型约束 通过冒号(:)分割 来作为类型参数链的一部分:
//        func someFunction<T: SomeClass, U: SomeProtocol>(someT: T, someU: U)
//        {
//            //这里是函数主体
//        }
        
        
        
        //7.2类型约束行为
        
        //下例是一个名为findStringIndex的非泛型函数:
        func findStringIndex(array: [String], _ valueToFind: String) -> Int?
        {
            for (index, value) in array.enumerate()
            {
                if value == valueToFind
                {
                    return index
                }
            }
            return nil
        }
        
        let strings = ["cat", "dog", "llama", "parakeet", "terrapin"]
        if let foundIndex = findStringIndex(strings, "llama")
        {
            print("The index of llama is \(foundIndex)")
        }
        
        //下例是findStringIndex的泛型版本findIndex 这个函数不会编译(原因在下面说明):
//        func findIndex<T>(array: [T], _ valueToFind: T) -> Int?
//        {
//            for (index, value) in array.enumerate()
//            {
//                if value == valueToFind
//                {
//                    return index
//                }
//            }
//            return nil
//        }
        
        //上例的函数不会编译 问题在等式的检查上 "if value == valueToFind" 不是所有的Swift中的类型都可以用等式符(==)来进行比较 例如:当创建了一个自定义的类或结构体来表示一个复杂的数据模型 Swift无法推测对于这个类或结构体而言"等于"的意思 因此 当试图编译这部分代码时会出现相应的错误
        
        //不过 Swift标准库中定义了一个Equatable协议 该协议要求任何遵循的类型实现等于符(==)和不等于符(!=) 对任意两个该类型进行比较 所有的Swift标准类型自动支持Equatable协议:
        func findIndex<T: Equatable>(array: [T], _ valueToFind: T) -> Int?
        {
            for (index, value) in array.enumerate()
            {
                if value == valueToFind
                {
                    return index
                }
            }
            return nil
        }
        
        //findIndex中类型参数写做:(T: Equatable) 意思是:任何T类型都遵循Equatable协议
        
        //现在可以使用该泛型函数了:
        let doubleIndex = findIndex([3.14159, 0.1, 0.25], 9.3)
        print(doubleIndex)
        let stringIndex = findIndex(["Mike", "Malcolm", "Andrea"], "Malcolm")
        print(stringIndex!)
        
        
        
        //8.关联类型(Associated Types)
        
        //定义一个协议时 有时需要声明一个或多个关联类型作为协议定义的一部分 给定类型的一个占位名(别名)作用于关联类型上 实际类型在协议被实现前是不需要指定的 关联类型的关键字是:associatedtype
        
        
        
        //8.1关联类型行为
        
        //下例是一个名为Container的协议 定义了一个ItemType的关联类型:
        
        //⭐️代码3在File文件里⭐️
        
        //Container协议定义了三个任何容器必须支持的兼容要求:
        //(1)必须可以通过append方法添加一个新元素到容器里
        //(2)必须可以通过使用count属性获取容器里元素的数量 并返回一个Int值
        //(3)必须可以通过容器的Int索引值下标检索到每一个元素
        
        //该协议只指定了任何遵循本类型所必须要求的三个条件 任意遵循的类型在满足这三个条件时 也可以提供额外的功能
        
        //下面是一个IntStackNew类型的非泛型版本 遵循Container协议:
        
        //⭐️代码4在File文件里⭐️
        
        //IntStackNew类型实现了Container协议的要求 此外IntStackNew指定了Container的实现 ItemType被用作Int类型
        
        //由于Swift的类型参考 可以不用在IntStackNew的定义部分声明一个具体的Int类型的ItemType
        //由于IntStackNew遵循Container协议的所有要求 只要通过简单的查找append方法的item参数类型和下标返回的类型 Swift就可以推断出合适的ItemType来使用
        
        //也可以生成遵循Container协议的泛型StackNew类型:
        
        //⭐️代码5在File文件里⭐️
        
        //占位类型参数T被用作append方法的item参数和下标的返回类型 Swift可以推断出被用作这个特定容器的ItemType的T的合适类型
        
        
        
        //8.2扩展存在的类型为指定关联类型
        
        //Swift的Array已经满足了Container协议的所有要求 这意味着可以扩展Array去遵循Container协议:
        
        //⭐️代码6在File文件里⭐️
        
        
        
        //9.Where语句
        
        //可以在参数列表中通过where语句定义参数的约束 where语句能够使关联类型遵循特定的协议
        
        //下例定义了一个名为allItemsMatch的泛型函数:
        
        func allItemsMatch<C1: Container, C2: Container where C1.ItemType == C2.ItemType, C1.ItemType: Equatable>(someContainer: C1, _ anotherContainer: C2) -> Bool
        {
            if someContainer.count != anotherContainer.count
            {
                return false
            }
            
            for i in 0..<someContainer.count
            {
                if someContainer[i] != anotherContainer[i]
                {
                    return false
                }
            }
            
            return true
        }
        
        var stackOfStringsNew = StackNew<String>()
        stackOfStringsNew.push("uno")
        stackOfStringsNew.push("dos")
        stackOfStringsNew.push("tres")
        
        let arrayOfStrings = ["uno", "dos", "tres"]
        
        if allItemsMatch(stackOfStringsNew, arrayOfStrings)
        {
            print("All items match.")
        }
        else
        {
            print("Not all items match.")
        }
    }
}