//
//  ViewController.swift
//  Swift笔记03
//
//  Created by apple on 15/12/18.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //1.基本运算符(Basic Operators)
        
        //一元运算符对单一操作对象操作(如-a) 一元运算符分前置运算符和后置运算符 前置运算符需紧跟在操作对象之前(如!b) 后置运算符需紧跟在操作对象之后(如i++)
        //二元运算符操作两个操作对象(如2 + 3) 是中置的 因为它们出现在两个操作对象之间
        //三元运算符操作三个操作对象 和C语言一样 Swift只有一个三元运算符 就是三目运算符(a ? b : c)
        
        //受运算符影响的值叫操作数 在表达式1 + 2中 加号+是二元运算符 它的两个操作数是值1和2
        
        
        
        //1.1赋值运算符
        
        //赋值运算(a = b) 表示用b的值来初始化或更新a的值
//        let b = 10
//        var a = 5
//        a = b
        
        //如果赋值的右边是一个多元组 它的元素可以马上被分解成多个常量或变量
//        let (x, y) = (1, 2)
        
        //与C语言和OC不同 Swift的赋值操作并不返回任何值 所以以下代码是错误的:
        //由于if x = y是错误代码 这个特性使你无法把(==)错写成(=)
//        if x = y // 此句错误 因为x = y并不返回任何值
//        {
//        }
        
        
        
        //1.2算术运算符
        
        //Swift中所有数值类型都支持基本的四则算术运算:(+ - * /)
        //与C语言和OC不同的是 Swift默认情况下不允许在数值运算中出现溢出情况
        //但是可以使用Swift的溢出运算符来 实现溢出运算(如a &+ b)详情参见溢出运算符
        
        //加法运算符也可用于String的拼接:
//        "hello, " + "world" //等于"hello, world"
        
        //1.2.1求余运算符
        
        //求余运算(a % b)是计算b的多少倍刚刚好可以容入a 返回多出来的那部分(余数)
        9 % 4 //等于1
        -9 % 4 //等于-1
        
        //在对负数b求余时 b的符号会被忽略 这意味着a % b和a % -b的结果是相同的:
        9 % 4 == 9 % -4
        
        //不同于C语言和OC Swift中是可以对浮点数进行求余的:
        print(8 % 2.5) //等于0.5
        
        //1.2.2自增自减运算
        //和C语言一样 Swift也提供了对变量本身加1或减1的自增(++)和自减(--)的缩略算符 操作对象可以是整型和浮点型
        var i = 0
        ++i //现在i = 1
        
        //实际上++i是i = i + 1的简写 而--i是i = i - 1的简写
        //++和--既可以用作前置运算又可以用作后置运算 ++i i++ --i i--都是有效的写法
        
        //需要注意的是 这些运算符既可以修改i的值也可以返回i的值
        //如果只想修改i的值 就可以忽略这个返回值 但如果想使用返回值 就需要留意前置和后置操作的返回值是不同的
        //它们遵循以下原则:
        //当++前置的时候 先自増再返回
        //当++后置的时候 先返回再自增
        
        //例如:
//        var a = 0
//        let b = ++a //a = 1 b = 1
//        let c = a++ //a = 2 c = 1
        
        //上例中 let b = ++a 先把a加1 再返回a的值 所以a和b都是新值1
        //而let c = a++ 先返回了a的值 然后a才加1 所以c得到了a的旧值1 而a加1后变成2
        //除非需要使用i++的特性 不然推荐使用++i和--i 因为先修改后返回这样的行为更符合逻辑
        
        //1.2.3一元负号运算符
        
        //数值的正负号可以使用前缀-(即一元负号)来切换
//        let three = 3
//        let minusThree = -three       // minusThree = -3
//        let plusThree = -minusThree   // plusThree = 3
        //一元负号(-)写在操作数之前 中间没有空格
        
        //1.2.4一元正号运算符
        
        //一元正号(+)不做任何改变地返回操作数的值
//        let minusSix = -6
//        let alsoMinusSix = +minusSix  // alsoMinusSix = -6
        //虽然一元正号什么都不会改变 但当使用一元负号来表达负数时 可以使用一元正号来表达正数 如此代码会具有对称美
        
        
        
        //1.3复合赋值运算符(Compound Assignment Operators)
        //如同C语言 Swift也提供把其他运算符和赋值运算(=)组合的复合赋值运算符 组合加运算(+=)是其中一个例子:
//        var a = 1
//        a += 2 //a = 3
        
        //表达式a += 2是a = a + 2的简写 一个组合加运算就是把加法运算和赋值运算组合成进一个运算符里 同时完成两个运算任务
        //注意:复合赋值运算没有返回值 let b = a += 2这类代码是错误 这不同于上面提到的自增和自减运算符
        
        
        
        //1.4比较运算符
        
        //所有标准C语言中的比较运算都可以在Swift中使用:
        //等于 (a == b)
        //不等于 (a != b)
        //大于 (a > b)
        //小于 (a < b)
        //大于等于 (a >= b)
        //小于等于 (a <= b)
        
        //注意:Swift也提供恒等===和不恒等!==这两个比较符来判断两个对象是否引用同一个对象实例 更多细节在类与结构
        
        //每个比较运算都返回了一个标识表达式是否成立的布尔值:
        1 == 1 //true
        2 != 1 //true
        2 > 1 //true
        1 < 2 //true
        1 >= 1 //true
        2 <= 1 //false
        
        //比较运算多用于条件语句 如if条件:
        let name = "world"
        if name == "world"
        {
            print("hello, world")
        }
        else
        {
            print("I'm sorry \(name), but I don't recognize you")
        }
        
        
        
        //1.5三目运算符(Ternary Conditional Operator)
        
        //三目运算符的特殊在于它是有三个操作数的运算符 它的原型是:问题 ? 答案1 : 答案2 它简洁地表达根据问题成立与否作出二选一的操作 如果问题成立 返回答案1的结果 如果不成立 返回答案2的结果
        
        //三目运算符是以下代码的缩写形式:
//        if question
//        {
//            answer1
//        }
//        else
//        {
//            answer2
//        }
        
//        let contentHeight = 40
//        let hasHeader = true
//        let rowHeight = contentHeight + (hasHeader ? 50 : 20)
        
        //上面的写法比下面的代码更简洁:
//        let contentHeight = 40
//        let hasHeader = true
//        var rowHeight = contentHeight
//        if hasHeader
//        {
//            rowHeight = rowHeight + 50
//        }
//        else
//        {
//            rowHeight = rowHeight + 20
//        }
        
        //第一段代码使用了三目运算 这比第二段代码简洁得多 无需将rowHeight定义成变量 因为它的值无需在if语句中改变
        //需要注意的是 过度使用三目运算符会使代码变得难懂 应该避免在一个组合语句中使用多个三目运算符
        
        
        
        //1.6空合运算符(Nil Coalescing Operator)
        
        //空合运算符(a ?? b)将对可选类型a进行空判断 如果a包含一个值就进行解封 否则就返回一个默认值b
        //这个运算符有两个条件:
        //(1)表达式a必须是Optional类型
        //(2)默认值b的类型必须要和a存储值的类型保持一致
        
        //空合运算符是对以下代码的简短表达方法:
//        (a != nil) ? a! : b
        
        //注意:如果a为非空值 那么值b将不会被估值 这就是所谓的短路求值
        
        //下文例子采用空合运算符 实现了在默认颜色名和可选自定义颜色名之间选择:
        let defaultColorName = "red"
        var userDefinedColorName: String? //默认值为nil
        var colorNameToUse = userDefinedColorName ?? defaultColorName
        print(colorNameToUse)
        
        userDefinedColorName = "green"
        colorNameToUse = userDefinedColorName ?? defaultColorName
        print(colorNameToUse)
        
        
        
        //1.7区间运算符
        
        //1.7.1闭区间运算符
        
        //闭区间运算符(a...b)定义一个包含从a到b(包括a和b)的所有值的区间 (b必须大于等于a) 闭区间运算符在迭代一个区间的所有值时是非常有用的 如在for-in循环中:
        for index in 1...5
        {
            print("\(index) * 5 = \(index * 5)")
        }
        
        //1.7.2半开区间运算符
        
        //半开区间(a..<b)定义一个从a到b但不包括b的区间 之所以称为半开区间 是因为该区间包含第一个值而不包括最后的值
        
        //半开区间的实用性在于当使用一个从0开始的列表(如数组)时 非常方便地从0数到列表的长度
        let names = ["Anna", "Alex", "Brian", "Jack"]
        let count = names.count
        for i in 0..<count
        {
            print("第 \(i + 1) 个人叫 \(names[i])")
        }
        
        
        
        //1.8逻辑运算
        
        //逻辑运算的操作对象是逻辑布尔值 Swift支持基于C语言的三个标准逻辑运算
        //(1)逻辑非 (!a)
        //(2)逻辑与 (a && b)
        //(3)逻辑或 (a || b)
        
        //1.8.1逻辑非
        
        //逻辑非运算(!a)对一个布尔值取反 使得true变false false变true
        
        //它是一个前置运算符 需紧跟在操作数之前 且不加空格 读作非a 例子如下:
        let allowedEntry = false
        if !allowedEntry
        {
            print("ACCESS DENIED")
        }
        //小心地选择布尔常量或变量有助于代码的可读性 并且避免使用双重逻辑非运算 或混乱的逻辑语句
        
        //1.8.2逻辑与
        
        //逻辑与(a && b)表达了只有a和b的值都为true时 整个表达式的值才会是true
        
        //只要任意一个值为false 整个表达式的值就为false 事实上 如果第一个值为false 那么是不去计算第二个值的 因为它已经不可能影响整个表达式的结果了 这被称做"短路计算(short-circuit evaluation)"
        let enteredDoorCode = true
        let passedRetinaScan = false
        if enteredDoorCode && passedRetinaScan
        {
            print("Welcome!")
        }
        else
        {
            print("ACCESS DENIED")
        }
        
        //1.8.3逻辑或
        
        //逻辑或(a || b)是一个由两个连续的|组成的中置运算符 它表示两个逻辑表达式的其中一个为true 整个表达式就为true 逻辑或也是"短路计算"的
        let hasDoorKey = false
        let knowsOverridePassword = true
        if hasDoorKey || knowsOverridePassword
        {
            print("Welcome!")
        }
        else
        {
            print("ACCESS DENIED")
        }
        
        //1.8.4逻辑运算符组合计算
        
        //可以组合多个逻辑运算来表达一个复合逻辑:
        if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword
        {
            print("Welcome!")
        }
        else
        {
            print("ACCESS DENIED")
        }
        
        //注意:Swift中逻辑操作符&&和||是左结合的 这意味着拥有多元逻辑操作符的复合表达式优先计算最左边的子表达式
        
        //为了一个复杂表达式更容易读懂 在合适的地方使用括号来明确优先级是很有效的 虽然它并非必要的 在上个关于门的权限的例子中 我们给第一个部分加个括号 使它看起来逻辑更明确:
        
        if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword
        {
            print("Welcome!")
        }
        else
        {
            print("ACCESS DENIED")
        }
    }
}