//
//  ViewController.swift
//  Swift笔记13
//
//  Created by apple on 15/12/30.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //下标脚本(Subscripts)
        
        //下标脚本可以定义在类(Class) 结构体(structure) 枚举(enumeration)这些目标中 是访问集合(collection) 列表(list) 序列(sequence)的快捷方式 使用下标脚本的索引设置和获取值 不需要再调用实例的特定的赋值和访问方法
        
        
        
        //1.下标脚本语法
        
        //下标脚本允许通过在实例后面的方括号中传入一个或者多个的索引值来对实例进行访问和赋值 语法类似于实例方法和计算型属性的混合
        //与定义实例方法类似 定义下标脚本使用subscript关键字 显式声明入参(一个或多个)和返回类型 与实例方法不同的是下标脚本可以设定为读写或只读 这种方式又类似于计算型属性的getter和setter:
//        subscript(index: Int) -> Int
//        {
//            get
//            {
//                //返回与入参匹配的Int类型的值
//            }
//            set(newValue)
//            {
//                //执行赋值操作
//            }
//        }
        
        //newValue的类型必须和下标脚本定义的返回类型相同 与计算型属性相同的是set的入参声明newValue即使不写 在set代码块中依然可以使用默认的newValue这个变量来访问新赋的值
        
        //与只读计算型属性一样 可以直接将原本应该写在get代码块中的代码写在subscript中:
//        subscript(index: Int) -> Int
//        {
//            //返回与入参匹配的Int类型的值
//        }
        
        //下例演示了一个在TimesTable结构体中使用只读下标脚本的用法 该结构体用来展示传入整数的n倍:
        struct TimesTable
        {
            let multiplier: Int
            
            subscript(index: Int) -> Int
            {
                return multiplier * index
            }
        }
        
        let threeTimesTable = TimesTable(multiplier: 3)
        print("3的6倍是\(threeTimesTable[6])")
        
        //上例通过下标脚本来得到结果 如:threeTimesTable[6]这条语句访问了threeTimesTable的第7个元素 返回18
        
        
        
        //2.下标脚本用法
        
        //使用场景不同下标脚本也具有不同的含义 通常下标脚本是用来访问集合(collection) 列表(list) 序列(sequence)中元素的快捷方式:
        var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
        numberOfLegs["bird"] = 2
        print(numberOfLegs["bird"])
        
        //上例定义了一个名为numberOfLegs的变量并用一个字典字面量初始化了包含三对键值的字典实例 numberOfLegs的字典存放值类型推断为[String:Int] 字典实例创建完成之后通过下标脚本的方式将整型值2赋值到字典实例的索引为bird的位置中
        
        //注意:Swift中字典的附属脚本实现中 在get部分返回值是Int? 上例中的numberOfLegs字典通过附属脚本返回的是一个Int?(可选的Int) 不是每个字典的索引都能得到一个整型值 对于没有值的索引的访问返回的结果就是nil 同样 想要从字典实例中删除某个索引下的值只需要给这个索引赋值为nil即可
        
        
        
        //3.下标脚本选项
        
        //下标脚本允许任意数量的入参索引 并且每个入参类型也没有限制 下标脚本的返回值也可以是任何类型 下标脚本可以使用变量参数和可变参数 但使用输入输出(in-out)参数或给参数设置默认值都是不允许的
        
        //一个类或结构体可以根据自身需要提供多个下标脚本实现 在定义下标脚本时通过入参的类型进行区分 使用下标脚本时会自动匹配合适的下标脚本实现运行 这就是下标脚本的重载
        
        //一个下标脚本入参是最常见的情况 但只要有合适的场景也可以定义多个下标脚本入参 下例定义了一个Matrix结构体呈现一个Double类型的二维矩阵 Matrix结构体的下标脚本需要两个整型参数:
        struct Matrix
        {
            let rows: Int, columns: Int
            var grid: [Double]
            
            init(rows: Int, columns: Int)
            {
                self.rows = rows
                self.columns = columns
                grid = Array(count: rows * columns, repeatedValue: 0.0)
            }
            
            func indexIsValid(row row: Int, column: Int) -> Bool
            {
                return row >= 0 && row < rows && column >= 0 && column < columns
            }
            
            subscript(row: Int, column: Int) -> Double
            {
                get
                {
                    assert(indexIsValid(row: row, column: column), "Index out of range")
                    return grid[(row * columns) + column]
                }
                set
                {
                    assert(indexIsValid(row: row, column: column), "Index out of range")
                    grid[(row * columns) + column] = newValue
                }
            }
        }
        
        var matrix = Matrix(rows: 2, columns: 2)
        
        //将值赋给带有row和column下标脚本的matrix实例表达式可以完成赋值操作 下标脚本入参使用逗号分割:
        matrix[0, 1] = 1.5
        matrix[1, 0] = 3.2
        
        //断言在下标脚本越界时触发:
//        let someValue = matrix[2, 2]
    }
}