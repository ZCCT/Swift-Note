//
//  ViewController.swift
//  Swift笔记21
//
//  Created by apple on 16/1/7.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //嵌套类型(Nested Types)
        
        //枚举类型常被用于实现特定类或结构体的功能 也能够在有多种变量类型的环境中 方便地定义通用类或结构体来使用 为了实现这种功能 Swift允许定义嵌套类型 可以在枚举/类/结构体中定义支持嵌套的类型
        
        
        
        //1.嵌套类型实例
        
        //下例定义了一个结构体BlackJackCard 包含2个嵌套定义的枚举类型Suit和Rank:
        struct BlackJackCard
        {
            enum Suit: Character //嵌套定义枚举型Suit
            {
                case Spades = "♠", Hearts = "♡", Diamonds = "♢", Clubs = "♣"
            }
            
            enum Rank: Int //嵌套定义枚举型Rank
            {
                case Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten
                case Jack, Queen, King, Ace
                
                struct Values
                {
                    let first: Int, second: Int?
                }
                
                var values: Values
                {
                    switch self
                    {
                    case .Ace:
                        return Values(first: 1, second: 11)
                    case .Jack, .Queen, .King:
                        return Values(first: 10, second: nil)
                    default:
                        return Values(first: self.rawValue, second: nil)
                    }
                }
            }
            
            //BlackJackCard的属性和方法:
            let rank: Rank, suit: Suit
            var description: String
            {
                var output = "suit is \(suit.rawValue),"
                output += " value is \(rank.values.first)"
                if let second = rank.values.second
                {
                    output += " or \(second)"
                }
                return output
            }
        }
        
        let theAceOfSpades = BlackJackCard(rank: .Ace, suit: .Spades)
        print("theAceOfSpades: \(theAceOfSpades.description)")
        
        //尽管Rank和Suit嵌套在BlackJackCard中 但仍可被引用 所以在初始化实例时能够通过枚举类型中的成员名称单独引用
        
        
        
        //2.嵌套类型的引用
        
        //在外部对嵌套类型的引用 以被嵌套类型的名字为前缀 加上所要引用的属性名:
        let heartsSymbol = BlackJackCard.Suit.Hearts.rawValue
        print(heartsSymbol)
    }
}