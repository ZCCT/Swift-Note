//
//  ViewController.swift
//  Swift笔记02
//
//  Created by apple on 15/12/17.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //1.元组(tuples)把多个值组合成一个复合值 元组内的值可以是任意类型
        
        //http404Error的类型是(Int, String) 值是(404, "Not Found")
        let http404Error = (404, "Not Found")
        
        //可以将一个元组的内容分解(decompose)成单独的常量和变量 然后使用
        let (statusCode, statusMessage) = http404Error
        print("The status code is \(statusCode)")
        print("The status message is \(statusMessage)")
        
        //如果只需要一部分元组值 分解的时候可以把要忽略的部分用下划线(_)标记
        let (justTheStatusCode, _) = http404Error
        print("The status code is \(justTheStatusCode)")
        
        //此外 还可以通过下标来访问元组中的单个元素 下标从零开始
        print("The status code is \(http404Error.0)")
        print("The status message is \(http404Error.1)")
        
        //可以在定义元组的时候给单个元素命名
        let http200Status = (statusCode: 200, description: "OK")
        print("The status code is \(http200Status.statusCode)")
        print("The status message is \(http200Status.description)")
        
        //元组在临时组织值的时候很有用 但是并不适合创建复杂的数据结构 如果数据结构不是临时使用 请使用类或结构体
        
        
        
        //2.可选类型
        
        //使用可选类型(optionals)来处理值可能缺失的情况 可选类型表示:有值(等于x) 或 没有值
        
        //convertedNumber被推测为类型:"Int?" 或者类型:"optional Int"
        //因为该构造器可能会失败 所以它返回一个可选类型(optional)Int 而不是一个Int 
        //一个可选的Int被写作Int?而不是Int 问号暗示包含的值是可选类型 也就是说可能包含Int值也可能不包含值(不能包含其他任何值比如Bool值或者String值 只能是Int或者什么都没有)
        let possibleNumber = "123"
        let convertedNumber = Int(possibleNumber)
        print("convertedNumber is \(convertedNumber)")
        
        //可以给可选变量赋值为nil来表示它没有值:
        var serverResponseCode: Int? = 404 //包含一个可选的Int值404
        serverResponseCode = nil //不包含值
        
        //nil不能用于非可选的常量和变量 如果有常量或者变量需要处理值缺失的情况 请把它们声明成对应的可选类型
        
        //如果声明可选常量或者变量但是没有赋值 它们会自动被设置为nil:
        var surveyAnswer: String?
        print("the value of surveyAnswer is \(surveyAnswer)")
        
        //Swift的nil和OC的nil并不一样 在OC中nil是一个指向不存在对象的指针 在Swift中nil不是指针 它是一个确定的值 用来表示值缺失 任何类型的可选状态都可以被设置为nil 不只是对象类型
        
        
        
        //3.if语句和强制解析
        
        //可以使用if语句和nil比较来判断一个可选值是否包含值 可以用"相等"(==)或"不等"(!=)来执行比较
        if convertedNumber != nil
        {
            print("convertedNumber contains some integer value.")
        }
        
        //当确定可选类型确实包含值之后 可以在可选的名字后面加一个感叹号(!)来获取值 这被称为可选值的强制解析(forced unwrapping)
        //使用!来获取一个不存在的可选值会导致运行时错误
        if convertedNumber != nil
        {
            print("convertedNumber has an integer value of \(convertedNumber!).")
        }
        
        
        
        //4.可选绑定
        
        //使用可选绑定(optional binding)来判断可选类型是否包含值 如果包含就把值赋给一个临时常量或者变量
        //可选绑定可以用在if和while语句中 来对可选类型的值进行判断并把值赋给一个常量或者变量
        
        //这段代码可以理解为:如果Int(possibleNumber)返回的可选Int包含一个值 创建一个叫做actualNumber的新常量并将可选包含的值赋给它
        //如果转换成功 actualNumber常量可以在if语句的第一个分支中使用 它已经被可选类型包含的值初始化过了 所以不需要再使用!后缀来强制解析获取它的值
        if let actualNumber = Int(possibleNumber)
        {
            print("\'\(possibleNumber)\' has an integer value of \(actualNumber)")
        }
        else
        {
            print("\'\(possibleNumber)\' could not be converted to an integer")
        }
        
        
        
        //5.隐式解析可选类型
        
        //有时在程序中 第一次被赋值之后 可以确定一个可选类型总会有值 在这种情况下 每次都要判断和解析可选值是非常低效的 因为可以确定它总会有值
        
        //这种类型的可选状态被定义为隐式解析可选类型(implicitly unwrapped optionals) 把想要用作可选的类型的后面的问号"?"改成"!"来声明一个隐式解析可选类型
        
        //隐式解析可选类型主要被用在Swift中类的构造过程中 请参考无主引用和隐式解析可选属性
        
        //一个隐式解析可选类型其实就是一个普通的可选类型 但是可以被当做非可选类型来使用 并不需要每次都使用解析来获取可选值 下面的例子展示了可选类型String和隐式解析可选类型String之间的区别:
        let possibleString: String? = "An optional string."
        print(possibleString!) //需要强制解析来获取值
        
        let assumedString: String! = "An implicitly unwrapped optional string."
        print(assumedString) //不需要强制解析
        
        //仍然可以把隐式解析可选类型当做普通可选类型来判断它是否包含值:
        if assumedString != nil
        {
            print(assumedString)
        }
        
        //也可以在可选绑定中使用隐式解析可选类型来检查并解析它的值:
        if let definiteString = assumedString
        {
            print(definiteString)
        }
        
        //如果一个变量之后可能变成nil的话请不要使用隐式解析可选类型 如果需要在变量的生命周期中判断是否是nil的话 请使用普通可选类型
        
        
        
        //6.错误处理(error handling)
        
        //相对于可选中运用值的存在与缺失来表达函数的成功与失败 错误处理可以推断失败的原因 并传送至程序的其他部分
        
        //当一个函数遇到错误条件 它能报错 调用函数的地方能抛出错误消息并合理处理
        func canThrowAnErrow() throws
        {
            //这个函数有可能抛出错误
        }
        //一个函数可以通过在声明中添加throws关键词来抛出错误消息 当函数能抛出错误消息时 应该在表达式中前置try关键词
        
        do
        {
            try canThrowAnErrow() //没有错误消息抛出
        }
        catch
        {
            //有一个错误消息抛出
        }
        //一个do语句创建了一个新的包含作用域 使得错误能被传播到一个或多个catch从句
        
        
        
        //7.断言
        
        //可选类型可以判断值是否存在 然而 在某些情况下 如果值缺失或者值并不满足特定的条件 代码可能没办法继续执行 这时 可以在代码中触发一个断言(assertion)来结束代码运行并通过调试来找到值缺失的原因
        
        //在这个例子中 只有age >= 0为true的时候 代码才会继续执行 如果age的值是负数 断言被触发 终止应用
        let age = 3
        assert(age >= 0, "A person's age cannot be less than zero")
        
        //如果不需要断言信息 可以省略:
        assert(age >= 0)
     }
}