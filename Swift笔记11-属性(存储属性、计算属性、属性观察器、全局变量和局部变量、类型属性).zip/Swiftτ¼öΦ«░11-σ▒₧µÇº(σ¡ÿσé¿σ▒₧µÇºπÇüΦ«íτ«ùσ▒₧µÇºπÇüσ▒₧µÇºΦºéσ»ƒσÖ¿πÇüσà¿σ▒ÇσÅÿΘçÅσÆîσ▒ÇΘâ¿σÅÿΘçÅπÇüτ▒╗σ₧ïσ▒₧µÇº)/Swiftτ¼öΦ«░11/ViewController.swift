//
//  ViewController.swift
//  Swift笔记11
//
//  Created by apple on 15/12/29.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //属性(Properties)
        
        //属性将值跟特定的类 结构体或枚举关联
        
        //存储属性存储常量或变量作为实例的一部分
        //计算属性计算一个值 计算属性可以用于类 结构体和枚举 存储属性只能用于类和结构体(⭐️)
        
        //存储属性和计算属性通常与特定类型的实例关联
        //属性也可以直接用于类型本身 这种属性称为类型属性
        
        //可以定义属性观察器来监控属性值的变化 以此来触发一个操作 属性观察器可以添加到自定义的存储属性上 也可以添加到从父类继承的属性上
        
        
        
        //1.存储属性
        
        //简单来说 一个存储属性就是存储在特定类或结构体的实例里的一个常量或变量 存储属性可以是变量存储属性(用关键字var定义) 也可以是常量存储属性(用关键字let定义)
        
        //可以在定义存储属性的时候指定默认值(请参考默认属性值一节) 也可以在构造过程中设置或修改存储属性的值 甚至修改常量存储属性的值(请参考在初始化阶段修改常量存储属性一节)
        
        //下例定义了一个名为FixedLengthRange的结构体 它描述了一个在创建后无法修改值域宽度的区间:
        struct FixedLengthRange
        {
            var firstValue: Int
            let length: Int
        }
        
        var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
        //该区间表示整数0 1 2
        rangeOfThreeItems.firstValue = 6
        //该区间现在表示整数6 7 8
        
        //FixedLengthRange实例包含一个名为firstValue的变量存储属性和一个名为length的常量存储属性 上例中length在创建实例的时候被初始化 因为它是一个常量存储属性 所以之后无法被修改
        
        
        
        //1.1常量结构体的存储属性
        
        //如果创建了一个结构体的实例并将其赋值给一个常量 则无法修改该实例的任何属性 即使定义了变量存储属性也不行:
//        let rangeOfFourItems = FixedLengthRange(firstValue: 0, length: 4)
//        rangeOfFourItems.firstValue = 6
        
        //因为rangeOfFourItems被声明成了常量 即使firstValue是一个变量属性 也无法修改
        
        //由于结构体属于值类型 当值类型的实例被声明为常量的时候 它的所有属性也就成了常量
        //引用类型则不一样 把一个引用类型的实例赋给一个常量后 仍然可以修改该实例的变量属性
        
        
        
        //1.2延迟存储属性
        
        //延迟存储属性是指当第一次被调用的时候才会计算其初始值的属性 在属性声明前使用lazy来标示一个延迟存储属性
        
        //注意:必须将延迟存储属性声明成变量(使用var关键字) 因为属性的初始值可能在实例构造完成之后才会得到 而常量属性在构造过程完成之前必须要有初始值 因此无法声明成延迟属性(⭐️)
        
        //延迟属性很有用 当属性的值依赖于在实例的构造过程结束后才会知道具体值的外部因素时 或者当获得属性的初始值需要复杂或大量计算时 可以只在需要的时候计算它
        
        //下例使用了延迟存储属性来避免复杂类中不必要的初始化:
        class DataImporter
        {
            /*
            DataImporter是一个将外部文件中的数据导入的类
            这个类的初始化会消耗不少时间
            */
            var fileName = "data.txt"
            //提供数据导入功能
        }
        
        class DataManager
        {
            lazy var importer = DataImporter()
            var data = [String]()
            //提供数据管理功能
        }
        
        let manager = DataManager()
        manager.data.append("Some data")
        manager.data.append("Some more data")
        //此时 DataImporter实例的importer属性还没有被创建⭐️
        //当DataManager的实例被创建时 没必要创建一个DataImporter的实例 应当第一次用到DataImporter的时候才去创建它
        
        //由于使用了lazy importer属性只有在第一次被访问的时候才被创建:
        print(manager.importer.fileName)
        //此时 DataImporter实例的importer属性被创建了⭐️
        
        //注意:如果一个被标记为lazy的属性在没有初始化时就同时被多个线程访问 则无法保证该属性只会被初始化一次
        
        
        
        //1.3存储属性和实例变量
        
        //Objective-C为类实例存储值和引用提供两种方法 对于属性来说 也可以使用实例变量作为属性值的后端存储
        
        //Swift把这些理论统一用属性来实现 Swift中的属性没有对应的实例变量 属性的后端存储也无法直接访问 这就避免了不同场景下访问方式的困扰 同时也将属性的定义简化成一个语句 一个类型中属性的全部信息:命名 类型和内存管理特征都在唯一一个地方(类型定义中)定义
        
        
        
        //2.计算属性
        
        //类 结构体和枚举可以定义计算属性 计算属性不直接存储值 而是提供一个getter和一个可选的setter来间接获取和设置其他属性或变量的值:
        struct Point
        {
            var x = 0.0, y = 0.0
        }
        
        struct Size
        {
            var width = 0.0, height = 0.0
        }
        
        struct Rect
        {
            var origin = Point()
            var size = Size()
            
            var center: Point
            {
                get
                {
                    let centerX = origin.x + (size.width / 2)
                    let centerY = origin.y + (size.height / 2)
                    return Point(x: centerX, y: centerY)
                }
                set(newCenter)
                {
                    origin.x = newCenter.x - (size.width / 2)
                    origin.y = newCenter.y - (size.height / 2)
                }
            }
        }
        
        var square = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
        print(square.center) //getter
        square.center = Point(x: 15.0, y: 15.0) //setter
        print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
        
        //上例创建了一个名为square的Rect实例 初始值原点是(0, 0) 宽高都是10
        
        //square的center属性可以通过点运算符(square.center)来访问 这会调用该属性的getter来获取它的值 跟直接返回已经存在的值不同 getter实际上通过计算然后返回一个新的Point来表示square的中心点
        
        //center属性之后被设置了一个新值(15, 15) 设置属性center的值会调用它的setter来修改属性origin的x和y的值
        
        
        
        //2.1便捷setter声明
        
        //如果计算属性的setter没有定义表示新值的参数名 则可以使用默认名称newValue 下面是使用了便捷setter声明的Rect结构体代码:
        struct AlternativeRect
        {
            var origin = Point()
            var size = Size()
            
            var center: Point
            {
                get
                {
                    let centerX = origin.x + (size.width / 2)
                    let centerY = origin.y + (size.height / 2)
                    return Point(x: centerX, y: centerY)
                }
                set
                {
                    origin.x = newValue.x - (size.width / 2)
                    origin.y = newValue.y - (size.height / 2)
                }
            }
        }
        
        //2.2只读计算属性
        
        //只有getter没有setter的计算属性就是只读计算属性 只读计算属性总是返回一个值 可以通过点运算符访问 但不能设置新值
        
        //注意:必须使用var关键字定义计算属性 包括只读计算属性 因为它们的值不是固定的
        //let关键字只用来声明常量属性 表示初始化后再也无法修改的值
        
        //只读计算属性的声明可以去掉get关键字和花括号
        
        //下例定义了一个名为Cuboid的结构体 表示三维空间的立方体 有width height depth属性 结构体还有一个名为volume的只读计算属性用来返回立方体的体积:
        struct Cuboid
        {
            var width = 0.0, height = 0.0, depth = 0.0
            
            var volume: Double
            {
                return width * height * depth
            }
        }
        
        let cuboid = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
        print("the volume of cuboid is \(cuboid.volume)")
        
        
        
        //3.属性观察器
        
        //属性观察器监控和响应属性值的变化 每次属性被设置值的时候都会调用属性观察器
        
        //可以为除了延迟存储属性之外的其他存储属性添加属性观察器 也可以通过重载属性的方式为继承的属性(包括存储属性和计算属性)添加属性观察器(属性重载请参考重载)
        
        //注意:不需要为非重载的计算属性添加属性观察器 因为它可以通过setter直接监控和响应值的变化
        
        //可以为属性添加如下的一个或全部观察器:
        //(1)willSet在新的值被设置之前调用
        //(2)didSet在新的值被设置之后立即调用
        
        //willSet观察器会将新的属性值作为常量参数传入 在willSet的实现代码中可以为这个参数指定一个名称 如果不指定则参数仍然可用 这时使用默认名称newValue表示
        
        //类似 didSet观察器会将旧的属性值作为参数传入 可以为该参数命名或者使用默认参数名oldValue
        
        //注意:父类的属性在子类的构造器中被赋值时 它在父类中的willSet和didSet观察器会被调用(更多信息请参考值类型的构造器代理和类的构造器代理规则)
        
        //StepCounter类定义了一个Int类型的属性totalSteps 它是一个存储属性 包含willSet和didSet观察器:
        class StepCounter
        {
            var totalSteps: Int = 0
            {
                willSet(newTotalSteps)
                {
                    print("Will set totalSteps to \(newTotalSteps)")
                }
                
                didSet
                {
                    if totalSteps > oldValue
                    {
                        print("Added \(totalSteps - oldValue) steps")
                    }
                }
            }
        }
        
        let stepCounter = StepCounter()
        stepCounter.totalSteps = 200
        stepCounter.totalSteps = 360
        stepCounter.totalSteps = 896
        //注意:如果在一个属性的didSet观察器里为它赋值 这个值会替换该观察器之前设置的值
        
        
        
        //4.全局变量和局部变量
        
        //计算属性和属性观察器所描述的模式也可以用于全局变量和局部变量 全局变量是在函数 方法 闭包或任何类型外部定义的变量 局部变量是在函数 方法或闭包内部定义的变量
        
        //全局变量或局部变量都属于存储型变量 跟存储属性类似 它提供特定类型的存储空间 并允许读取和写入
        
        //在全局或局部范围都可以定义计算型变量和为存储型变量定义观察器 计算型变量跟计算属性一样 返回一个计算的值而不是存储值 声明格式也完全一样
        
        //注意:全局的常量或变量都是延迟计算的 跟延迟存储属性相似 不同的是全局常量或变量不需要标记lazy特性 局部范围的常量或变量不会延迟计算
        
        
        
        //5.类型属性
        
        //实例的属性属于一个特定类型实例 每次类型实例化后都拥有自己的一套属性值 实例之间的属性相互独立
        
        //也可以为类型本身定义属性 不管类型有多少个实例 这些属性都只有唯一一份 这种属性就是类型属性
        
        //类型属性用于定义特定类型所有实例共享的数据 比如所有实例都能用的一个常量(就像C语言中的静态常量) 或者所有实例都能访问的一个变量(就像C语言中的静态变量)
        
        //值类型的存储型类型属性可以是变量或常量 计算型类型属性跟实例的计算属性一样只能定义成变量属性
        
        //注意:跟实例的存储属性不同 必须给存储型类型属性指定默认值 因为类型本身无法在初始化过程中使用构造器给类型属性赋值
        
        
        
        //5.1类型属性语法
        
        //在C或Objective-C中 与某个类型关联的静态常量和静态变量 是作为全局(global)静态量定义的 但是在Swift中类型属性是作为类型定义的一部分写在类型最外层的花括号内 因此它的作用范围也就在类型支持的范围内
        
        //使用关键字static来定义类型属性 在为类(class)定义计算型类型属性时 可以使用关键字class来支持子类对父类的实现进行重写 下例演示了存储型和计算型类型属性的语法:
        struct SomeStructure
        {
            static var storedTypeProperty = "Some value."
            static var computedTypeProperty: Int
            {
                return 1
            }
        }
        
        enum SomeEnumeration
        {
            static var storedTypeProperty = "Some value."
            static var computedTypeProperty: Int
            {
                return 2
            }
        }
        
        class SomeClass
        {
            static var storedTypeProperty = "Some value."
            static var computedTypeProperty: Int
            {
                return 3
            }
            
            class var overrideableComputedTypeProperty: Int
            {
                return 4
            }
        }
        //注意:上例中的计算型类型属性是只读的 但也可以定义可读可写的计算型类型属性 跟实例计算属性的语法类似
        
        
        
        //5.2获取和设置类型属性的值
        
        //跟实例属性一样 类型属性的访问也是通过点运算符来进行 但是类型属性是通过类型本身来获取和设置 而不是通过实例:
        print(SomeStructure.storedTypeProperty)
        SomeStructure.storedTypeProperty = "Another value."
        print(SomeStructure.storedTypeProperty)
        print(SomeEnumeration.computedTypeProperty)
        print(SomeClass.computedTypeProperty)
        
        //下例定义了一个结构体 使用两个存储型类型属性来表示多个声道的声音电平值 每个声道有一个0到10之间的整数表示声音电平值:
        struct AudioChannel
        {
            static let thresholdLevel = 10
            static var maxInputLevelForAllChannels = 0
            
            var currentLevel: Int = 0
            {
                didSet
                {
                    if currentLevel > AudioChannel.thresholdLevel
                    {
                        //将新电平值设置为阀值
                        currentLevel = AudioChannel.thresholdLevel
                    }
                    if currentLevel > AudioChannel.maxInputLevelForAllChannels
                    {
                        //存储当前电平值作为新的最大输入电平
                        AudioChannel.maxInputLevelForAllChannels = currentLevel
                    }
                }
            }
        }
        //AudioChannel也定义了一个名为currentLevel的实例存储属性 表示当前声道现在的电平值 属性currentLevel包含didSet属性观察器来检查每次新设置后的属性值
        
        //注意:在第一个检查过程中 didSet属性观察器将currentLevel设置成了不同的值 但此时不会再次调用属性观察器
        
        //用结构体AudioChannel来创建表示立体声系统的两个声道leftChannel和rightChannel:
        var leftChannel = AudioChannel()
        var rightChannel = AudioChannel()
        
        //如果将左声道的电平设置成7 类型属性maxInputLevelForAllChannels也会更新成7:
        leftChannel.currentLevel = 7
        print(leftChannel.currentLevel)
        print(AudioChannel.maxInputLevelForAllChannels)
        
        //将右声道的电平设置成11 右声道的currentLevel被修正到最大值10 同时maxInputLevelForAllChannels的值也会更新到10:
        rightChannel.currentLevel = 11
        print(rightChannel.currentLevel)
        print(AudioChannel.maxInputLevelForAllChannels)
    }
}