//
//  File.swift
//  Swift笔记26
//
//  Created by apple on 16/1/14.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
struct Vector2D
{
    var x = 0.0, y = 0.0
}

func + (left: Vector2D, right: Vector2D) -> Vector2D
{
    return Vector2D(x: left.x + right.x, y: left.y + right.y)
}

//代码2
prefix func - (vector: Vector2D) -> Vector2D
{
    return Vector2D(x: -vector.x, y: -vector.y)
}

//代码3
func += (inout left: Vector2D, right: Vector2D)
{
    left = left + right
}

//加法运算之前已经定义过了 所以这里无需重新定义 可以直接利用现有的加法运算符函数

//代码4
prefix func ++ (inout vector: Vector2D) -> Vector2D
{
    vector += Vector2D(x: 1.0, y: 1.0)
    return vector
}

//该前缀自增运算符使用了之前定义的加法赋值运算符函数

//代码5
func == (left: Vector2D, right: Vector2D) -> Bool
{
    return (left.x == right.x) && (left.y == right.y)
}

func != (left: Vector2D, right: Vector2D) -> Bool
{
    return !(left == right)
}

//代码6
prefix operator +++ {}

prefix func +++ (inout vector: Vector2D) -> Vector2D
{
    vector += vector
    return vector
}

//代码7
infix operator +- { associativity left precedence 140 }

func +- (left: Vector2D, right: Vector2D) -> Vector2D
{
    return Vector2D(x: left.x + right.x, y: left.y - right.y)
}