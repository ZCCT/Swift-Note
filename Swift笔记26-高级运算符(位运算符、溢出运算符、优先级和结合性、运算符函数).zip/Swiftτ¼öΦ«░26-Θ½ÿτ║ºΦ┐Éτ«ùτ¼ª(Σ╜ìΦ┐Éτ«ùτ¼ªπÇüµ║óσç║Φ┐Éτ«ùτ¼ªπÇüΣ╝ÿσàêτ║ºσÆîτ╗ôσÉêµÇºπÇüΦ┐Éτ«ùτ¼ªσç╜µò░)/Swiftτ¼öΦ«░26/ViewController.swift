//
//  ViewController.swift
//  Swift笔记26
//
//  Created by apple on 16/1/13.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //高级运算符(Advanced Operators)
        
        //与C语言的算术运算符不同 Swift的算术运算符默认是不会溢出的 所有溢出行为都会被捕获并报告为错误 如果想让系统允许溢出行为 可以选择使用Swift中另一套默认支持溢出的运算符 所有的这些溢出运算符都是以(&)开头的 例如:溢出加法运算符(&+)
        
        //Swift可以自由地定义中缀 前缀 后缀和赋值运算符 以及相应的优先级与结合性 这些运算符在代码中可以像预设的运算符一样使用 甚至可以扩展已有的类型以支持自定义的运算符
        
        
        
        //1.位运算符(Bitwise operators)
        
        //位运算符可以操作一个数据结构中每个独立的位 通常被用在底层开发中 例如:图形编程和创建设备驱动
        //位运算符在处理外部资源的原始数据时也十分有用 例如:对自定义通信协议传输的数据进行编码和解码
        
        //Swift支持C语言的全部位运算符 具体如下:
        
        
        
        //1.1按位取反运算符(bitwise NOT operator)
        
        let initialBits: UInt8 = 0b00001111
        let invertedBits = ~initialBits //等于0b11110000
        print(initialBits, invertedBits)
        
        
        
        //1.2按位与运算符(Bitwise AND Operator)
        
        let firstSixBits: UInt8 = 0b11111100
        let lastSixBits: UInt8  = 0b00111111
        let middleFourBits = firstSixBits & lastSixBits //等于00111100
        print(middleFourBits)
        
        
        
        //1.3按位或运算符(Bitwise OR Operator)
        
        let someBits: UInt8 = 0b10110010
        let moreBits: UInt8 = 0b01011110
        let combinedbits = someBits | moreBits //等于11111110
        print(combinedbits)
        
        
        
        //1.4按位异或运算符(Bitwise XOR Opoerator)
        
        let firstBits: UInt8 = 0b00010100
        let otherBits: UInt8 = 0b00000101
        let outputBits = firstBits ^ otherBits //等于00010001
        print(outputBits)
        
        
        
        //1.5按位左移/右移运算符
        
        //按位左移运算符(<<)和按位右移运算符(>>)可以对一个数进行指定位数的左移和右移 但是需要遵守以下规则:
        
        //对一个数进行按位左移或按位右移 相当于对这个数进行乘2或除2的运算
        
        //对无符号整型进行移位的规则如下:
        //(1)已经存在的比特位按指定的位数进行左移和右移
        //(2)任何移动超出整型存储边界的位都会被丢弃
        //(3)用0来填充移动后产生的空白位
        //这种方法称为逻辑移位(logical shift)
        
        //下面的代码演示了Swift中的移位操作:
        let shiftBits: UInt8 = 4   //00000100
        shiftBits << 1             //00001000
        shiftBits << 2             //00010000
        shiftBits << 5             //10000000
        shiftBits << 6             //00000000
        shiftBits >> 2             //00000001
        
        //可以使用移位操作对其他的数据类型进行编码和解码:
        let pink: UInt32 = 0xCC6699
        let redComponent = (pink & 0xFF0000) >> 16    //redComponent  是0xCC 即:204
        let greenComponent = (pink & 0x00FF00) >> 8   //greenComponent是0x66 即:102
        let blueComponent = pink & 0x0000FF           //blueComponent 是0x99 即:153
        print(redComponent, greenComponent, blueComponent)
        
        
        
        //有符号整型的移位操作
        
        //相对于无符号整型来说 有符号整型的移位操作复杂得多 这种复杂性源于有符号整数的二进制表现形式
        
        //有符号整数使用第1个比特位(通常被称为符号位)来表示这个数的正负 0代表正数 1代表负数
        
        //其余的比特位(通常被称为数值位)存储了这个数的真实值
        
        //这是值为4的Int8型整数的二进制位表现形式:
        let valueA: Int8 = 4 //00000100
        print(valueA >> 2)   //00000001
        
        //不同于正数 负数是按照补码的方式存储的(符号位不变 数值位按位取反再加1)
        //当对有符号整数进行按位右移操作时 遵循与无符号整数相同的规则 但是对于移位产生的空白位使用符号位进行填充 而不是用0
        //这是值为-4的Int8型整数的二进制位表现形式:
        let valueB: Int8 = -4 //11111100
        print(valueB >> 2)    //11111100 -> 11111111 -> 10000001
        
        
        
        //2.溢出运算符
        
        //默认情况下 当给一个整数赋超过它容量的值时 Swift会报错
        
        //例如:Int16型整数能容纳的有符号整数范围是:-32768~32767 当为一个Int16型变量赋的值超过这个范围时 系统就会报错:
//        var potentialOverflow = Int16.max
//        potentialOverflow += 1 //这里会报错
        
        //也可以使用Swift提供的三个溢出操作符(overflow operators)来让系统支持整数溢出运算:
        //溢出加法(&+) 溢出减法(&-) 溢出乘法(&*)
        
        
        
        //2.1数值溢出
        
        //数值有可能出现上溢或下溢
        
        //下例展示了对一个无符号整数使用溢出加法(&+)进行上溢运算时的情况:
        let unsignedOverflow = UInt8.max //11111111
        let unsignedOverflowNew = unsignedOverflow &+ 1 //100000000(最高位的1溢出了)
        print(unsignedOverflow, "->", unsignedOverflowNew)
        
        //下例展示了对一个无符号整数使用溢出减法(&-)进行下溢运算时的情况:
        let unsignedOverflow1 = UInt8.min //00000000
        let unsignedOverflowNew1 = unsignedOverflow1 &- 1 //数值产生下溢并被截断为:11111111
        print(unsignedOverflow1, "->", unsignedOverflowNew1)
        
        //下例展示了对一个有符号整数使用溢出加法(&+)进行上溢运算时的情况:
        let signedOverflow = Int8.max //01111111
        let signedOverflowNew = signedOverflow &+ 1 //10000000
        print(signedOverflow, "->", signedOverflowNew)
        
        //下例展示了对一个有符号整数使用溢出减法(&-)进行下溢运算时的情况:
        let signedOverflow1 = Int8.min //10000000
        let signedOverflowNew1 = signedOverflow1 &- 1 //01111111
        print(signedOverflow1, "->", signedOverflowNew1)
        
        //对于无符号与有符号整数值 当出现上溢时 它们会从数值所能容纳的最大数变成最小的数 当发生下溢时 它们会从所能容纳的最小数变成最大的数
        
        
        
        //3.优先级和结合性
        
        //运算符的优先级(precedence)使得一些运算符优先于其他运算符 高优先级的运算符会被先计算
        
        //结合性(associativity)定义了相同优先级的运算符是如何结合的
        
        
        
        //4.运算符函数
        
        //类和结构体可以为已有的操作符提供自定义的实现 称为运算符重载(overloading)
        
        //下例展示了为自定义的结构体实现加法操作符(+):
        
        //⭐️代码1在File文件里⭐️
        
        let vector = Vector2D(x: 3.0, y: 1.0)
        let anotherVector = Vector2D(x: 2.0, y: 4.0)
        let combinedVector = vector + anotherVector
        print(combinedVector)
        
        
        
        //4.1前缀和后缀运算符
        
        //类与结构体也能提供标准单目运算符(unary operators)的实现
            
        //想实现前缀或后缀运算符 要在声明运算符函数的时候在func关键字前加prefix或postfix限定符:
        
        //⭐️代码2在File文件里⭐️
        
        let positive = Vector2D(x: 3.0, y: 4.0)
        let negative = -positive
        print(negative)
        
        
        
        //4.2复合赋值运算符
        
        //复合赋值运算符(Compound assignment operators)将赋值运算符(=)与其它运算符结合 例如:将加法与赋值结合成加法赋值运算符(+=) 实现时 需要把运算符的左参数设置成inout类型 因为这个参数的值会在运算符函数内直接被修改:
        
        //⭐️代码3在File文件里⭐️
        
        var original = Vector2D(x: 1.0, y: 2.0)
        let vectorToAdd = Vector2D(x: 3.0, y: 4.0)
        original += vectorToAdd
        print(original)
        
        
        
        //也可以将赋值与prefix或postfix限定符结合:
        
        //⭐️代码4在File文件里⭐️
        
        var toIncrement = Vector2D(x: 3.0, y: 4.0)
        let afterIncrement = ++toIncrement
        print(afterIncrement)
        
        //注意:不能对默认的赋值运算符(=)进行重载(只有组合赋值符可以被重载) 也无法对三目运算符:a ? b : c进行重载
        
        
        
        //4.3等价操作符
        
        //自定义的类和结构体没有对等价操作符(equivalence operators)进行默认实现 等价操作符通常被称为"相等"操作符(==)与"不等"操作符(!=) 对于自定义类型Swift无法判断其是否"相等"
        
        //为了使用等价操作符来对自定义类型进行判等操作 需要为其提供自定义实现:
        
        //⭐️代码5在File文件里⭐️
        
        let twoThree = Vector2D(x: 2.0, y: 3.0)
        let anotherTwoThree = Vector2D(x: 2.0, y: 3.0)
        if twoThree == anotherTwoThree
        {
            print("These two vectors are equivalent.")
        }
        else
        {
            print("These two vectors are not equivalent.")
        }
        
        
        
        //4.4自定义运算符
        
        //除了实现标准运算符 Swift还可以声明和实现自定义运算符(custom operators)
        
        //新的运算符要在全局作用域内使用operator关键字进行声明 同时还要指定prefix infix或postfix限定符:
        
        //⭐️代码6在File文件里⭐️
        
        var toBeDoubled = Vector2D(x: 1.0, y: 4.0)
        let afterDoubling = +++toBeDoubled
        print(afterDoubling)
        
        
        
        //4.5自定义中缀运算符的优先级和结合性
        
        //自定义中缀(infix)运算符也可以指定优先级(precedence)和结合性(associativity)
        
        //结合性(associativity)可选的值有left right和none
        //当左结合运算符跟其他相同优先级的左结合运算符写在一起时 会跟左边的操作数进行结合
        //当右结合运算符跟其他相同优先级的右结合运算符写在一起时 会跟右边的操作数进行结合
        //非结合运算符不能跟其他相同优先级的运算符写在一起
        
        //结合性(associativity)默认值是none 优先级(precedence)默认为100
        
        //下例定义了一个新的中缀运算符+- 此操作符是左结合的 并且它的优先级为140:
        
        //⭐️代码7在File文件里⭐️
        
        let firstVector = Vector2D(x: 1.0, y: 2.0)
        let secondVector = Vector2D(x: 3.0, y: 4.0)
        
        let plusMinusVector = firstVector +- secondVector
        print(plusMinusVector)
        
        //注意:定义前缀与后缀操作符时并没有指定优先级 然而 如果对一个操作数同时使用前缀与后缀操作符 则后缀操作符先被执行
    }
}