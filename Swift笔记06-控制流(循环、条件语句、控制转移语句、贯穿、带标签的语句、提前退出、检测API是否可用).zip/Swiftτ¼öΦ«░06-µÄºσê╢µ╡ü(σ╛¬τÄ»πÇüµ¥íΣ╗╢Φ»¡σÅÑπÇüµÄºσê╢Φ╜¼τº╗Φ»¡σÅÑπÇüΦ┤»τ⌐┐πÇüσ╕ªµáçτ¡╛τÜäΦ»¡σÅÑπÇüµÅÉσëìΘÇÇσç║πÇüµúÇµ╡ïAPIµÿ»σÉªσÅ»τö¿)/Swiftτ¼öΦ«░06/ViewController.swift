//
//  ViewController.swift
//  Swift笔记06
//
//  Created by apple on 15/12/22.
//  Copyright © 2015年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //控制流(Control Flow)
        
        //1.For循环
        
        //Swift提供两种for循环形式来按照指定的次数多次执行一系列语句:
        //for-in循环对一个集合里面的每个元素执行一系列语句
        //for循环 用来重复执行一系列语句直到特定条件达成 一般通过在每次循环完成后增加计数器的值来实现
        
        
        
        //1.1for-in循环
        
        //可以使用for-in循环来遍历一个集合里面的所有元素 例如:由数字表示的区间 数组中的元素 字符串中的字符
        for index in 1...5
        {
            print("\(index) times 5 is \(index * 5)")
        }
        
        //如果不需要知道区间内每一项的值 可以使用下划线(_)替代变量名来忽略对值的访问:
        let base = 3
        var answer = 1
        let power = 10
        for _ in 1...power
        {
            answer *= base
        }
        print("\(base) to the power of \(power) is \(answer)")
        
        //使用for-in遍历一个数组的所有元素:
        let names = ["Anna", "Alex", "Brian", "Jack"]
        for name in names
        {
            print("Hello, \(name)!")
        }
        
        //也可以通过遍历一个字典来访问它的键值对 遍历字典时 字典的每项元素会以(key, value)元组的形式返回 可以在for-in循环中使用显式的常量名称来解读(key, value)元组:
        let numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
        for (animalName, legCount) in numberOfLegs
        {
            print("\(animalName)s have \(legCount) legs")
        }
        //字典元素的遍历顺序和插入顺序可能不同 字典的内容在内部是无序的 所以遍历元素时不能保证顺序
        
        
        
        //1.2for循环
        
        //Swift也提供使用条件判断和递增方法的标准C样式的for循环:
//        for var index = 0; index < 3; ++index
//        {
//            print("index is \(index)")
//        }
        
        //下面是一般情况下这种循环的格式:
        //for initialization; condition; increment { statements }
        //和C语言中一样 分号将循环的定义分为3部分 不同的是Swift不需要使用圆括号将initialization; condition; increment包括起来
        
        //注意:在初始化表达式中声明的常量和变量(比如var index = 0)只在for循环的生命周期里有效 如果想在循环结束后访问index的值 就必须在循环生命周期开始前声明index才行:
        var index: Int
        for index = 0; index < 3; ++index
        {
            print("index is \(index)")
        }
        print("The loop statements were executed \(index) times")
        //注意:index在循环结束后终值是3而不是2 最后一次调用递增表达式++index会将index设置为3 从而导致index < 3条件为false 并终止循环
        
        
        
        //2.While循环
        
        //while循环运行一系列语句直到条件变成false 这类循环适合使用在第一次迭代前迭代次数未知的情况下
        
        //Swift提供两种while循环形式:
        //(1)while循环:每次在循环开始时 计算条件是否符合
        //(2)repeat-while循环:每次在循环结束时 计算条件是否符合
        
        
        
        //2.1while循环
        
        //下面是一般情况下while循环的格式:
        //while condition { statements }
        
        //下面的例子是一个叫做蛇和梯子的小游戏 也叫做滑道和梯子(游戏规则图片在本Demo里!)
        
        //游戏规则描述如下:
        //游戏盘面包括25个方格 游戏目标是达到或超过第25个方格
        //每一轮通过掷一个6边的骰子来确定移动方块的步数 移动的路线由图中横向的虚线所示
        //如果在某轮结束 移动到了梯子的底部 可以顺着梯子爬上去
        //如果在某轮结束 移动到了蛇的头部 会顺着蛇的身体滑下去
        
        
        
        //游戏盘面可以使用一个Int数组来表达 数组的长度由一个finalSquare常量储存 用来初始化数组和检测最终胜利条件
        //游戏盘面由26个Int 0值初始化 而不是25个(由0到25 一共26个):
        let finalSquare = 25
        var board = [Int](count: finalSquare + 1, repeatedValue: 0)
        
        //一些方块被设置成有蛇或者梯子的指定值 梯子底部的方块是一个正值 使你可以向上移动 蛇头处的方块是一个负值 会让你向下移动:
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
        //3号方块是梯子的底部 会让你向上移动到11号方格 我们使用board[03] = +08(来表示11和3之间的差值) 使用一元加运算符(+) 是为了和一元减运算符(-)对称 为了让盘面代码整齐 小于10的数字都使用0补齐(这些处理都不是必须的 仅仅是为了让代码整洁)
        
        //玩家由左下角编号为0的方格开始游戏 一般来说玩家第一次掷骰子后才会进入游戏盘面:
        var square = 0
        var diceRoll = 0
        while square < finalSquare
        {
            //掷骰子
            if ++diceRoll == 7 { diceRoll = 1 }
            
            //根据点数移动
            square += diceRoll
            print(square) //打印当前所在格子
            
            if square < board.count
            {
                //如果玩家还在棋盘上 可能会顺着梯子爬上去 或者顺着蛇滑下去 也可能不动
                let upOrDown = board[square]
                square += upOrDown
                if upOrDown != 0
                {
                    print(square) //打印受梯子和蛇影响之后所在的格子
                }
            }
        }
        print("Game over!")
        
        //相对于for循环 while循环比较适合本例中的这种情况 因为在while循环开始时 我们并不知道游戏的长度或者循环的次数 只有在达成指定条件时循环才会结束
        
        
        
        //2.2repeat-while循环
        
        //While循环的另一种形式是repeat-while 它和while的区别是在判断循环条件之前 先执行一次循环的代码块 然后重复循环直到条件为false
        //注意:Swift中的repeat-while循环和其他语言中的do-while循环是类似的
        //下面是一般情况下repeat-while循环的格式:
        //repeat { statements } while condition
        
        //蛇和梯子的游戏 repeat-while版本 循环中第一步就需要去检测是否在梯子或者蛇的方块上 没有梯子会让玩家直接上到第25个方格 所以玩家不会通过梯子直接赢得游戏 这样在循环开始时先检测是否踩在梯子或者蛇上是安全的
        //游戏开始时 玩家在第0个方格上:
        square = 0
        diceRoll = 0
        repeat
        {
            //如果玩家还在棋盘上 可能会顺着梯子爬上去 或者顺着蛇滑下去 也可能不动
            let upOrDown = board[square]
            square += upOrDown
            if upOrDown != 0
            {
                print(square) //打印受梯子和蛇影响之后所在的格子
            }
            
            //掷骰子
            if ++diceRoll == 7 { diceRoll = 1 }
            
            //根据点数移动
            square += diceRoll
            print(square) //打印当前所在格子
        }
        while square < finalSquare
        print("Game over!")
        //循环条件(while square < finalSquare)和while方式相同 但是只会在循环结束后进行判断 在本例中repeat-while表现比while循环更好 repeat-while方式会在判断square没有超出后直接运行square += board[square] 这种方式可以去掉while版本中的数组越界判断
        
        
        
        //3.条件语句
        
        //Swift提供两种类型的条件语句:if语句 switch语句
        //当条件较为简单且可能的情况很少时 使用if语句
        //switch语句更适用于条件较复杂 可能情况较多且需要用到模式匹配(pattern-matching)的情境
        
        
        
        //3.1If
        
        //if语句最简单的形式就是只包含一个条件 当且仅当该条件为true时 才执行相关代码:
        var temperatureInFahrenheit = 30
        if temperatureInFahrenheit <= 32
        {
            print("It's very cold. Consider wearing ascarf.")
        }
        
        //if语句也允许二选一 也就是当条件为false时 执行else语句:
        temperatureInFahrenheit = 40
        if temperatureInFahrenheit <= 32
        {
            print("It's very cold. Consider wearing a scarf.")
        }
        else
        {
            print("It's not that cold. Wear a t-shirt.")
        }
        
        //也可以把多个if语句像下面这样连接在一起:
        temperatureInFahrenheit = 90
        if temperatureInFahrenheit <= 32
        {
            print("It's very cold. Consider wearing a scarf.")
        }
        else if temperatureInFahrenheit >= 86
        {
            print("It's really warm. Don't forget to wear sunscreen.")
        }
        else
        {
            print("It's not that cold. Wear a t-shirt.")
        }
        
        //最后的else语句是可选的:
        temperatureInFahrenheit = 90
        if temperatureInFahrenheit <= 32
        {
            print("It's very cold. Consider wearing a scarf.")
        }
        else if temperatureInFahrenheit >= 86
        {
            print("It's really warm. Don't forget to wear sunscreen.")
        }
        
        
        
        //3.2Switch
        
        //switch语句会尝试把某个值与若干个模式(pattern)进行匹配 根据第一个匹配成功的模式 switch语句会执行对应的代码 当可能的情况较多时 通常用switch语句替换if语句
        
        //switch语句由多个case构成 为了匹配某些更特定的值 Swift提供了几种更复杂的匹配模式
        
        //每一个case都是代码执行的一条分支 这与if语句类似 与之不同的是 switch语句会决定哪一条分支应该被执行
        
        //switch语句必须是完备的:每一个可能的值都必须至少有一个case分支与之对应 在某些不能涵盖所有值的情况下 可以使用默认(default)分支满足该要求 默认分支必须在switch语句的最后面:
        let someCharacter: Character = "e"
        
        switch someCharacter
        {
        case "a", "e", "i", "o", "u":
            print("\(someCharacter) is a vowel")
        case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
        "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
            print("\(someCharacter) is a consonant")
        default:
            print("\(someCharacter) is not a vowel or a consonant")
        }
        
        //3.2.1不存在隐式贯穿(No Implicit Fallthrough)
        
        //与C语言和Objective-C中的switch语句不同 在Swift中 当匹配的case分支中的代码执行完毕后 程序会自动终止switch语句 而不会继续执行下一个case分支 也就是说 不需要在case分支中显式地使用break语句 这使得switch语句更安全
        
        //注意:虽然在Swift中break不是必须的 但依然可以在case分支中的代码执行完毕前使用break跳出
        
        //每一个case分支都必须包含至少一条语句 下面的代码是无效的 因为第一个case分支是空的:
//        let anotherCharacter: Character = "a"
//        switch anotherCharacter
//        {
//        case "a":
//        case "A":
//            print("The letter A")
//        default:
//            print("Not the letter A")
//        }
        
        
        //3.2.2区间匹配
        
        //case分支的模式也可以是一个值的区间 下例展示了如何使用区间匹配来输出任意数字对应的自然语言格式:
        let approximateCount = 62
        let countedThings = "moons orbiting Saturn"
        var naturalCount: String
        
        switch approximateCount
        {
        case 0:
            naturalCount = "no"
        case 1..<5:
            naturalCount = "a few"
        case 5..<12:
            naturalCount = "several"
        case 12..<100:
            naturalCount = "dozens of"
        case 100..<1000:
            naturalCount = "hundreds of"
        default:
            naturalCount = "many"
        }
        print("There are \(naturalCount) \(countedThings).")
        
        //3.2.3元组(Tuple)
        
        //可以使用元组在同一个switch语句中测试多个值 元组中的元素可以是值 也可以是区间 另外可以使用下划线(_)来匹配所有可能的值
        
        //下例展示了如何使用一个(Int, Int)类型的元组来分类点(x, y):
        let somePoint = (1, 1)
        
        switch somePoint
        {
        case (0, 0):
            print("(0, 0) is at the origin")
        case (_, 0):
            print("(\(somePoint.0), 0) is on the x-axis")
        case (0, _):
            print("(0, \(somePoint.1)) is on the y-axis")
        case (-2...2, -2...2):
            print("(\(somePoint.0), \(somePoint.1)) is inside the box")
        default:
            print("(\(somePoint.0), \(somePoint.1)) is outside of the box")
        }
        
        //3.2.4值绑定(Value Bindings)
        
        //case分支的模式允许将匹配的值绑定到一个临时的常量或变量 这些常量或变量在该case分支里就可以被引用 这种行为被称为值绑定(value binding)
        
        //下例展示了如何在一个(Int, Int)类型的元组中使用值绑定来分类点(x, y):
        let anotherPoint = (2, 0)
        
        switch anotherPoint
        {
        case (let x, 0):
            print("on the x-axis with an x value of \(x)")
        case (0, let y):
            print("on the y-axis with a y value of \(y)")
        case let (x, y):
            print("somewhere else at (\(x), \(y))")
        }
        
        //3.2.5Where
        
        //case分支的模式可以使用where语句来判断额外的条件
        
        //下例把点(x, y)进行了分类:
        let yetAnotherPoint = (1, -1)
        
        switch yetAnotherPoint
        {
        case let (x, y) where x == y:
            print("(\(x), \(y)) is on the line x == y")
        case let (x, y) where x == -y:
            print("(\(x), \(y)) is on the line x == -y")
        case let (x, y):
            print("(\(x), \(y)) is just some arbitrary point")
        }
        //这三个case都声明了常量x和y的占位符 用于临时获取元组yetAnotherPoint的两个值 这些常量被用作where语句的一部分 从而创建一个动态的过滤器(filter) 当且仅当where语句的条件为true时 匹配到的case分支才会被执行
        
        
        
        //4.控制转移语句(Control Transfer Statements)
        
        //控制转移语句改变代码的执行顺序 通过它们可以实现代码的跳转 Swift有五种控制转移语句:
        //(1)continue
        //(2)break
        //(3)fallthrough
        //(4)return
        //(5)throw
        //在下面介绍:continue break fallthrough语句 return语句将会在函数章节介绍 throw语句会在错误抛出介绍
        
        
        
        //4.1Continue
        
        //continue语句告诉一个循环体立刻停止本次循环迭代 重新开始下次循环迭代 但是并不会离开整个循环体
        
        //注意:在一个带有条件和递增的for循环体中 调用continue语句后 迭代增量仍然会被计算求值 循环体继续像往常一样工作 仅仅只是循环体中的执行代码会被跳过
        
        //下例把一个小写字符串中的元音字母和空格字符移除 生成了一个含义模糊的短句:
        
        let puzzleInput = "great minds think alike"
        var puzzleOutput = ""
        
        for character in puzzleInput.characters
        {
            switch character
            {
            case "a", "e", "i", "o", "u", " ":
                continue
            default:
                puzzleOutput.append(character)
            }
        }
        print(puzzleOutput)
        
        
        
        //4.2Break
        
        //break语句会立刻结束整个控制流的执行
        
        //循环语句中的break:
        //当在一个循环体中使用break时 会立刻中断该循环体的执行 然后跳转到表示循环体结束的大括号(})后的第一行代码 不会再有本次循环迭代的代码被执行 也不会再有下次的循环迭代产生
        
        //Switch语句中的break:
        //当在一个switch代码块中使用break时 会立即中断该switch代码块的执行 并且跳转到表示switch代码块结束的大括号(})后的第一行代码
        //这种特性可以被用来匹配或者忽略一个或多个分支 因为Swift的switch需要包含所有的分支而且不允许有为空的分支 当你想忽略某个分支时 可以在该分支内写上break语句 当那个分支被匹配到时 分支内的break语句会立即结束switch代码块
        
        //下例通过switch来判断一个Character值是否代表下面四种语言之一 为了简洁 多个值被包含在了同一个分支情况中:
        let numberSymbol: Character = "三"
        
        var possibleIntegerValue: Int?
        
        switch numberSymbol
        {
        case "1", "١", "一", "๑":
            possibleIntegerValue = 1
        case "2", "٢", "二", "๒":
            possibleIntegerValue = 2
        case "3", "٣", "三", "๓":
            possibleIntegerValue = 3
        case "4", "٤", "四", "๔":
            possibleIntegerValue = 4
        default:
            break
        }
        
        if let integerValue = possibleIntegerValue
        {
            print("The integer value of \(numberSymbol) is \(integerValue).")
        }
        else
        {
            print("An integer value could not be found for \(numberSymbol).")
        }
        //这个例子检查numberSymbol是否是拉丁 阿拉伯 中文或者泰语中的1到4的其中之一 如果被匹配到 该switch分支语句给Int?类型变量possibleIntegerValue设置一个整数值
        
        //当switch代码块执行完后 接下来的代码通过使用可选绑定来判断possibleIntegerValue是否曾经被设置过值 因为是可选类型 possibleIntegerValue有一个隐式的初始值nil 所以仅当possibleIntegerValue曾被switch代码块的前四个分支中的某个设置过值时 可选绑定才会被判断为成功
        
        //在上例中 把Character所有的的可能性都枚举出来是不现实的 所以使用default分支来包含所有上面没有匹配到字符的情况 由于default分支不需要执行任何动作 所以只写了一条break语句 一旦落入到default分支中 break语句就完成了该分支的所有代码操作 代码继续向下 开始执行if语句
        
        
        
        //5.贯穿(Fallthrough)
        
        //Swift中的switch不会从上一个case分支落入到下一个case分支中 相反 只要第一个匹配到的case分支完成了它需要执行的语句 整个switch代码块便执行完成 相比之下C语言要求显示的插入break语句到每个switch分支的末尾来阻止自动落入到下一个case分支中 Swift的这种避免默认落入到下一个分支中的特性意味着它的switch功能要比C语言的更加清晰和可预测 可以避免无意识地执行多个case分支而引发的错误
        
        //如果需要C风格的贯穿的特性 可以在每个需要该特性的case分支中使用fallthrough关键字:
        let integerToDescribe = 5
        var description = "The number \(integerToDescribe) is"
        switch integerToDescribe
        {
        case 2, 3, 5, 7, 11, 13, 17, 19:
            description += " a prime number, and also"
            fallthrough
        default:
            description += " an integer."
        }
        print(description)
        //注意:fallthrough关键字不会检查它下一个将会落入执行的case中的匹配条件 fallthrough简单地使代码执行继续连接到下一个case中的执行代码 这和C语言标准中的switch语句特性是一样的
        
        
        
        //6.带标签的语句
        
        //在Swift中 可以在循环体和switch代码块中嵌套循环体和switch代码块来创造复杂的控制流结构 然而 循环体和switch代码块两者都可以使用break语句来提前结束整个方法体 因此 显示地指明break语句想要终止的是哪个循环体或者switch代码块会很有用 类似地 如果有许多嵌套的循环体 显示指明continue语句想要影响哪一个循环体也会非常有用
        
        //为了实现这个目的 可以使用标签来标记一个循环体或者switch代码块 当使用break或者continue时 带上这个标签 可以控制该标签代表对象的中断或者执行
        
        //产生一个带标签的语句是通过在该语句的关键词的同一行前面放置一个标签:
        //label name: while condition { statements }
        
        //下例是在一个带有标签的while循环体中调用break和continue语句 是前面蛇和梯子的改编版本 这次增加了额外的规则:
        //为了获胜 必须刚好落在第25个方块中
        //如果某次掷骰子使玩家移动超出第25个方块 则必须重新掷骰子 直到玩家掷出的骰子数刚好能落在第25个方块中
        
        
        
        //这个版本的游戏使用while循环体和switch方法块来实现游戏的逻辑 while循环体有一个标签名:gameLoop 来表明它是蛇和梯子的主循环
        //该while循环体的条件判断语句是while square != finalSquare 这表明玩家必须要刚好落在第25个方块中:
        square = 0
        diceRoll = 0
        
        gameLoop: while square != finalSquare
        {
            if ++diceRoll == 7 { diceRoll = 1 } //掷骰子
            
            switch square + diceRoll
            {
            case finalSquare:
                break gameLoop //到达最后一个方块 游戏结束
            case let newSquare where newSquare > finalSquare:
                continue gameLoop //超出最后一个方块 再掷一次骰子
            default:              //没有超出第25个方块 本次移动有效
                square += diceRoll
                square += board[square]
            }
        }
        print("Game over!")
        
        //每次循环迭代开始时掷骰子 与之前玩家掷完骰子就立即移动不同 这里使用了switch来考虑每次移动可能产生的结果 从而决定玩家本次是否能够移动
        
        //如果骰子数刚好使玩家移动到最终的方格里 游戏结束 break gameLoop语句跳转控制去执行while循环体后的第一行代码 游戏结束
        
        //如果骰子数将会使玩家的移动超出最后的方格 那么这种移动是不合法的 玩家需要重新掷骰子 continue gameLoop语句结束本次while循环的迭代 开始下一次循环迭代
        
        //在剩余的所有情况中 骰子数产生的都是合法的移动 玩家向前移动骰子数个方格 然后游戏逻辑再处理玩家当前是否处于蛇头或者梯子的底部 本次循环迭代结束 控制跳转到while循环体的条件判断语句处 再决定是否能够继续执行下次循环迭代
        
        //注意:如果上述的break语句没有使用gameLoop标签 那么它将会中断switch代码块而不是while循环体 使用gameLoop标签清晰的表明了break想要中断的是哪个代码块 同时 当调用continue gameLoop去跳转到下一次循环迭代时 这里使用gameLoop标签并不是严格必须的 因为本例中只有一个循环体 所以continue语句会影响到哪个循环体是没有歧义的 而continue语句使用gameLoop标签也是没有危害的 这样做符合标签的使用规则
        
        
        
        //7.提前退出
        
        //和if语句一样 guard的执行取决于一个表达式的布尔值 可以使用guard语句来要求条件必须为真时 以执行guard语句后的代码 不同于if语句 一个guard语句总是有一个else分句 如果条件不为真则执行else分句中的代码:
        func greet(person: [String: String])
        {
            guard let name = person["name"] else
            {
                return
            }
            print("Hello \(name)")
            
            guard let location = person["location"] else
            {
                print("I hope the weather is nice near you.")
                return
            }
            print("I hope the weather is nice in \(location).")
        }
        
        greet(["name": "John"])
        greet(["name": "Jane", "location": "Cupertino"])
        
        //如果guard语句的条件被满足 则在保护语句的封闭大括号结束后继续执行代码 任何使用了可选绑定作为条件的一部分并被分配了值的变量或常量对于剩下的保护语句出现的代码段是可用的
        
        //如果条件不被满足 在else分支上的代码就会被执行 这个分支必须转移控制以退出guard语句出现的代码段 可以用控制转移语句如:return break continue 或者调用一个不返回的方法或函数如:fatalError()
        
        //相比于可以实现同样功能的if语句 按需使用guard语句会提升代码的可靠性 它可以使代码连贯的被执行而不需要将其包在else块中 而且处理违反要求的代码更符合规则
        
        
        
        //8.检测API是否可用
        
        //Swift有内置支持去检查接口的可用性 可以确保不会使用对于当前部署目标不可用的API
        
        //编译器使用SDK中的可用信息来验证在可用部署目标指定项目的代码中所有的API调用 如果使用了一个不可用的API Swift会在编译时报错
        
        //使用一个可用性条件在一个if或guard语句中去有条件的执行一段代码 这取决于要使用的API是否在运行时是可用的 编译器使用从可用性条件语句中获取的信息去验证在代码块中调用的API是否都可用
        if #available(iOS 9, OSX 10.10, *)
        {
            //在iOS使用iOS9 APIs并且在OS X使用OS X 10.10 APIs
        }
        else
        {
            //回滚至早前iOS and OS X 的APIs
        }
        
        //以上可用性条件指定在iOS if段的代码仅仅在iOS9及更高可运行 在OS X 仅在OS X 10.10及更高可运行 最后一个参数:* 是必须的 并且指定在任何其他平台上 if段的代码在最小可用部署目标指定项目中执行
        
        //在普遍形式中 可用性条件获取了平台名字和版本的清单 平台名字可以是iOS OSX或watchOS 除了特定的主版本号 如:iOS8 也可以指定较小的版本号如:iOS8.3或OS X 10.10.3
        
        if #available(watchOS 2.0, *)
        {
            //statements to execute if the APIs are available
        }
        else
        {
            //fallback statements to execute if the APIs are unavailable
        }
    }
}