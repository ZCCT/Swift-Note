//
//  ViewController.swift
//  Swift笔记20
//
//  Created by apple on 16/1/7.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //类型转移(Type Casting)
        
        //类型转移可以判断实例的类型 也可以将实例看做是其父类或者子类的实例
        
        //类型转移在Swift中用is和as操作符实现 这两个操作符提供了一种简单的方式去检查值的类型或者转换它的类型
        
        //也可以用它来检查一个类是否实现了某个协议
        
        
        
        //1.定义一个类层次作为例子
        
        //可以将类型转移用在类和子类的层次结构上 检查特定类实例的类型并且转换这个类实例的类型成为这个层次结构中的其他类型
        class MediaItem
        {
            var name: String
            
            init(name: String)
            {
                self.name = name
            }
        }
        
        class Movie: MediaItem
        {
            var director: String
            
            init(name: String, director: String)
            {
                self.director = director
                super.init(name: name)
            }
        }
        
        class Song: MediaItem
        {
            var artist: String
            
            init(name: String, artist: String)
            {
                self.artist = artist
                super.init(name: name)
            }
        }
        
        let library =
        [
            Movie(name: "Casablanca", director: "Michael Curtiz"),
            Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
            Movie(name: "Citizen Kane", director: "Orson Welles"),
            Song(name: "The One And Only", artist: "Chesney Hawkes"),
            Song(name: "Never Gonna Give You Up", artist: "Rick Astley")
        ]
        
        //在后台 library存储的是Movie和Song类型的 但是 若迭代它 依次取出的实例会是MediaItem类型的 为了让它们作为原本的类型工作 需要检查它们的类型或者向下转移它们到其它类型
        
        
        
        //2.检查类型(Checking Type)
        
        //用类型检查操作符(is)来检查一个实例是否属于特定子类型 若实例属于那个子类型 类型检查操作符返回true 否则返回false
        var movieCount = 0
        var songCount = 0
        
        for item in library
        {
            if item is Movie
            {
                movieCount += 1
            }
            else if item is Song
            {
                songCount += 1
            }
        }
        
        print("Media library contains \(movieCount) movies and \(songCount) songs")
        
        
        
        //3.向下转型(Downcasting)
        
        //某类型的常量或变量可能实际属于子类 这时可以尝试向下转移到它的子类型 用类型转换操作符(as?或as!)
        
        //因为向下转型可能会失败 类型转型操作符带有两种不同形式 条件形式:as? 返回一个试图向下转成的类型的可选值(optional value) 强制形式:as! 把试图向下转型和强制解包(force-unwraps)的结果作为一个混合动作
        
        //当不确定向下转型可以成功时 用类型转换的条件形式(as?) 条件形式的类型转换总是返回一个可选值 并且若下转是不可能的 可选值将是nil 这使得能够检查向下转型是否成功
        
        //只有确定向下转型一定会成功时 才能使用强制形式(as!) 当试图向下转型为一个不正确的类型时 强制形式的向下转型会触发一个运行时错误
        
        for item in library
        {
            if let movie = item as? Movie
            {
                print("Movie: '\(movie.name)', dir. \(movie.director)")
            }
            else if let song = item as? Song
            {
                print("Song: '\(song.name)', by \(song.artist)")
            }
        }
        
        //注意:转移没有真的改变实例或它的值 只是简单地把它作为它被转换成的类来使用
        
        
        
        //4.AnyObject和Any的类型转移
        
        //Swift为不确定类型提供了两种特殊类型别名:
        //(1)AnyObject可以代表任何class类型的实例
        //(2)Any可以表示任何类型 包括方法类型(function types)
        
        
        
        //4.1AnyObject类型
        
        //当使用Cocoa APIs时 一般会接收一个[AnyObject]类型的数组(或者说一个任何对象类型的数组) 这是因为 Objective-C没有明确的类型化数组 但是常常可以从API提供的信息中清晰地确定数组中对象的类型
        
        //这种情况下 可以使用强制形式的类型转移(as!)来下转在数组中的每一项到比AnyObject更明确的类型 不需要可选解析(optional unwrapping)
        
        let someObjects: [AnyObject] =
        [
            Movie(name: "2001: A Space Odyssey", director: "Stanley Kubrick"),
            Movie(name: "Moon", director: "Duncan Jones"),
            Movie(name: "Alien", director: "Ridley Scott")
        ]
        
        //因为这个数组只包含Movie实例 可以直接用(as!)下转并解包到不可选的Movie类型:
        for object in someObjects
        {
            let movie = object as! Movie
            print("Movie: '\(movie.name)', dir. \(movie.director)")
        }
        
        //为了更短的形式 下转someObjects数组为[Movie]类型来代替下转数组中每一项的方式:
        for movie in someObjects as! [Movie]
        {
            print("Movie: '\(movie.name)', dir. \(movie.director)")
        }
        
        
        
        //4.2Any类型
        
        //下例使用Any类型和混合的不同类型一起工作 包括方法类型和非class类型:
        var things = [Any]()
        
        things.append(0)
        things.append(0.0)
        things.append(42)
        things.append(3.14159)
        things.append("hello")
        things.append((3.0, 5.0))
        things.append(Movie(name: "Ghostbusters", director: "Ivan Reitman"))
        things.append({ (name: String) -> String in return "Hello, \(name)" })
        
        //下例用switch语句查找things数组每一项的类型:
        for thing in things
        {
            switch thing
            {
            case 0 as Int:
                print("zero as an Int")
            case 0 as Double:
                print("zero as a Double")
            case let someInt as Int:
                print("an integer value of \(someInt)")
            case let someDouble as Double where someDouble > 0:
                print("a positive double value of \(someDouble)")
            case is Double:
                print("some other double value that I don't want to print")
            case let someString as String:
                print("a string value of \"\(someString)\"")
            case let (x, y) as (Double, Double):
                print("an (x, y) point at \(x), \(y)")
            case let movie as Movie:
                print("a movie called '\(movie.name)', dir. \(movie.director)")
            case let stringConverter as String -> String:
                print(stringConverter("Michael"))
            default:
                print("something else")
            }
        }
        
        //注意:在switch的case中使用强制形式的类型转移操作符(as而不是as?)来检查和转换到一个明确的类型 在switch的case中这种检查总是安全的
    }
}