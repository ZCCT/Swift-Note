//
//  File.swift
//  Swift笔记25
//
//  Created by apple on 16/1/12.
//  Copyright © 2016年 ZCCT. All rights reserved.
//

import Foundation

//代码1
public class SomePublicClass             //显式的public类
{
    public var somePublicProperty = 0    //显式的public类成员
    var someInternalProperty = 0         //隐式的internal类成员
    private func somePrivateMethod() {}  //显式的private类成员
}

class SomeInternalClass                  //隐式的internal类
{
    var someInternalProperty = 0         //隐式的internal类成员
    private func somePrivateMethod() {}  //显式的private类成员
}

private class SomePrivateClass           // 显式的private类
{
    var somePrivateProperty = 0          // 隐式的private类成员
    func somePrivateMethod() {}          // 隐式的private类成员
}

//代码2
private func someFunction() -> (SomeInternalClass, SomePrivateClass)
{
    let thingA = SomeInternalClass()
    let thingB = SomePrivateClass()
    
    return (thingA, thingB)
}

//代码3
public enum CompassPoint
{
    case North
    case South
    case East
    case West
}

//代码4
public class A
{
    private func someMethod() {}
}

internal class B: A
{
    internal override func someMethod() {}
}

//代码5
public class A1
{
    private func someMethod() {}
}

internal class B1: A1
{
    override internal func someMethod()
    {
        super.someMethod()
    }
}

//因为A1和B1定义在同一个源文件中 所以在B1中重写的someMethod方法中可以调用super.someMethod()

//代码6
private var privateInstance = SomePrivateClass()

//代码7
struct TrackedString
{
    private(set) var numberOfEdits = 0
    
    var value: String = ""
    {
        didSet
        {
            numberOfEdits += 1
        }
    }
}

//结构体和它的属性value均没有申明显式访问级别 所以它们都拥有默认的访问级别internal

//该结构体的numberOfEdits属性使用private(set)修饰符进行了申明 这意味着该属性只能在定义该结构体的源文件中赋值 而该属性的Getter依然是默认的访问级别internal 所以该属性在当前的源文件中是可读写的 而在其它源文件中只是一个可读属性

//代码8
public struct TrackedStringNew
{
    public private(set) var numberOfEdits = 0
    
    public var value: String = ""
    {
        didSet
        {
            numberOfEdits += 1
        }
    }
    public init() {}
}